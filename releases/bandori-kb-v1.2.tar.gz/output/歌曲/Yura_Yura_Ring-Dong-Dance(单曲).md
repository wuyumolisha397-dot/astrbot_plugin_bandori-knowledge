---
title: Yura Yura Ring-Dong-Dance(单曲)
url: https://zh.moegirl.org.cn/Yura%20Yura%20Ring-Dong-Dance%28%E5%8D%95%E6%9B%B2%29
revision: 8461156
updated: '2026-06-28'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Yura Yura Ring-Dong-Dance(单曲)

《ゆら・ゆらRing-Dong-Dance》是《BanG Dream!》企划组合Pastel*Palettes的2nd单曲，发售于2018年1月17日。两首歌曲的试听动画于2017年12月12日在YouTube上发布。
初回封入特典为2nd单曲三联购入活动报名券Pastel＊Palettes部分、角色卡等。各店铺特典为写真、文件夹等。

## 试听动画

ゆら・ゆらRing-Dong-Dance

はなまる◎アンダンテ

## 收录曲目

## 外部链接与注释

试听动画：ゆら·ゆらRing-Dong-Dance、はなまる◎アンダンテ
（日文）官网CD介绍页
