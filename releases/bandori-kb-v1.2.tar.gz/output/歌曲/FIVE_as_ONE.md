---
title: FIVE as ONE
url: https://zh.moegirl.org.cn/FIVE%20as%20ONE
revision: 8547439
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

「FIVE as ONE」是《BanG Dream!》多媒体企划中女子摇滚乐队 RAISE A SUILEN 的原创音乐作品。作为乐队极具代表性的曲目之一，这首歌深刻契合了乐队成员间的羁绊与团队核心精神。

在发行与发布方面，该曲是手机游戏《BanG Dream! 少女乐团派对！》第 298 期主题游戏活动「Baby steps!」的专属活动奖励曲目。除了在手游内供玩家体验外，其完整版音源后续被正式收录并发行于 RAISE A SUILEN 的第 14 张实体单曲光盘《'FIGHT' ADDICT》中，该单曲唱片于 2025 年 11 月 12 日正式面向市场发售。

在舞台呈现与现场演出方面，「FIVE as ONE」拥有极具张力的表演设计。该曲在 RAISE A SUILEN 举办的「RUMBLEHEADZ」演唱会上迎来了首次公开演奏。在为期两日的演出日程中，乐队将其编排在了另一首曲目「REIGNING」之后进行无缝衔接。为了完美过渡两首风格强烈的作品，乐队核心成员兼键盘手 CHU² 在两曲之间特别加入了一段简短且极具技巧性的键盘 Solo 作为桥梁，这一精心设计的舞台编排不仅点燃了现场气氛，也充分展现了乐队高超的器乐演奏水准。

从作品内涵来看，曲名「FIVE as ONE」直白地传达了“五位成员融为一体”的核心理念。RAISE A SUILEN 由主唱 LAYER、吉他手 LOCK、贝斯手 MASKING、键盘手 CHU² 以及鼓手 PAREO 五名性格迥异却同样热爱音乐的少女组成。这首作品不仅是乐队音乐风格的一次集中展现，更是对她们在经历重重磨砺后，彼此建立深厚信任、在舞台上同呼吸共命运的完美写照。
