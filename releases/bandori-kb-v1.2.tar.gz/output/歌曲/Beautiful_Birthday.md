---
title: Beautiful Birthday
url: https://zh.moegirl.org.cn/Beautiful%20Birthday
revision: 8544325
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

《Beautiful Birthday》是《BanG Dream!》企划旗下乐队 RAISE A SUILEN 的原创歌曲，作为 TV 动画《BanG Dream! 3rd Season》第11话与第13话的插入曲登场。该曲的动画插曲版收录于2020年4月发售的动画原声带中，而完整版则收录于同年8月发行的乐队首张专辑《ERA》。

在动画剧情中，这首歌原本是由键盘手 PAREO 为队长兼 DJ 的 CHU² 准备的生日礼物。但在其深情的歌词背后，其实暗藏着乐队全体成员对 CHU² 的真挚告白。每一句歌词都对应着成员们与 CHU² 相遇、相知的过往经历：例如歌词中提及的“刺入冰冷梦境的光芒”，象征着吉他手 LOCK 在上京组建乐队屡屡受挫时，被 CHU² 的聚光灯照亮并招揽的瞬间；“即使身处地狱”的觉悟，则描绘了 PAREO 在 CHU² 偏离音乐初心时，依然决定追随她的深刻羁绊。此外，歌词还诉说了鼓手 MASKING 因狂野风格被业界忌惮却最终被乐队接纳的归属感，以及贝斯手 LAYER 在失去自我的支援工作中被 CHU² 的音乐重新唤醒的震撼。这些细节将整首歌升华为一首属于 RAISE A SUILEN 全员的羁绊之歌。

在动画演绎中，第11话版本采用了常规乐队配置演奏；而在第13话的最终话中，不仅加入了 CHU² 的人声演唱与 DJ 合成器音效，演唱方式也进行了重新编排，将剧情的情感推向高潮。

除了动画作品，该曲也是手机游戏《BanG Dream! 少女乐团派对!》第117期活动的关联曲目。在现实演出方面，《Beautiful Birthday》于舞台剧《We are RAISE A SUILEN～BanG Dream! The Stage～》中完成了首次公开演奏，随后在演唱会「THE DEPTHS」中迎来了真实的Live初演。凭借其极具故事性的背景与动感的旋律，该曲成为了 RAISE A SUILEN 极具代表性的音乐作品之一。
