---
title: Initial/击穿梦想的瞬间！
url: https://zh.moegirl.org.cn/Initial%2F%E5%87%BB%E7%A9%BF%E6%A2%A6%E6%83%B3%E7%9A%84%E7%9E%AC%E9%97%B4%EF%BC%81
revision: 8540390
updated: '2026-07-01'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

《Initial/击穿梦想的瞬间！》是《BanG Dream!》企划旗下组合Poppin'Party的第15张单曲，于2020年1月8日正式发售。这张单曲分为“Kirakira Ver.”与“Dokidoki Ver.”两种规格，两者均包含通常盘与附带Blu-ray的生产限定盘。不同版本在曲目细节上略有差异，但Blu-ray的收录影像内容保持一致。单曲的完整试听动画已于2019年11月15日在YouTube平台先行公开。

作为Poppin'Party的代表作之一，这张单曲承载了乐队成长的重要节点。同名主打歌《Initial》与《击穿梦想的瞬间！》延续了Poppin'Party一贯的青春摇滚风格，歌词聚焦于对梦想的执着追求与成员间的羁绊，充满积极向上的能量。其中，《击穿梦想的瞬间！》作为TV动画《BanG Dream! 3rd Season》的片头曲，而《Initial》则作为动画第三季的片尾曲，伴随动画的播出深入人心，进一步提升了歌曲与乐队的人气。

在实体碟的Blu-ray光盘中，除了音乐内容外，还特别收录了丰富的影像资料以回馈粉丝。光盘内完整收录了TV动画《BanG Dream! 2nd Season》的第13话，以及TV动画《BanG Dream! 3rd Season》的第1话，方便观众重温动画剧情。此外，还收录了《BanG Dream! TV》特别篇第1回的节目影像，该期节目由Poppin'Party成员爱美、大冢纱英与伊藤彩沙参与出演，展现了成员们在音乐之外的生动互动与真实魅力。

这张单曲不仅是Poppin'Party音乐历程中的一座重要里程碑，也完美总结了TV动画第二季与第三季的故事情感，是《BanG Dream!》企划粉丝不可错过的经典实体作品。
