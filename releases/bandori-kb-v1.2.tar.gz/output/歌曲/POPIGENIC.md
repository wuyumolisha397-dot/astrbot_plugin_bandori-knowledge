---
title: POPIGENIC
url: https://zh.moegirl.org.cn/POPIGENIC
revision: 8540485
updated: '2026-07-01'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

《POPIGENIC》是《BanG Dream!》企划旗下组合Poppin'Party的第三张正式专辑，于2025年2月26日正式发行。这张专辑分为附赠Blu-ray的生产限定盘与通常盘两种规格。

在音乐内容方面，专辑共收录了四首全新创作的曲目。此外，还完整收录了Poppin'Party此前发行的数张热门单曲作品，包括《Photograph》、《ぽっぴん'どりーむ！》、《夏に閉じこめて》、《新しい季節に》以及《TARINAI/トレモロアイズ》中的经典歌曲，充分展现了乐队在音乐风格上的成长与延续。

专辑的视觉设计充满情怀，其封面构图与Poppin'Party的出道首张单曲《Yes! BanG_Dream!》极为相似，通过巧妙的呼应唤起了粉丝的最初感动。在实体盘的特典方面，初回生产限定盘不仅随专辑附赠随机一张共五种款式的角色卡片，还为粉丝准备了Poppin'Party新年演唱会「Happy BanG Year!!」的最速先行抽选申请券。

此外，生产限定盘附带的Blu-ray光碟中，收录了Poppin'Party在2024年举办的「Poppin'Canvas 〜芸術の秋、音楽の秋！〜」专场演唱会的精彩现场影像。这份高清影像记录了乐队演绎《キラキラだとか夢だとか ～Sing Girls～》、《キズナミュージック♪》、《Time Lapse》以及《ティアドロップス》等经典曲目的高光舞台，为听众完整保留了现场的热烈氛围与感动。
