---
title: Floral Haven
url: https://zh.moegirl.org.cn/Floral%20Haven
revision: 8546324
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 樱川惠歌曲
- 相羽爱奈歌曲
---

Floral Haven是《BanG Dream!》企划旗下组合Roselia的原创歌曲。该曲游戏版于2024年5月5日实装，完整版于同年5月27日开启数字配信，随后收录于6月26日发售的Roselia第三张专辑《Für immer》中。官方将其描述为一首充满温暖和力量的作品。该曲在Roselia的「Rosenchor」演唱会上首次公开演奏，现场音源于2024年9月6日以《Floral Haven (LIVE ver.)》为名发布。
