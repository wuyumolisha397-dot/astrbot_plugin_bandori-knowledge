---
title: KIZUNA MUSIC(单曲)
url: https://zh.moegirl.org.cn/KIZUNA%20MUSIC%28%E5%8D%95%E6%9B%B2%29
revision: 8461225
updated: '2026-07-01'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
---

《KIZUNA MUSIC♪》是《BanG Dream!》企划旗下组合Poppin'Party的第十二张单曲，于2018年12月12日正式发售。这张单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格，全碟试听动画则于同年11月20日先行发布。

作为Poppin'Party发展历程中的重要作品，该单曲的同名主打歌《KIZUNA MUSIC♪》被选为电视动画《BanG Dream!》第二季的片头曲。歌曲延续了Poppin'Party一贯的青春流行摇滚风格，以轻快明亮的旋律与充满活力的编曲，生动诠释了乐队成员之间深厚的情感羁绊。Poppin'Party作为《BanG Dream!》企划的核心组合，由主唱兼吉他手户山香澄领衔，其音乐作品始终围绕着少女们通过音乐相遇、成长并建立真挚友谊的主题。这首《KIZUNA MUSIC♪》正是对这一核心理念的集中表达，展现了她们在音乐道路上携手前行的坚定信念。

在实体唱片发行方面，生产限定盘附带的Blu-ray光盘内收录了动画《BanG Dream!》第二季无字幕版的片头影像，为粉丝提供了极具收藏价值的视觉内容。此外，官方还推出了联合购入特典活动，消费者在指定店铺将本单曲与Roselia的第七张单曲《BRAVE JEWEL》以及RAISE A SUILEN的首张单曲《R·I·O·T》同时购入时，即可获赠一张特典翻唱曲CD。该特典CD收录了《BanG Dream!》企划中的经典翻唱歌曲，尽管不同店铺赠送的特典光盘表面涂装设计有所差异，但内含的音频曲目完全一致。

这张单曲不仅标志着Poppin'Party在音乐创作上的持续迈进，也通过跨乐队的联动特典，进一步丰富了《BanG Dream!》企划的整体世界观，展现了各组合之间并驾齐驱、共同发展的繁荣景象。
