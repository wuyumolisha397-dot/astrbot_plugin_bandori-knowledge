---
title: Georgette Me, Georgette You
url: https://zh.moegirl.org.cn/Georgette%20Me%2C%20Georgette%20You
revision: 8547274
updated: '2026-06-30'
categories:
- Ave Mujica歌曲
- BanG Dream!音乐
- C/W曲
- 佐佐木李子歌曲
- 冈田梦以歌曲
- 日本音乐作品
- 渡濑结月歌曲
- 片尾曲
- 米泽茜歌曲
- 高尾奏音歌曲
---

《Georgette Me, Georgette You》是企划《BanG Dream!》旗下组合Ave Mujica第二张单曲《KiLLKiSS》的C/W曲，同时作为电视动画《BanG Dream! Ave Mujica》的片尾曲使用。该曲于2025年1月15日作为数字独立单曲正式发售。

曲目标题中的“Georgette”源自法语，中文译为“乔其纱”。这是一种由高度加捻的纱线织就的半透明轻质绉布，常用于缝制连衣裙、晚礼服等服饰。此外，Georgette也可作为女性名字George的变体写法。在Ave Mujica的设定语境中，该词被赋予了舞台假名的含义，当演员需要分饰两角时，使用此类假名能有效防止剧情提前泄露或演出“穿帮”，这一特性与动画中角色身份的隐秘性相呼应。

在音乐游戏《BanG Dream! 少女乐团派对！》中，该曲于2025年1月9日率先追加至日服，随后分别于1月13日和1月14日上线简中服与国际服。其中，国际服的上线日期恰逢Ave Mujica成员Mortis（若叶睦）的生日，为游戏内活动增添了一份纪念意义。

作为Ave Mujica的代表作之一，该曲延续了组合神秘且富有戏剧张力的风格。歌曲通过Doloris、Mortis、Timoris、Amoris、Oblivionis等成员的合唱形式呈现，将乔其纱轻盈半透明的物质意象与舞台假名的双重身份隐喻相交织，深刻契合了《BanG Dream! Ave Mujica》动画中关于面具、真实自我与虚幻舞台的核心主题。
