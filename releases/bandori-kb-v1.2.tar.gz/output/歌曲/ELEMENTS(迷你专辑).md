---
title: ELEMENTS(迷你专辑)
url: https://zh.moegirl.org.cn/ELEMENTS%28%E8%BF%B7%E4%BD%A0%E4%B8%93%E8%BE%91%29
revision: 8542122
updated: '2026-06-28'
categories:
- 2024年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
---

《ELEMENTS》是《BanG Dream!》企划旗下组合Ave Mujica的第二张迷你专辑，于2024年10月2日发售，发售当日恰逢新月。专辑分为数量限定生产特装盘、Blu-ray付生产限定盘与通常盘三种规格。其中，数量限定生产特装盘采用特制的豪华包装盒，仅在武士道在线商店及活动会场独家限量销售。

专辑标题“ELEMENTS”源自古典哲学中的古典元素概念。专辑前四首歌曲的标题分别融入了代表火、风、水、土的古典四大元素炼金术符号，而第五首歌曲则指代第五元素“以太”。官方明确表示，专辑内的歌曲并非角色曲，其音乐内容均是为配合Ave Mujica第一至第四场演唱会的幕间剧情而创作。目前没有任何可靠证据能直接佐证曲目与特定角色存在唯一关联，相关猜测也尚未形成统一结论。

在实体特典方面，全部版本的专辑均附赠Ave Mujica与MyGO!!!!!联合演唱会《わかれ道の、その先へ》的最速先行抽选申请券。数量限定生产特装盘还额外包含以专辑歌曲为设计灵感的特制贴纸套装，以及第二场演唱会专属的特制黑色金字硅胶带。

此外，附带Blu-ray的限定盘收录了Ave Mujica第二场演唱会“Quaerere Lumina”神奈川公演的完整Live影像。影像收录了《素晴らしき世界 でも どこにもない場所》《Angles》《暗黒天国》《Mas?uerade Rhapsody Re?uest》《神さま、バカ》《Symbol I : 🜂》《KINGS》《堕天》《Symbol II : 🜁》《Choir 'S' Choir》《ふたつの月 ~Deep Into The Forest~》以及《黒のバースデイ》等经典曲目，完整呈现了该组合极具戏剧张力的舞台演出。
