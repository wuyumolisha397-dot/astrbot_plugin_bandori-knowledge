---
title: Live Beyond!!(专辑)
url: https://zh.moegirl.org.cn/Live%20Beyond%21%21%28%E4%B8%93%E8%BE%91%29
revision: 8457799
updated: '2026-07-01'
categories:
- 2021年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
---

《Live Beyond!!》是《BanG Dream!》企划组合Poppin'Party的首张迷你专辑，于2021年8月18日发售。专辑分为Blu-ray付生产限定盘和通常盘两种规格。

专辑同名主打曲《Live Beyond!!》配有音乐视频。Blu-ray付生产限定盘收录了《BanG Dream! 8th☆LIVE》夏の野外3DAYS DAY3的「Special Live ～Summerly Tone♪～」Poppin'Party PART演出影像，演出曲目包括《Time Lapse》《イニシャル》《夏のドーン！》《夏空 SUN! SUN! SEVEN!》《八月のif》《ときめきエクスペリエンス！》《STAR BEAT!～ホシノコドウ～》《ティアドロップス》《ミライトレイン》等九首歌曲，并包含幕间映像Ⅲ及安可环节。安可环节中，Poppin'Party与凑友希那（CV.相羽あいな）和LAYER（CV.Raychell）共同演唱了《夢を撃ち抜く瞬間に！》。此外，Blu-ray还收录了特典映像《全力！バンドリ！タイムズ》前编与后编。
