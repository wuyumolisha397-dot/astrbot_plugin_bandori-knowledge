---
title: 天下统一 A to Z(单曲)
url: https://zh.moegirl.org.cn/%E5%A4%A9%E4%B8%8B%E7%BB%9F%E4%B8%80%20A%20to%20Z%28%E5%8D%95%E6%9B%B2%29
revision: 8557390
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题替换的页面
---

# 天下统一 A to Z(单曲)

《天下トーイツ A to Z☆》是《BanG Dream!》企划组合Pastel*Palettes的4th单曲，发售于2019年2月20日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2019年1月4日在YouTube上发布。
初回封入特典为角色卡片一张（共5种），及预计在2019年春季后举办的活动抽选申请卷。
在各店铺与Poppin'Party13th单曲《Jumpin'》一同购入还将赠送特典BD一张，内容为「Poppin'Party HAPPY PARTY 2018!猛特訓SP 完全版」。

## 试听动画

## 收录曲目

## Blu-ray收录内容

迷你动画《BanG Dream! Girls Band Party!☆PICO》 #10 ~ #18

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
