---
title: 觉悟的Liberation
url: https://zh.moegirl.org.cn/%E8%A7%89%E6%82%9F%E7%9A%84Liberation
revision: 8546291
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# 觉悟的Liberation

「覚悟のLiberation」是企划《BanG Dream!》旗下组合Roselia演唱的歌曲。为游戏第243期活动『リトルライト・イン・ザ・ダークネス』（Little Light in the Darkness）的主题曲。

## 歌曲试听

## 歌词

翻译：蔷薇之心字幕组

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  冰川纱夜  今井莉莎  宇田川亚子  白金燐子  合唱

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

（待补充）

## 注释及外部链接
