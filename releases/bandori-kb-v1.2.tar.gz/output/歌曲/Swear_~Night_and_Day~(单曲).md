---
title: Swear ~Night and Day~(单曲)
url: https://zh.moegirl.org.cn/Swear%20~Night%20and%20Day~%28%E5%8D%95%E6%9B%B2%29
revision: 8462499
updated: '2026-06-28'
categories:
- 2022年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Swear ~Night and Day~(单曲)

《Swear ~Night and Day~》是《BanG Dream!》企划组合Roselia的12th单曲，发售于2022年10月26日。分为Blu-ray付生产限定盘与通常盘两种规格。
试听动画于2022年9月3日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：一张BanG Dream! 11th☆LIVE DAY2的抽选券，以及一张角色卡片。

## 试听动画

## 收录曲目

## Blu-ray收录内容

## 外部链接

（日文）官网CD介绍页
