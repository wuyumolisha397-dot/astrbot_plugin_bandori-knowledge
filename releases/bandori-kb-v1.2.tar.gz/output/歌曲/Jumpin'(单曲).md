---
title: Jumpin'(单曲)
url: https://zh.moegirl.org.cn/Jumpin%27%28%E5%8D%95%E6%9B%B2%29
revision: 8461223
updated: '2026-07-01'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Jumpin'》是《BanG Dream!》企划中组合Poppin'Party的第13张单曲，于2019年2月20日正式发售。该单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格。

单曲的主打曲《Jumpin'》与C/W曲《What's the POPIPA!?》的试听动画，分别于2019年1月3日和1月10日在YouTube平台上陆续公开。在收录曲目方面，除了这两首歌曲及其伴奏版本外，生产限定盘附带的Blu-ray光盘还收录了Poppin'Party在2018年5月12日举办的「BanG Dream! 5th☆LIVE」Day1「HAPPY PARTY 2018!」演唱会完整映像。

在发售特典方面，单曲的初回封入特典包含一张随机角色卡片（全5种），以及Poppin'Party春季后续演唱会的抽选申请券。此外，粉丝在各店铺将本单曲与Pastel*Palettes的第4张单曲《天下トーイツ A to Z☆》一同购入时，还可额外获赠一张特典蓝光光盘，其内容为「Poppin'Party HAPPY PARTY 2018! 猛特訓SP 完全版」的特别影像。
