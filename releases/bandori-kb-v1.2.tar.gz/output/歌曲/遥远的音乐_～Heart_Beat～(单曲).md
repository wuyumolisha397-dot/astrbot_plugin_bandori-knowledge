---
title: 遥远的音乐 ～Heart Beat～(单曲)
url: https://zh.moegirl.org.cn/%E9%81%A5%E8%BF%9C%E7%9A%84%E9%9F%B3%E4%B9%90%20%EF%BD%9EHeart%20Beat%EF%BD%9E%28%E5%8D%95%E6%9B%B2%29
revision: 8538358
updated: '2026-07-01'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 遥远的音乐 ～Heart Beat～(单曲)

《遠い音楽 ～ハートビート～》是TV动画《BanG Dream!》主角山吹沙绫（CV.大桥彩香）的角色歌专辑，发售于2017年7月26日。试听动画于2017年7月21日在YouTube上发布。
另收录了由山吹沙绫演唱的《STAR BEAT!～ホシノコドウ～》的Acoustic版本作为C/W曲。
初回封入特典为ESP合作角色拨片（山吹沙绫ver.）、角色歌五首联动特别报名券等。各店铺特典为写真、徽章、收纳盒等。

## 试听动画

## 收录曲目

## 外部链接与注释

试听动画
（日文）官网CD介绍页
