---
title: EXPOSE 'Burn out!!!'
url: https://zh.moegirl.org.cn/EXPOSE%20%27Burn%20out%21%21%21%27
revision: 8543322
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

「EXPOSE 'Burn out!!!'」是《BanG Dream!》企划中乐队 RAISE A SUILEN 的原创歌曲，由主唱纺木吏佐演唱。该曲作为 TV 动画《BanG Dream! 3rd Season》第4至7话及第10话的插入曲首次广为人知，同时亦收录于剧场版动画《BanG Dream! FILM LIVE 2nd Stage》中。

本曲于2019年2月20日随乐队的第2张单曲《A DECLARATION OF ×××》正式发行，后收录于2020年发售的首张专辑《ERA》。2023年6月，乐队的第11张单曲《-N-E-M-E-S-I-S-》中收录了英文填词版，其词意与日文原版基本一致。在早期现场演出中，本曲便已作为核心曲目登台表演。

在衍生手游《BanG Dream! 少女乐团派对！》中，该曲于2020年6月10日随乐队剧情实装，同时也是游戏第117期 RAISE A SUILEN 专属活动的主题曲。游戏谱面方面，EXPERT 难度为26级，整体属于常规水平，但若开启附带大量光影特效的动画 MV 模式，视觉干扰会大幅增加游玩挑战。SPECIAL 难度则定级为27级，以复杂的新滑键与粉键交替配置为主要难点，十分考验玩家的读谱与协调能力。此外，该曲也曾被音乐游戏《D4DJ Groovy Mix》收录，由组合 Merm4id 进行翻唱。

作为乐队的代表作品之一，本曲在演出与传播中也衍生出趣味轶事。由于纺木吏佐独特的说唱口音，RAP 段中的“What happened”常被听众空耳成“What's happened”，这一发音特点不仅遭到同队吉他手小原莉子的吐槽，官方更在游戏中专门推出相关卡牌进行玩梗，成为了粉丝间津津乐道的互动佳话。
