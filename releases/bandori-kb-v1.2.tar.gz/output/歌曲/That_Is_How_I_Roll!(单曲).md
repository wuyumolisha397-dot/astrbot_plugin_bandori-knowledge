---
title: That Is How I Roll!(单曲)
url: https://zh.moegirl.org.cn/That%20Is%20How%20I%20Roll%21%28%E5%8D%95%E6%9B%B2%29
revision: 8462505
updated: '2026-06-28'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# That Is How I Roll!(单曲)

《That Is How I Roll!》是《BanG Dream!》企划组合Afterglow的1st单曲，发售于2017年9月6日。试听动画于2017年8月25日在YouTube上发布。
初回限定特典为A4海报。初回封入特典为1st单曲发布特别纪念活动参加抽选券、角色卡等。各店铺特典为写真、文件夹等。

## 试听动画

## 收录曲目

## 外部链接与注释

试听动画
（日文）官网CD介绍页
