---
title: Embrace of light
url: https://zh.moegirl.org.cn/Embrace%20of%20light
revision: 8545090
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 扰乱 THE PRINCESS OF SNOW AND BLOOD音乐
- 日本音乐作品
- 片尾曲
- 纺木吏佐歌曲
---

「Embrace of light」是《BanG Dream!》企划旗下组合 RAISE A SUILEN 的原创歌曲，同时作为 TV 动画《扰乱 THE PRINCESS OF SNOW AND BLOOD》的片尾曲使用。该曲收录于 2021 年 4 月 21 日发售的 RAISE A SUILEN 第七张单曲《EXIST》中，并在「OVERKILL」演唱会上首次公开演奏。

作为 RAISE A SUILEN 少有的慢节奏抒情曲，本曲依然保留了乐队标志性的音乐风格。歌曲主题与《扰乱》的剧情紧密相连，以主角雪村咲羽与中村浅阳的羁绊为创作视角，表达了历经磨难与万般无奈后依然不离不弃、永远守护对方的坚定心意。由于同张单曲中的主打歌《EXIST》在游戏内具有极高的通关效率，本曲常在效率对比中被玩家提及。

在手机游戏《BanG Dream! 少女乐团派对！》中，该曲的全曲 BPM 位居全游倒数第二，物量也位列倒数第二，仅比《你所给予之物》多出五个音符。其专家难度设定为 22 级，整体谱面在所有专家难度中偏向简单，除结尾阶段的连打部分外，非常适合新手玩家作为进阶挑战的入门练习曲目。
