---
title: EXIST(RAISE A SUILEN)
url: https://zh.moegirl.org.cn/EXIST%28RAISE%20A%20SUILEN%29
revision: 8545045
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 使用标题格式化的页面
- 夏芽歌曲
- 小原莉子歌曲
- 扰乱 THE PRINCESS OF SNOW AND BLOOD音乐
- 日本音乐作品
- 片头曲
- 纺木吏佐歌曲
---

《EXIST》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的原创歌曲，同时作为TV动画《扰乱 THE PRINCESS OF SNOW AND BLOOD》的片头曲使用。该曲于2021年4月21日作为RAISE A SUILEN的第七张单曲发行，后亦收录于2024年6月12日发售的第二张专辑《SAVAGE》中。早在正式发行前，本曲便在「BE LIGHT」活动上进行了首次公开演奏。

作为一首为动画量身打造的歌曲，《EXIST》展现了RAISE A SUILEN一贯的强烈风格与摇滚张力，契合了《扰乱》剧集的氛围。在《BanG Dream! 少女乐团派对！》手游中，本曲随RAISE A SUILEN的实装同步追加，并因其出色的综合数据成为游戏内备受玩家青睐的曲目。

在游戏谱面设计方面，本曲的Expert难度标级为26，但其通关与全连难度对玩家极为友善，实际体验远低于标定等级，被玩家群体戏称为入门级谱面。尽管其BPM仅为140，但由于物量与时长配置优异，使其成为游戏内极具代表性的高效率曲目之一。在综合出分能力上，该谱面位居全服前列；在活动协力玩法中，尤其受到大众玩家的欢迎。对于无法攻克高难度曲目的玩家而言，《EXIST》是追求活动积分收益的最优选择，在活动末尾的冲刺阶段更是协力模式中的热门选项。
