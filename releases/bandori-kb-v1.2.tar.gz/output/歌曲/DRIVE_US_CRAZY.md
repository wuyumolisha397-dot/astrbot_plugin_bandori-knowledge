---
title: DRIVE US CRAZY
url: https://zh.moegirl.org.cn/DRIVE%20US%20CRAZY
revision: 8544309
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

「DRIVE US CRAZY」是《BanG Dream!》企划中女子乐队 RAISE A SUILEN 的原创歌曲，同时作为剧场版动画《BanG Dream! ぽっぴん'どりーむ！》的插曲。该曲以极具爆发力的摇滚编曲和强烈的舞台感染力著称，展现了 RAISE A SUILEN 标志性的硬核音乐风格。

歌曲完整版最初收录于 2020 年 1 月 22 日发行的同名第四张单曲《DRIVE US CRAZY》，后于同年 8 月 19 日被收录进乐队首张专辑《ERA》。在「Heaven and Earth」演唱会上首次公开演出时，乐队特别设计了开场合唱环节，通过互动形式调动现场气氛，成为后续演出的固定特色之一。

作为 RAISE A SUILEN 的代表作之一，该曲延续了乐队融合电子音效与重型摇滚的创作路线，主唱 LAYER 的充满张力的演唱与 CHU² 的电子音效编排形成鲜明对比。歌曲主题围绕突破束缚、释放情绪展开，歌词中反复出现的「DRIVE US CRAZY」成为核心记忆点。

在手游《BanG Dream! 少女乐团派对！》中，该曲于 2022 年 3 月 17 日作为剧场版联动内容追加，距离原曲发布已间隔 785 天，创下当时游戏内歌曲收录时间最长的纪录。游戏内谱面以高难度著称，Expert 难度被评定为 27 级，Special 难度则于 2025 年 12 月 31 日追加。
