---
title: Determination Symphony
url: https://zh.moegirl.org.cn/Determination%20Symphony
revision: 8540591
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Roselia歌曲
- 中岛由贵歌曲
- 小泽亚李歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 插曲
- 日本音乐作品
- 日笠阳子歌曲
- 明坂聪美歌曲
- 樱川惠歌曲
- 相羽爱奈歌曲
- 远藤祐里香歌曲
---

《Determination Symphony》是《BanG Dream!》企划中组合Roselia的歌曲，最初作为其第四张单曲《ONENESS》的C/W曲于2017年11月29日发售。该曲同时也是手游《BanG Dream! 少女乐团派对！》第二十一期剧情活动《秋时骤雨伞层叠》的主题曲，并在TV动画《BanG Dream!》第二季第9话中作为插曲登场。随着组合成员更替，Roselia在第二张专辑《Wahl》中收录了由新声优阵容重新录制的版本。

在游戏内，该曲以较高的BPM和物量著称。其高难度谱面配置相对均匀，对玩家的手速与体力有较高要求，常被视作挑战更高难度曲目的前置练习曲。

此外，本曲还有由SISTER'S QUARTET（成员包括宇田川巴、冰川日菜、冰川纱夜与宇田川亚子的声优）演唱的平行歌曲版本，该版本于2026年1月6日在各音乐平台上线配信，其游戏谱面与原版保持一致。
