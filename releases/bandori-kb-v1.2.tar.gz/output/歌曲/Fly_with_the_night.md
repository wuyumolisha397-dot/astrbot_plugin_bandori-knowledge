---
title: Fly with the night
url: https://zh.moegirl.org.cn/Fly%20with%20the%20night
revision: 8545127
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- 小写标题
- 日本音乐作品
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

《fly with the night》是《BanG Dream!》企划旗下女子乐队组合Morfonica的第四张同名单曲主打曲，于2022年3月30日正式发售。歌曲由仓田真白、桐谷透子、广町七深、二叶筑紫与八潮瑠唯共同演唱，延续了Morfonica一贯融合小提琴与摇滚的交响曲风，展现出乐队在音乐表达上的成长与探索。

该曲同时作为手机游戏《BanG Dream! 少女乐团派对！》中Morfonica第二章活动课题曲登场，活动于2021年10月10日在日服开启。在游戏谱面设计方面，Expert难度被标注为26级，但实际配置整体偏向25级中位水平，除副歌部分出现的大跨度滑键（绿条）外，其余段落难度相对平易，在同期发布的四首第二章活动曲目中属于较易上手的一首。

作为Morfonica的代表作品之一，《fly with the night》通过富有层次感的编曲与成员们各具特色的声线，传递出乐队成员携手突破困境、追寻音乐理想的情感内核，进一步巩固了Morfonica在BanG Dream!企划中独树一帜的优雅风格。
