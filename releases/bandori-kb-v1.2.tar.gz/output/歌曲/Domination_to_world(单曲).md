---
title: Domination to world(单曲)
url: https://zh.moegirl.org.cn/Domination%20to%20world%28%E5%8D%95%E6%9B%B2%29
revision: 8461192
updated: '2026-06-28'
categories:
- 2021年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Domination to world》是《BanG Dream!》多媒体企划旗下女子摇滚乐队 RAISE A SUILEN 的第八张单曲，于2021年9月29日正式发行。这张单曲共推出包含蓝光光盘的生产限定盘与通常盘两种规格，实体唱片不仅收录了同名主打歌等音乐作品，其初回生产特典还附赠了乐队巡演“RAISE A SUILEN ZEPP TOUR 2021 BE LIGHT”追加公演的最速先行抽选券，以及随机封入的五种巡演版成员卡片之一。在正式发售前夕，官方已于同年9月6日在视频平台上公开了整张单曲的试听影像，提前向听众展现了乐队极具爆发力的音乐魅力。

除了录音室音轨外，生产限定盘附带的蓝光光盘还完整收录了 RAISE A SUILEN 在“BanG Dream! 8th☆LIVE”夏季野外三日演唱会第二天举办的专场演出“THE DEPTHS”的精彩实况。这场演出全方位记录了乐队在舞台上的狂热表现，蓝光盘中收录的现场曲目涵盖了乐队自成立以来的多首核心代表作与翻唱经典。

其中包括《UNSTOPPABLE》《HELL! or HELL?》《Beautiful Birthday》《DRIVE US CRAZY》《R･I･O･T》等完美展现其标志性强硬摇滚与电子音乐融合风格的原创曲目。此外，现场影像还收录了《激動》以及《恋しさとせつなさと心強さと》《DEPARTURES》等经典流行金曲的摇滚改编版。这些现场录像不仅展现了乐队成员们扎实的演奏功底与主唱极具穿透力的嗓音，更将现场热烈的演出氛围原汁原味地呈现给了观众。作为 RAISE A SUILEN 音乐历程中的重要实体发行物，这张单曲凭借其丰富的光盘附赠内容，成为了粉丝们回顾乐队早期现场魅力与感受其独特音乐风格的重要作品。
