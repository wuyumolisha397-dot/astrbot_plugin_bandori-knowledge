---
title: Domination to world
url: https://zh.moegirl.org.cn/Domination%20to%20world
revision: 8545069
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

「Domination to world」是《BanG Dream!》企划组合 RAISE A SUILEN 的原创歌曲，收录于 2021 年 9 月 29 日发售的同名第八张单曲，后亦收录于 2024 年 6 月 12 日发行的乐队第二张专辑《SAVAGE》。该曲在手游《BanG Dream! 少女乐团派对！》中作为第 151 期活动「outside/inside」的活动曲，于 2021 年 5 月 31 日实装日服，并在此前的「Mythology」演出中首次公开演奏。

在游戏谱面方面，该曲以约 1 分 49 秒的时长承载了高达 932 的物量，整体难度较高。谱面难点集中于大量天弱与鬼畜绿条配置，开头与结尾均包含类似「SOS」的衔接段落。中段 combo 599 后出现连续三次迅速三连打与双押交替，而 combo 757 后的强化版双押段更被视为全曲最难部分。在《DRIVE US CRAZY》实装前，该曲长期被公认为 RAISE A SUILEN 最难的 27 级 Expert 谱面。
