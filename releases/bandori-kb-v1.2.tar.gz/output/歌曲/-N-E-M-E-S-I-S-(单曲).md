---
title: -N-E-M-E-S-I-S-(单曲)
url: https://zh.moegirl.org.cn/-N-E-M-E-S-I-S-%28%E5%8D%95%E6%9B%B2%29
revision: 8461170
updated: '2026-06-28'
categories:
- 2023年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《-N-E-M-E-S-I-S-》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的第11张单曲，于2023年6月28日正式发售。单曲分为Blu-ray付生产限定盘与通常盘两种规格。

本作收录一首全新原创曲《-N-E-M-E-S-I-S-》，以及两首既往原创曲的英文重新填词版本。这是BanG Dream!企划首次在单曲中收录英文重填词作品。新曲《-N-E-M-E-S-I-S-》以强烈的节奏和充满力量感的编曲展现了RAISE A SUILEN向世界舞台进发的决心。两首英文版歌曲的试听动画于2023年5月17日在BanG Dream!官方YouTube频道公开。

初回生产限定盘内封入了两项特典：一张BanG Dream! 12th☆LIVE DAY3「REVEAL」演唱会的最速先行抽选券，以及一张随机封入的原创角色设计卡片（共5种款式）。Blu-ray付生产限定盘附带的光碟收录了BanG Dream! 10th☆LIVE DAY4「SOUL ROAR」的完整Live映像，包括《DRIVE US CRAZY》《UNSTOPPABLE》《Invincible Fighter》《Takin' my Heart》《EXIST》《Sacred World》《!NVADE SHOW!》《灼熱 Bonfire!》《OUTSIDER RODEO》《Beautiful Birthday》《Light a fire》《R･I･O･T》《THE WAY OF LIFE》《HELL! or HELL?》《CORUSCATE -DNA-》《EXPOSE 'Burn out!!!'》等共计16首曲目的现场演出。

作为RAISE A SUILEN在2023年夏季的重要单曲，《-N-E-M-E-S-I-S-》延续了该乐队一贯的硬朗电子摇滚风格，同时通过英文重填词的形式进一步拓展了海外受众的接触面，体现了企划对全球化发展的战略布局。单曲的发行也配合了乐队此后的专场演唱会计划，在粉丝中获得了较高的讨论度。
