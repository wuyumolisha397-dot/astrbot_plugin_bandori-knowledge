---
title: BanG Dream!特殊组合翻唱歌曲2
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8546257
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《BanG Dream! 少女乐团派对！》中收录了一系列特殊组合翻唱歌曲。这些作品打破了原有乐队的界限，由不同乐团的成员跨队合作演唱，为玩家带来了全新的视听体验。

这些翻唱曲目涵盖了动画主题曲、热门流行乐以及经典的VOCALOID曲目。在合作阵容上，美竹兰是极为活跃的跨队成员，她曾与Hello, Happy World!合作演绎《理科生坠入情网，故尝试证明。》的片尾曲《Turing Love》，与Roselia共同演唱VOCALOID传说曲《Surges》，与Poppin'Party合作电视剧主题曲《I wonder》，并与Pastel*Palettes合作翻唱了虚拟团体HIMEHINA的《爱派Dancehall》。此外，Poppin'Party还与高松灯合作翻唱了电视剧《Eye Love You》的主题曲《几亿光年》。

Pastel*Palettes也参与了多次精彩的跨队合作。她们与PAREO共同翻唱了初音未来的《行星环》，与松原花音合作演绎了巡音流歌的殿堂曲《Dreamin Chuchu》，并与凑友希那合唱了由初音未来原唱的《才不是恶魔呢》。凑友希那还与RAISE A SUILEN合作翻唱了Ado的热门歌曲《踊》。

其他特殊组合同样带来了丰富的曲目。Hello, Happy World!与仓田真白合作翻唱了动画《鹿乃子乃子乃子虎视眈眈》的片头曲《鹿色时光》；Roselia与LAYER共同演绎了动画《进击的巨人 最终季》的片尾曲《恶魔之子》；Morfonica则与高松灯合作，翻唱了动画《青春之箱》的片头曲《Same Blue》。

部分歌曲的完整版音频被正式收录并发行。例如《行星环》收录于翻唱曲合辑第八卷，而《爱派Dancehall》《几亿光年》《鹿色时光》与《恶魔之子》等曲目则被收录于翻唱曲合辑第十卷中。这些特殊组合的翻唱不仅展现了角色们多变的声线与音乐表现力，也进一步丰富了整个企划的音乐生态。
