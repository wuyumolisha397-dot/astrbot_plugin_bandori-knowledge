---
title: CORUSCATE -DNA-(单曲)
url: https://zh.moegirl.org.cn/CORUSCATE%20-DNA-%28%E5%8D%95%E6%9B%B2%29
revision: 8531879
updated: '2026-06-28'
categories:
- 2021年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《CORUSCATE -DNA-》是《BanG Dream!》企划组合 RAISE A SUILEN 的第九张单曲，于2022年4月27日发行。该单曲分为附赠 Blu-ray 的生产限定盘与常规盘两种规格，并在企划内首次将翻唱曲作为单曲收录内容。同年4月15日，官方在 YouTube 频道发布了单曲的试听动画。

单曲的初回封入特典包含 BanG Dream! 10th☆LIVE DAY4:SOUL ROAR 以及 RAISE A SUILEN LIVE 2022「OVERKILL」两场演唱会的抽选券，另随机附赠一张成员照片卡。

在收录曲目方面，单曲不仅包含同名主打歌，还收录了曾作为拉斯维加斯合作企划提供的歌曲《Repaint》以及翻唱曲《Light a fire》。限定盘附带的 Blu-ray 光碟则收录了 RAISE A SUILEN ZEPP TOUR 2021 BE LIGHT 东京公演的现场演出影像，完整记录了包括《EXPOSE 'Burn out!!!'》《UNSTOPPABLE》《SOUL SOLDIER》《R･I･O･T》等在内的十三首经典曲目。此外，光碟内还收录了《CORUSCATE -DNA-》与《Repaint》的动画 MV，以及《Light a fire》的真人 MV。

同时，官方还推出了同时购入两种形态的特典 Blu-ray 光碟，其中收录了 BE LIGHT 巡演中名古屋公演与大阪公演的差分曲目。名古屋公演收录了《Beautiful Birthday》与《JUST THE WAY I AM》，大阪公演则收录了《REIGNING》与《Sacred world》两首曲目。
