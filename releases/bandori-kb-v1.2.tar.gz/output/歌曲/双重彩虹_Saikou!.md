---
title: 双重彩虹/Saikou!
url: https://zh.moegirl.org.cn/%E5%8F%8C%E9%87%8D%E5%BD%A9%E8%99%B9%2FSaikou%21
revision: 8542913
updated: '2026-07-01'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

# 双重彩虹/Saikou!

《二重の虹（ダブル レインボウ）/最高（さあ行こう）！》是《BanG Dream!》企划组合Poppin'Party的10th单曲，发售于2018年07月11日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2018年5月15日在YouTube上发布。
初回封入特典为角色卡等。各店铺特典是写真、文件夹、明信片等。

## 试听动画

## 收录曲目

## Blu-ray收录内容

《ティアドロップス》MV
TV动画《BanG Dream!》再放送NCED（ティアドロップス）
ガルパライブ＆ガルパーティ！in東京 Live映像Poppin'Party部分

### Live映像

## 外部链接与注释

试听动画：全碟
（日文）官网CD介绍页
