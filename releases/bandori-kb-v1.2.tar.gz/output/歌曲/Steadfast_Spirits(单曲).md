---
title: Steadfast Spirits(单曲)
url: https://zh.moegirl.org.cn/Steadfast%20Spirits%28%E5%8D%95%E6%9B%B2%29
revision: 8552210
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Steadfast Spirits》是《BanG Dream!》多媒体企划旗下女子摇滚乐队Roselia的第18张单曲，于2025年11月19日正式发行。本作共推出包含Blu-ray的生产限定盘与通常盘两种规格，初回生产特典内附角色卡片一张，以及Roselia与同企划组合Poppin'Party联合演唱会的最速先行抽选券。这场备受期待的联合演唱会预定于2026年5月3日举办，彰显了企划内乐队间的紧密互动。

单曲的Blu-ray部分收录了Roselia此前举办的「Sei stark」专场演唱会完整Live映像。这场演出不仅展现了乐队极高的现场表现力，更汇聚了其音乐生涯中的众多经典曲目。演出曲目涵盖了从早期奠定乐队暗黑交响摇滚风格的《BLACK SHOUT》《Requiem for Fate》，到充满力量与信念的《BRAVE JEWEL》《FIRE BIRD》，再到展现成熟音乐驾驭能力的《ROZEN HORIZON》《ZEAL of proud》等作品。此外，Live映像还收录了《overtuRe》《Break your desire》《Swear ～Night & Day～》《Keep Heart》《Safe and Sound》《一逢のFull Glory》《Dazzle the Destiny》以及安可曲《“UNIONS" Road》，并特别附带了幕间映像的导演剪辑版，为观众呈现了一场极具史诗感与沉浸感的视听盛宴。

作为Roselia在2025年末推出的重要音乐作品，《Steadfast Spirits》不仅延续了乐队一贯的高水准制作与哥特摇滚美学，更通过附带的演唱会影像，记录了成员们不断突破自我的音乐轨迹。单曲的发行与后续联合演唱会的企划，进一步丰富了Roselia的音乐版图，也持续深化了《BanG Dream!》企划中各乐队之间相互交织、共同成长的羁绊。
