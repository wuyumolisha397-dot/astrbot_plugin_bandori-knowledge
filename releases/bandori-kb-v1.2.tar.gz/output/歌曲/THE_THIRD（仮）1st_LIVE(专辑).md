---
title: THE THIRD（仮）1st LIVE(专辑)
url: https://zh.moegirl.org.cn/THE%20THIRD%EF%BC%88%E4%BB%AE%EF%BC%891st%20LIVE%28%E4%B8%93%E8%BE%91%29
revision: 8560545
updated: '2026-06-29'
categories:
- 2018年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题替换的页面
- 现场专辑
---

# THE THIRD（仮）1st LIVE(专辑)

《THE THIRD（仮）1st ライブ》是《BanG Dream!》企划组合RAISE A SUILEN以THE THIRD（仮）名义发行的唯一一张专辑，发售于2018年9月26日。
专辑中收录了2018年3月25日在下北泽GARDEN举办的1st LIVE的歌曲。纺木吏佐当时尚未加入，大冢纱英作为客串吉他手出演。
除了歌曲《R·I·O·T》以外的歌曲都是翻唱《BanG Dream!》其他乐队的歌曲。

## 收录曲目

## 外部链接与注释

（日文）官网CD介绍页
