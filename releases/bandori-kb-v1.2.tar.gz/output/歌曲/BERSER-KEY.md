---
title: BERSER-KEY
url: https://zh.moegirl.org.cn/BERSER-KEY
revision: 8543439
updated: '2026-06-28'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 印象曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

「BERSER-KEY」是《BanG Dream!》企划旗下组合RAISE A SUILEN的原创歌曲，收录于该组合于2023年11月1日发行的首张迷你专辑《REVELATION》中。歌曲的短版MV先行于2023年10月12日发布，并在随后举办的「REVEAL」Live上迎来了首次公开演奏。

作为RAISE A SUILEN的吉他手LOCK的印象曲，该曲在组合的音乐历程中具有特殊意义，它贡献了RAS迄今为止唯一一段LOCK的独唱段落，充分展现了这位角色在音乐表达上的独特魅力与成长。

曲名「BERSER-KEY」蕴含着巧妙的构思与角色关联。该词由「BERSERKER」（狂战士）变形而来，呼应了LOCK在衍生动画《BanG Dream! 少女乐团派对！☆PICO》第二季中获得的「吉他狂战士」这一称号；而后半部分的「KEY」（钥匙）则与LOCK（锁）在字面上形成对应，暗含着解锁与释放的意味。此外，歌词中提及的「一番星」，被认为可能指代角色户山香澄，她宛如白月光般存在于相关角色的过往经历中，为歌曲增添了更深层的情感羁绊与叙事维度。

整首歌曲通过精心的词曲编排与成员间的演唱分配，不仅强化了LOCK在乐队中的核心印记，也进一步丰满了RAISE A SUILEN整体的乐队风貌与故事脉络。
