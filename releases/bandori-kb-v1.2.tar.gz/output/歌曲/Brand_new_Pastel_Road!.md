---
title: Brand new Pastel Road!
url: https://zh.moegirl.org.cn/Brand%20new%20Pastel%20Road%21
revision: 8545116
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 秦佐和子歌曲
---

《Brand new Pastel Road!》是《BanG Dream!》企划旗下女子乐队Pastel*Palettes演唱的一首歌曲。该曲作为企划内“Garupa Station”4.5周年特别节目上公开的第四首联动商业合作曲（Tie-up曲）与观众正式见面。歌曲的完整版音频于2022年3月26日率先开启数字音乐配信，随后被正式收录至Pastel*Palettes的第二张音乐专辑《Pastel à la mode》的Disc1中，该实体专辑于2023年5月31日全面发售。

Pastel*Palettes是由主唱丸山彩、吉他手冰川日菜、贝斯手白鹭千圣、键盘手大和麻弥以及鼓手若宫伊芙五名成员组成的偶像气质女子乐队。这首《Brand new Pastel Road!》作为乐队发展后期的核心代表作品之一，不仅延续了该组合一贯色彩缤纷、充满青春活力的流行摇滚曲风，更通过五名成员各具特色的声线交织，完美展现了团队在音乐表现力上的成长与默契。歌曲的演绎涵盖了全员合唱与各成员的独立段落，充分凸显了每位角色的音乐个性与团队凝聚力。

作为一首在企划重要节点发布的特别曲目，该曲承载了Pastel*Palettes在音乐道路上不断前行的全新愿景。无论是充满元气的旋律编排，还是积极向上的情感表达，都与乐队“向更多人传递闪耀光芒”的核心理念高度契合。凭借极具感染力的节奏与高质量的录制水准，《Brand new Pastel Road!》在发布后迅速获得了广大听众与企划粉丝的喜爱，成为了Pastel*Palettes音乐历程中一首极具标志性的优秀作品。
