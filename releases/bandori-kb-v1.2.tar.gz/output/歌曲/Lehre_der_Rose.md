---
title: Lehre der Rose
url: https://zh.moegirl.org.cn/Lehre%20der%20Rose
revision: 8557395
updated: '2026-06-28'
categories:
- 2026年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

《Lehre der Rose》是《BanG Dream!》企划旗下组合Roselia的十周年精选专辑，于2026年8月26日正式发售。该专辑共分为数量限定生产特装盘、Blu-ray付生产限定盘和通常盘三种规格。

专辑共收录了24首Roselia的原创歌曲。其中，有10首曲目是通过2026年2月至3月在Roselia十周年特设网站上举办的粉丝投票活动选拔而出。此外，《BLACK SHOUT》《FIRE BIRD》《PASSIONATE ANTHEM》《陽だまりロードナイト》《礎の花冠》以及《VIOLET LINE》这六首经典歌曲，均特别采用了十周年现场演出的实况音源版本。

在实体规格与特典方面，各版本均附赠2027年Roselia专场演唱会的最速先行抽选券以及随机一款共6种的角色卡片。数量限定生产特装盘仅在Roselia演唱会现场及武士道在线商店发售，内含特制三边盒套、高箱尺寸内封、纪念手册，并额外附赠特制双陆棋套装、纪念盒以及亚洲巡演“Neuweltfahrt”的专属旗帜。Blu-ray付生产限定盘则配有特制纸套。

该专辑的影像内容极其丰富，主要收录了Roselia亚洲巡演“Neuweltfahrt”大阪、东京、新加坡、首尔、台北等多站的高清现场演出影像及定点机位画面，并包含东京最终公演的两日完整Live影像，以及巡演期间拍摄的幕后趣味短剧。

为庆祝专辑发行，官方于2026年8月29日至30日举办了专门的发售纪念演唱会，与粉丝共同庆祝Roselia出道十周年的辉煌历程。
