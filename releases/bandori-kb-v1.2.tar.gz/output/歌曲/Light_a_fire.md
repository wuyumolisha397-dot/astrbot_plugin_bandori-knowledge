---
title: Light a fire
url: https://zh.moegirl.org.cn/Light%20a%20fire
revision: 8545652
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

《Light a fire》是《BanG Dream!》企划中女子乐队 RAISE A SUILEN 的原创歌曲。该曲于"OVERKILL"现场首次公开演奏，音乐视频于 2022 年 3 月 23 日发布，这也是 RAISE A SUILEN 自出道以来的首支真人 MV。完整版音源随后收录于 2022 年 4 月 27 日发行的第九张单曲《CORUSCATE -DNA-》中。

RAISE A SUILEN 是一支以强劲现场表现力和电子摇滚风格著称的乐队，成员包括主唱 LAYER、吉他手 LOCK、贝斯手 MASKING、键盘手 PAREO 以及队长兼制作人 CHU²。乐队在《BanG Dream!》企划中以充满攻击性的音乐风格和高度完成度的舞台演出著称，作品多融合摇滚与电子元素，强调节奏感与能量释放。

《Light a fire》延续了 RAISE A SUILEN 一贯的硬朗曲风，歌曲节奏鲜明，旋律富有张力，展现出乐队在音乐创作上的成熟与自信。作为首支真人 MV 作品，该曲的视觉呈现也进一步强化了乐队的整体形象，成员在 MV 中以真实面貌登场，配合高强度的演奏与表演，呈现出与动画风格不同的现场质感。

该曲自首次演出以来便受到听众关注，现场版本与录音室版本均获得较高评价。歌曲收录于单曲《CORUSCATE -DNA-》后，成为 RAISE A SUILEN 音乐作品序列中的重要一环，也常被列入乐队后续演出的曲目列表中。
