---
title: Dreamers Go!/Returns
url: https://zh.moegirl.org.cn/Dreamers%20Go%21%2FReturns
revision: 8540382
updated: '2026-07-01'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

《Dreamers Go!/Returns》是《BanG Dream!》多媒体企划中组合Poppin'Party的第14张单曲，于2019年5月15日正式发售。该单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格，初回生产特典为随机封入的角色卡片一张。

作为Poppin'Party在企划发展期的重要音乐作品，这张单曲承载了乐队成长与羁绊加深的主题。Poppin'Party由主唱兼吉他手户山香澄领衔，是以积极向上的流行摇滚风格为核心的少女乐队。单曲同名主打曲《Dreamers Go!》与《Returns》紧扣追逐梦想与回归初心的情感脉络，展现了成员们在经历迷茫与挑战后，依然坚定迈向未来、用音乐相互连结的信念。歌曲充满活力的旋律与真挚的歌词，生动刻画了少女们对舞台的渴望以及对同伴的信赖，是乐队精神内核的集中体现。

单曲的Blu-ray光盘收录了电视动画《BanG Dream! 2nd Season》的第1话与第2话正片，并附带Web版下集预告及Poppin'Party篇电视广告等影像特典。在动画第二季的剧情背景下，Poppin'Party面临着重组与自我突破的考验，而这张单曲的音乐表达恰好与动画中她们跨越瓶颈、重燃热情的故事线相呼应。作品不仅记录了乐队在音乐道路上的关键蜕变，也进一步巩固了Poppin'Party在企划中作为梦想开拓者的核心地位，深受粉丝群体的喜爱与共鸣。
