---
title: FIRE BIRD
url: https://zh.moegirl.org.cn/FIRE%20BIRD
revision: 8561424
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 插曲
- 日本音乐作品
- 樱川惠歌曲
- 相羽爱奈歌曲
---

《FIRE BIRD》是《BanG Dream!》企划中乐队Roselia的第九张单曲主打曲，于2019年7月24日发售，同时作为插曲应用于TV动画《BanG Dream! 2nd Season》第13话。游戏版为志崎桦音加入Roselia后首次参与录制的版本，动画版则由明坂聪美参与录制。

该曲由上松范康负责作词与作曲。上松在访谈中表示，创作初衷是记录Roselia两年半的真实成长轨迹，使其成为Roselia少有的以现实经历为出发点的歌曲。上松曾称此曲是“为BanG Dream!赌上人生的一曲”。由于上松为该企划作词极为罕见，动画ED名单与官方配信预告一度将作词者误记为织田あすか。该曲曾作为第十四届声优奖歌唱赏颁奖仪式的背景音乐，并收录于Roselia十周年精选专辑《Lehre der Rose》的十周年实演重录版本中。

在演出方面，Poppin'Party曾在Roselia的8th LIVE DAY3翻唱此曲，9th LIVE时实现两团合唱。在「Rosenchor」东京公演DAY2中，因麦克风故障引发收音问题，第二段副歌意外促成了与台下观众的大合唱。

该曲在《BanG Dream! 少女乐团派对！》中具有极高挑战性。短版Expert难度标级为27，包含大量绿白键交替与高密度连打，因配信延期曾被戏称为“火鸽子”。Special难度标级为29，物量达1111。Full Expert难度长达5分22秒，物量极高，尾杀的18连长移位交互接红键极具挑战性。该谱面曾长期位居游戏全曲FC难度第一位，诞生40分钟内即被玩家带MV攻略，次日出现单手FC纪录。

此外，该曲曾作为联动曲目收录于街机音游CHUNITHM，其WORLD'S END谱面还原了手游本家谱面配置。2025年12月，该曲作为联动内容收录于《Link！Like！LoveLive!》应用中。
