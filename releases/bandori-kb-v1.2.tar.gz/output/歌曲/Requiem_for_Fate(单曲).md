---
title: Requiem for Fate(单曲)
url: https://zh.moegirl.org.cn/Requiem%20for%20Fate%28%E5%8D%95%E6%9B%B2%29
revision: 8462481
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Requiem for Fate》是《BanG Dream!》企划旗下组合Roselia的第17张单曲，于2025年6月26日正式发售。该单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格，初回生产特典包含Roselia亚洲巡演“Neuweltfahrt”的最速先行抽选券、单曲购买者限定免费演唱会“Stolz”的抽选券，以及随机一款共五种样式的角色卡片。此外，若在特定实体或电子商店将本单曲与《Dazzle the Destiny》一并购买，还可获赠限量收纳盒。

单曲的Blu-ray光盘收录了Roselia“Stille Nacht, Rosen Nacht”上海追加公演的现场演出影像及幕后花絮。这场演出呈现了乐队多首经典曲目，包括《Sage der Rosen》《Song I am.》《THE HISTORIC...》《Determination Symphony》《FIRE BIRD》《約束》《礎の花冠》《Neo-Aspect》《Re:birth day》《熱色スターマイン》以及《PASSIONATE ANTHEM》等。演出安可环节则带来了《Our Carol》《ONENESS》与《BLACK SHOUT》三首歌曲。此外，影像中还穿插了《角色设定不可崩！》日本列岛争夺战5人合作圣诞特别篇的幕间映像，为整场演出增添了趣味互动。
