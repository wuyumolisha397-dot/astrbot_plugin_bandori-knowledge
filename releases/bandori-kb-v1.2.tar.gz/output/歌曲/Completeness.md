---
title: Completeness
url: https://zh.moegirl.org.cn/Completeness
revision: 8542119
updated: '2026-06-28'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

《Completeness》是《BanG Dream!》企划旗下组合Ave Mujica的第一张音乐专辑，于2025年4月23日正式发行。作为该神秘风格乐队的重要音乐作品，本专辑共收录了《KiLLKiSS》《Georgette Me, Georgette You》《Imprisoned XII》《Crucifix X》《八芒星舞蹈》《颜》以及《天球的Música》等核心曲目，全面展现了Ave Mujica独特的戏剧化摇滚魅力。

专辑在发行时提供了丰富的规格与特典供听众选择，分为限量五千枚的生产特装盘、附赠Blu-ray的生产限定盘以及通常盘三种版本。其中，五千枚限定特装盘采用豪华包装，内含特殊亚克力立牌与动画同款挂饰，仅在武士道在线商店独家限量销售。实体专辑的初回限定封入特典包含了Ave Mujica第六场演唱会的最速先行抽选申请券以及角色卡片。此外，听众在特定渠道购买专辑还可获赠包含第四场演唱会现场曲目的特典CD，若与同企划组合MyGO!!!!!的实体单曲合并购买，还能额外获得CRYCHIC纪念色纸。

除了丰富的音乐与实体内容，部分版本的专辑还附带了Blu-ray光盘，盘中完整收录了Ave Mujica第四场演唱会「Adventus」的精彩Live影像，影像涵盖了《黑色的生日》《神明，笨蛋》《Ave Mujica》《Angles》《Ether》等众多经典曲目，为听众还原了极具张力的现场表演。

为了庆祝专辑的顺利发售，官方于2025年6月至8月期间在日本各地举办了系列发售纪念握手会，与广大粉丝进行近距离互动。此外，为满足黑胶唱片爱好者的收藏需求，该专辑的完全生产限定盘黑胶唱片版本也定于2026年5月20日推出。
