---
title: Cutie～Mighty*flower
url: https://zh.moegirl.org.cn/Cutie%EF%BD%9EMighty%2Aflower
revision: 8543340
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 仓知玲凤歌曲
- 前岛亚美歌曲
- 夏芽歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 秦佐和子歌曲
- 西本里美歌曲
---

《Cutie～Mighty*flower》（日文名：きゅ～まい＊flower）是《BanG Dream!》企划中 Pastel*Palettes 组合的第五张单曲主打歌，于2019年9月18日正式发售。这首作品同时也是 TV 动画《BanG Dream! 2nd Season》第13话的插曲，在剧情中为乐队的重要演出场景增添了活力与感染力。

除了 Pastel*Palettes 的原版之外，这首歌曲还有一个特别的平行演唱版本，由“スキを貫け♡”（坚持所爱♡）这一临时组合演绎，成员包括牛込里美（CV.西本里美）、大和麻弥（CV.中上育实）、MASKING（CV.夏芽）与 PAREO（CV.仓知玲凤）。该版本于2026年1月4日在各音乐平台上线配信，为听众带来了不同于原版的全新视听体验。

在手机游戏《BanG Dream! 少女乐团派对！》中，这首歌曲以较高的难度配置受到玩家关注。游戏日服于2026年1月3日追加了 SPECIAL 难度谱面，其 EXPERT 难度被评定为26级中上位。谱面整体节奏紧凑，歌曲 BPM 在 Pastel*Palettes 原创曲中位居第二，仅次于《SURVIVOR Never Give Up!》。谱面中融合了高强度的交互按键、复杂的滑条以及多种红键配置，虽然局部看似简单，但综合起来对玩家的连击稳定性提出了较高要求。此外，该曲的完整版 EXPERT 难度时长为3分37秒，是当时游戏内完整版谱面中最短的一首，整体处于27级下位水平，适合具备一定耐力的玩家挑战。平行版本的谱面则与原版保持完全一致。

作为 Pastel*Palettes 的代表作之一，《Cutie～Mighty*flower》不仅展现了乐队一贯的明亮可爱风格，也在企划跨媒体展开中留下了令人印象深刻的舞台印记。
