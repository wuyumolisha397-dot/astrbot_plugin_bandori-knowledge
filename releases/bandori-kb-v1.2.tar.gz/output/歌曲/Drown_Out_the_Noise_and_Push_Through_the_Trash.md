---
title: Drown Out the Noise and Push Through the Trash
url: https://zh.moegirl.org.cn/Drown%20Out%20the%20Noise%20and%20Push%20Through%20the%20Trash
revision: 8547367
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Fear, and Loathing in Las Vegas歌曲
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

「Drown Out the Noise and Push Through the Trash」是《BanG Dream!》企划旗下乐队RAISE A SUILEN与日本电子摇滚乐队Fear, and Loathing in Las Vegas合作的歌曲。这也是Fear, and Loathing in Las Vegas为RAISE A SUILEN提供的第二首曲目，两首乐队分别录制了各自的版本。RAISE A SUILEN版收录于2025年11月12日发行的第14张单曲《'FIGHT' ADDICT》中，而Fear, and Loathing in Las Vegas版则收录于2026年5月20日发行的第八张专辑《StandBy》中。

本曲的主题聚焦于网络环境，意在将社交平台上不负责任的言论视为“噪音”并将其彻底消除。由于歌词含有未和谐的不适当内容，该曲在流媒体平台被标注为Explicit，成为《BanG Dream!》企划中首首获得E标认证的原创歌曲。此外，过长的英文标题对日语使用者而言颇具挑战，RAISE A SUILEN主唱Raychell在宣读曲名时也曾出现咬舌的趣事。

在编曲方面，相较于首次合作的《Repaint》，Fear, and Loathing in Las Vegas此次并未进行重编曲，而是沿用了RAS版的编曲框架。不过，听众依然能从细节中辨别出两版差异，例如FaLiLV标志性的金属质感鼓组音色，以及两者在特定歌词断句处理上的不同。

在演出经历上，该曲在同名演唱会「Drown Out the Noise」上首次亮相，随后在2026年的MEGA VEGAS音乐节上，RAISE A SUILEN与Fear, and Loathing in Las Vegas实现了同台合唱。在《BanG Dream! 少女乐团派对！》游戏中，本曲的专家难度谱面物量达1140，虽然整体配置相对平缓，但前段的弓形绿条与副歌前的短条交互仍具备一定挑战性。
