---
title: Feathered Dreams(单曲)
url: https://zh.moegirl.org.cn/Feathered%20Dreams%28%E5%8D%95%E6%9B%B2%29
revision: 8461198
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Feathered Dreams》是《BanG Dream!》企划旗下组合Morfonica的第八张单曲，于2025年8月27日正式发售。本作分为附赠Blu-ray的生产限定盘与通常盘两种规格。生产限定盘不仅附带限量特制透明盒套与二十四页图片小册子，初回封入特典还包含了Morfonica五周年纪念演唱会「Maestoso」的最速先行抽选申请券、随机角色卡片，以及《卡片战斗先导者》PR卡。为庆祝单曲发行，官方于同年八至九月间在日本多地举办了线上签名会、一日店长巡游及特殊谈话会等丰富的发售纪念活动。

在音乐与影像内容方面，单曲Blu-ray收录了Morfonica专场演唱会「Rubato」的完整影像，并附带幕后花絮与广告影像。这场演出汇聚了组合的多首代表曲目，涵盖了《flame of hope》《Daylight》《Sonorous》《Tempest》等经典作品，同时也收录了《Wreath of Brave》《誓いのWingbeat》《両翼のBrilliance》《One step at a time》《カラフルリバティー》等展现乐队多元风格的音乐，以及《ハーモニー・デイ》《Polyphonyscape》等安可曲目，充分展现了Morfonica在弦乐与摇滚交织下的独特音乐魅力与扎实的现场表演实力。
