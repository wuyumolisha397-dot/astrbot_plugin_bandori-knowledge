---
title: BanG Dream!额外歌曲
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E9%A2%9D%E5%A4%96%E6%AD%8C%E6%9B%B2
revision: 8538796
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《BanG Dream! 少女乐团派对！》中的“额外歌曲”是乐队企划《BanG Dream!》手游内推出的一类特殊翻唱合作曲目。该系列打破了常规翻唱曲仅由游戏内乐队演绎的模式，邀请《BanG Dream!》旗下的各支乐队与外部知名歌手、虚拟主播及经典企划角色进行跨次元合唱，具有极高的话题度与纪念意义。

该系列曲目涵盖了极为广泛的合作对象与音乐风格。在知名歌手合作方面，Poppin'Party与铃木木乃美合唱了《樱花庄的宠物女孩》片尾曲《DAYS of DASH》；Hello, Happy World!与Machico共同演绎了《为美好的世界献上祝福！第二季》片头曲《TOMORROW》；Afterglow与FLOW合作了《CODE GEASS 叛逆的鲁鲁修》经典名曲《COLORS》；Roselia与伊藤香奈子合唱了《命运石之门》主题曲《天空覆层的观测者》；Pastel*Palettes与ClariS合作了《埃罗芒阿老师》片头曲《自言自语》；Morfonica与fhána带来了《小林家的龙女仆》片头曲《青空狂想曲》；RAISE A SUILEN则与MYTH & ROID合唱了《OVERLORD》片头曲《VORACITY》。此外，Afterglow还与知名唱见96猫合作了V家名曲《Phony》，Roselia与+α/某不思议合唱了VOCALOID传说曲《转生苹果》。

在与虚拟主播及经典IP的联动中，该系列同样大放异彩。Pastel*Palettes与凑阿库娅合唱了《Fan service》，Hello, Happy World!与白上吹雪合作了《Blend·S》片头曲《Buonappetito♡S》。Poppin'Party与P丸样。接连合作了《如果我成为大统领》与《少女是心理变态》两首曲目。Roselia更是集结了萝卜子、常暗永远与沙花叉克萝耶共同演绎了《蔷薇少女》经典主题曲《圣少女领域》。此外，RAISE A SUILEN与星街彗星合作了《Stellar Stellar》，Morfonica与雪花莉莉合唱了《Fleur》，Afterglow与宝钟玛琳合作了《Ahoy 我们是宝钟海贼团》，MyGO!!!!!与狮白牡丹合作了《Lioness' Pride》。

除了跨次元合作，该系列也包含与三丽鸥及经典流行歌手的联动。Poppin'Party与Hello Kitty合唱了生物股长的名曲《Joyful》，Pastel*Palettes则与美乐蒂合作翻唱了松浦亚弥的经典曲目《桃色单恋》。

2023年9月6日发行的专辑《BanG Dream! 少女乐团派对！翻唱合集 Vol.8》第二张碟片，集中收录了上述多首合作曲目的游戏内乐队独唱版本。需要注意的是，因版权及合作方属性等原因，部分涉及虚拟主播或特定外部角色的合作曲目未在游戏国服实装。
