---
title: Harmony Day(单曲)
url: https://zh.moegirl.org.cn/Harmony%20Day%28%E5%8D%95%E6%9B%B2%29
revision: 8461208
updated: '2026-06-28'
categories:
- 2021年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Harmony Day》（日文标题《ハーモニー・デイ》）是《BanG Dream!》多媒体企划旗下女子摇滚乐队Morfonica的第三张单曲，于2021年10月6日正式发行。该单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格发售。在实体唱片上市前夕，官方于2021年9月15日在YouTube平台上发布了单曲的试听动画，让听众提前感受新作的视听魅力。

作为一支以小提琴与摇滚乐队编制相融合为特色的组合，Morfonica在这张单曲中延续了一贯的奇幻与华丽风格，展现了成员们不断进化的音乐表现力。同名主打曲《Harmony Day》不仅彰显了乐队深厚的古典底蕴与充满活力的流行摇滚基底，更通过主唱清澈且富有穿透力的嗓音，以及小提琴与吉他交织的旋律，传递出少女们在成长道路上的细腻情感与坚定信念。

单曲的Blu-ray部分收录了极为丰富的现场演出影像，具有极高的收藏价值。影像内容主要涵盖了Morfonica参与“BanG Dream! 8th☆LIVE”夏日野外三天巡演第三日“Special Live ～Summerly Tone♪～”的专属演出段落。在这场演出中，乐队倾情演绎了《Daylight -デイライト-》《chAngE》《メリッサ》《金色へのプレリュード》以及《ブルームブルーム》等多首代表曲目。

此外，Blu-ray还完整收录了Morfonica的首场专场演唱会“1st Live「Cantabile」”的实况影像。在这场意义非凡的演出中，乐队不仅演绎了自身的原创经典作品，如《月光花》《深海少女》《Nevereverland》《CQCQ》与《flame of hope》等，更在安可环节再次引爆全场热情。整张单曲不仅是Morfonica音乐历程的重要记录，也充分展现了她们在舞台上极具感染力的表演风采。
