---
title: '''FIGHT'' ADDICT(单曲)'
url: https://zh.moegirl.org.cn/%27FIGHT%27%20ADDICT%28%E5%8D%95%E6%9B%B2%29
revision: 8531876
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《'FIGHT' ADDICT》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的第14张单曲，于2025年11月12日发售。单曲以Blu-ray付生产限定盘和通常盘两种形式发行，初回生产批次均封入多项特典，包括RAISE A SUILEN LIVE 2026「Boot IGNITION」最速先行抽选申请券、随机一张角色卡片（全5种），以及一张《卡片战斗先导者》PR卡。

本单曲为RAISE A SUILEN延续其标志性硬朗摇滚风格的作品，标题中的“FIGHT”与“ADDICT”呼应了乐队一贯的激昂与战斗意志。Blu-ray付生产限定盘额外收录了RAISE A SUILEN LIVE 2025「REBEL SOUNDWAVE」的完整演唱会映像，使乐迷能够在聆听新曲的同时重温现场演出的热烈氛围。

作为乐队第十四张单曲，《'FIGHT' ADDICT》在发行周期上衔接了前作，并与《卡片战斗先导者》展开联动合作，进一步拓展了跨媒体企划的受众。单曲中的角色卡片涵盖RAISE A SUILEN五位成员——LAYER、LOCK、MASKING、PAREO、CHU²，体现了乐队全员的个性形象。此外，附赠的LIVE抽选券也为即将于2026年举办的「Boot IGNITION」演唱会提前造势，展现了RAISE A SUILEN持续活跃的演出节奏。

整体而言，《'FIGHT' ADDICT》不仅是RAISE A SUILEN音乐创作的一次新节点，也是其现场活动与跨界合作的重要载体，承载着乐队粉丝对后续演出的期待。
