---
title: VIOLET LINE(单曲)
url: https://zh.moegirl.org.cn/VIOLET%20LINE%28%E5%8D%95%E6%9B%B2%29
revision: 8462508
updated: '2026-06-28'
categories:
- 2023年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
---

# VIOLET LINE(单曲)

《VIOLET LINE》是《BanG Dream!》企划组合Roselia的14th单曲，发售于2023年12月13日。分为Blu-ray付生产限定盘、凑友希那Ver.、冰川纱夜Ver.、今井莉莎Ver.、宇田川亚子Ver.与白金燐子Ver.六种规格。
试听动画于2023年12月7日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：一张Roselia LIVE TOUR「Rosenchor」的抽选券，以及一张对应版本的角色卡片。

## 试听动画

## 收录曲目

## Blu-ray收录内容

## 外部链接

（日文）官网CD介绍页
