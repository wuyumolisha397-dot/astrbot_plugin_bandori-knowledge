---
title: CiRCLING
url: https://zh.moegirl.org.cn/CiRCLING
revision: 8542668
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 日本音乐作品
- 爱美歌曲
- 西本里美歌曲
---

《CiRCLING》是《BanG Dream!》企划旗下组合Poppin'Party的第九张同名主打单曲，于2018年3月21日正式发行。该曲由乐队五位成员户山香澄、花园多惠、牛込里美、山吹沙绫与市谷有咲共同演唱，展现了Poppin'Party一贯充满活力的流行摇滚风格。

作为Poppin'Party的代表作之一，《CiRCLING》在企划内具有重要地位。2021年上映的《BanG Dream! FILM LIVE 2nd Stage》中，该曲被选为安可曲，并由七个乐团共35名成员共同合唱，成为企划史上规模最大的合作演出之一。

在《BanG Dream! 少女乐团派对！》手游中，《CiRCLING》作为第三十期活动"Fun Fun Circling Fivestar"的配信曲目登场，同时也是该期对邦活动的指定曲目。游戏谱面设计颇具特色，Hard与EX难度均出现了标志性的圆形绿条，这一设计源自BanG Dream!本家的玩梗元素。其中Hard难度被评为18级中最具挑战性的谱面之一，全连难度甚至超过部分20级曲目；EX难度则因25级的标定与实际难度存在差异，被玩家认为具有"诈称"特征。

2018年12月，《CiRCLING》作为SEGA街机音游《音击》与BanG Dream!手游第二波联动曲目上线。游戏谱面保留了原版的圆形长条设计，但操作方式适配了街机平台的按键系统。由于授权到期，该曲于2021年7月8日从《音击》RED Plus版本中下架。

《CiRCLING》以其鲜明的旋律特色和富有挑战性的谱面设计，成为Poppin'Party音乐作品中的重要一环，在BanG Dream!企划的多媒体展开中持续发挥着影响力。
