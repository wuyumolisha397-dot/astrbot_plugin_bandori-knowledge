---
title: 梦幻战队MuType1
url: https://zh.moegirl.org.cn/%E6%A2%A6%E5%B9%BB%E6%88%98%E9%98%9FMuType1
revision: 8457831
updated: '2026-06-28'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# 梦幻战队MuType1

《夢幻戦隊むーたいぷ１》是《BanG Dream!》旗下虚拟Youtuber组合梦限大MewType的第一张翻唱数字迷你专辑（デビューカバーデジタルEP），于2025年4月2日网络发布。
BanG Dream! 官网关于本EP的演唱名义写的是夢限大みゅーたいぷ，但音乐平台标注的演唱名义为夢幻戦隊むーたいぷ。

## 收录曲目

## 外部链接

（日文）官网EP介绍页
