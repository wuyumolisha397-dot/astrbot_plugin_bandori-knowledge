---
title: BanG Dream! 翻唱曲合辑 Extra Volume
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91%20Extra%20Volume
revision: 8440574
updated: '2026-06-30'
categories:
- 2024年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 翻唱专辑
---

《BanG Dream! 翻唱曲合辑 Extra Volume》是《BanG Dream!》多媒体企划于2024年7月10日推出的一张特别翻唱音乐专辑。专辑分为附带蓝光光盘的生产限定盘与通常盘两种规格发售。

这张合辑的核心内容聚焦于企划中极具人气的两支乐队：MyGO!!!!!与Ave Mujica。专辑内共收录了六首翻唱歌曲，两支乐队各占三首。值得一提的是，由于在专辑发售之初，Ave Mujica的三首翻唱曲目尚未在相关的移动端音乐手游中实装上线，因此这张专辑打破了以往以游戏名义发行的惯例，改为直接以《BanG Dream!》企划的名义进行官方发售。这一特殊的发行背景，也使得该专辑在企划的音乐发行史中具有独特的收藏意义。

在实体专辑的附赠内容方面，购买初回生产限定盘的消费者可以获得多项 exclusive 特典。其中包括一张MyGO!!!!!专属线下活动《MyGO!!!!!的“迷子集会”出差版 第二弹 - 日常的碎片 -》的最速先行抽选申请券，以及Ave Mujica第三次与第四次专场演唱会的最速先行门票抽选券。此外，专辑还随附了一张精美的CD封面图案专属贴纸。

除了音乐CD外，生产限定盘附带的蓝光光盘更是收录了极具价值的现场演出影像。该影像源自Roselia乐队的专场演唱会「Farbe」，完整呈现了演出当天的开场嘉宾舞台。在Day1的演出中，MyGO!!!!!作为嘉宾热血登台，演绎了《影色舞》、《碧天伴走》、《壱雫空》三首曲目；而在Day2的舞台上，Ave Mujica则带来了充满神秘与戏剧张力的表演，演出了《Ave Mujica》、《神さま、バカ》以及《Mas?uerade Rhapsody Re?uest》。这张专辑不仅是MyGO!!!!!与Ave Mujica音乐魅力的集中展现，更是《BanG Dream!》企划中跨乐队深厚羁绊与同台竞技的完美记录。
