---
title: SAVAGE
url: https://zh.moegirl.org.cn/SAVAGE
revision: 8528984
updated: '2026-06-28'
categories:
- 2024年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

《SAVAGE》是《BanG Dream!》企划旗下女子摇滚乐队 RAISE A SUILEN 的第二张录音室专辑，于 2024 年 6 月 12 日正式发行。这张专辑延续了该乐队一贯强烈的摇滚与电子舞曲相结合的音乐风格，展现了她们极具爆发力与侵略性的舞台魅力。

专辑在发售规格上分为附赠 Blu-ray 的生产限定盘与通常盘两种版本。在音乐内容方面，《SAVAGE》共收录了十二首曲目。除了包含五首全新创作的歌曲之外，还悉数收录了乐队此前发布的数首热门数字单曲及实体单曲的主打歌，其中包括《Sacred world》《mind of Prominence》《EXIST》《Domination to world》《THE WAY OF LIFE》《CORUSCATE -DNA-》以及《-N-E-M-E-S-I-S-》等代表作品。这些歌曲不仅见证了 RAISE A SUILEN 的音乐成长轨迹，也进一步巩固了她们在乐队摇滚与流行电子跨界领域的独特定位。

在实体盘的附加内容上，生产限定盘附带的 Blu-ray 光碟完整收录了乐队此前举办的“BanG Dream! 12th☆LIVE DAY3:REVEAL”演唱会高清Live映像。这场演出涵盖了《Apocalypse》《EXPOSE ‘Burn out!!!’》《JUST THE WAY I AM》《Invincible Fighter》《HELL! or HELL?》《A DECLARATION OF ×××》《DRIVE US CRAZY》《R·I·O·T》《UNSTOPPABLE》以及《POLARIS》等经典曲目。此外，蓝光光碟中还特别加入了演唱会现场的成员对焦镜头特典影像，分别记录了主唱 LAYER、吉他手 LOCK、贝斯手 MASKING、键盘手 CHU² 以及鼓手 PAREO 在舞台上的专属演出视角，为粉丝提供了沉浸式的视听体验。

实体专辑的初回封入特典还包含了巡演“RAISE A SUILEN ZEPP TOUR 2024-2025「PANDEMONIUM」”的最速先行抽选申请券。购买限定盘的粉丝还可以获得一张全息封面图贴纸，而通常盘则随机附赠五款单角色贴纸中的一款。整体而言，《SAVAGE》不仅是一张音乐作品集，更是 RAISE A SUILEN 展现其强悍现场表现力与独特乐队美学的重要里程碑。
