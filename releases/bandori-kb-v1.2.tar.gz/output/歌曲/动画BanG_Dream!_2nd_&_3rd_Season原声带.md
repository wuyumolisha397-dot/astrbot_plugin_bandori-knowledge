---
title: 动画BanG Dream! 2nd & 3rd Season原声带
url: https://zh.moegirl.org.cn/%E5%8A%A8%E7%94%BBBanG%20Dream%21%202nd%20%26%203rd%20Season%E5%8E%9F%E5%A3%B0%E5%B8%A6
revision: 8547497
updated: '2026-06-30'
categories:
- BanG Dream!音乐唱片
- 原声带
---

# 动画BanG Dream! 2nd & 3rd Season原声带

《アニメ「BanG Dream! 2nd＆3rd Season」オリジナル・サウンドトラック》是TV动画《BanG Dream!第二季》和《BanG Dream!第三季》的原声带，发售于2020年4月8日。宣传CM于2020年3月8日在YouTube上发布。
收录有动画OP《キズナミュージック♪》、《BRAVE JEWEL》、《イニシャル》与ED《Safe and Sound》、《Jumpin'》、《夢を撃ち抜く瞬間に！》的TV Size版本。
除此之外还收录了大冢纱英演唱的《Returns》版本、大冢纱英×Raychell演唱的《ナカナ イナ カナイ》、RAISE A SUILEN演唱的《Beautiful Birthday》等插曲与BGM。

## 宣传CM

## 收录曲目

## Blu-ray内容

动画《BanG Dream! 3rd Season》 #12~#13
BanG Dream! TV 特别篇#7

## 外部链接与注释

宣传CM
（日文）官网CD介绍页
