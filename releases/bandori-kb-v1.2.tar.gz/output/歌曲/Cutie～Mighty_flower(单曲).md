---
title: Cutie～Mighty*flower(单曲)
url: https://zh.moegirl.org.cn/Cutie%EF%BD%9EMighty%2Aflower%28%E5%8D%95%E6%9B%B2%29
revision: 8557381
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Cutie～Mighty*flower》（日文名《きゅ～まい＊flower》）是《BanG Dream!》企划旗下女子乐队组合 Pastel*Palettes 的第五张单曲，于2019年9月18日正式发售。Pastel*Palettes 是一支由主唱丸山彩、吉他手若宫伊芙、贝斯手花园多惠、键盘手市谷有咲以及鼓手大和麻弥组成的偶像乐队，该单曲是她们在音乐历程中的重要作品之一。

这张单曲在发行时分为附赠 Blu-ray 的生产限定盘与通常盘两种规格。为了满足粉丝的期待，官方提前于2019年4月25日在 YouTube 平台上发布了单曲的试听动画。此外，单曲的初回封入特典还附带了 Pastel*Palettes 特别公演的抽选申请券，为粉丝提供了参与线下专属演出的机会。

在收录内容方面，除了音乐曲目外，生产限定盘附带的 Blu-ray 光盘收录了丰富的影像资料。其中包括电视动画《BanG Dream! 2nd Season》第九集与第十集的正片内容，以及这两集对应的 Web 版下回预告。同时，光盘内还特别收录了《BanG Dream! 2nd Season》中 Pastel*Palettes 篇的宣传广告，极具收藏价值。

作为 Pastel*Palettes 的第五张单曲，《Cutie～Mighty*flower》不仅延续了组合一贯充满活力与色彩的偶像流行摇滚风格，也展现了成员们在企划发展过程中的成长。配合动画第二季的播出，这首单曲进一步丰富了组合的背景故事，是 Pastel*Palettes 音乐作品库中不可或缺的代表作。
