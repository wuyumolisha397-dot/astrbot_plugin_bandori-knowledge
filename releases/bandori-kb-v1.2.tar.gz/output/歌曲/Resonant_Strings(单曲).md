---
title: Resonant Strings(单曲)
url: https://zh.moegirl.org.cn/Resonant%20Strings%28%E5%8D%95%E6%9B%B2%29
revision: 8466832
updated: '2026-06-28'
categories:
- 2026年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Resonant Strings》是《BanG Dream!》企划旗下组合Morfonica的第九张单曲，于2026年4月22日正式发售。该单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格。初回生产限定盘配备了特制三面透明封套及24页的图片小册子，初回封入特典则包含Morfonica演唱会「Movement」的最速先行抽选申请券，以及随机一张共六款的角色卡片。

单曲的Blu-ray部分收录了《Morfonica 5th Anniversary LIVE「Maestoso」》的演唱会影像及幕后制作花絮。这场五周年纪念演出汇聚了Morfonica自出道以来的众多经典曲目，包括《Daylight -デイライト-》《ブルームブルーム》《flame of hope》《ハーモニー・デイ》《Secret Dawn》《fly with the night》《Nevereverland》《誓いのWingbeat》《メランコリックララバイ》《両翼のBrilliance》《きょうもMerry go rounD》《Tempest》《Polyphonyscape》《Portray Empathy》《Feathered Dreams》等。在安可环节中，乐队演唱了本张单曲的同名主打歌《Resonant Strings》以及《寄る辺のSunny, Sunny》，蓝光光碟内同时收录了《Resonant Strings》的音乐录影带。

为纪念单曲发售，官方于2026年4月2日举办了线上签名会活动「モニカの校外学習 Vol.4」。活动由Morfonica的五位成员进藤天音、直田姬奈、西尾夕香、mika与Ayasa共同出演，以直播形式进行并提供了回放。该签名会的销售与抽选通道于同年2月12日至3月22日期间开放，中选者于3月27日前收到通知邮件。
