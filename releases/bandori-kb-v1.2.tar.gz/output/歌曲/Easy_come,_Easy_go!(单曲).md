---
title: Easy come, Easy go!(单曲)
url: https://zh.moegirl.org.cn/Easy%20come%2C%20Easy%20go%21%28%E5%8D%95%E6%9B%B2%29
revision: 8525125
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《Easy come, Easy go!》是《BanG Dream!》多媒体企划旗下女子摇滚乐队Afterglow的第六张单曲，于2020年3月11日正式发行。作为Afterglow音乐历程中的重要作品，该单曲延续了乐队一贯的流行摇滚风格，展现了成员之间深厚的情感羁绊与充满活力的青春气息。

单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格发售。全碟的试听动画于2019年12月22日率先在YouTube平台公开，提前为乐迷揭晓了新作的视听风格。实体唱片不仅收录了Afterglow的全新音乐作品，生产限定盘的Blu-ray光碟内还特别收录了《BanG Dream!》第三季电视动画的第八集与第九集，以及《BanG Dream! TV》特别篇第五期的精彩影像内容，为粉丝提供了丰富的视听附加价值。

在实体发售机制上，该单曲配置了丰厚的初回封入特典以回馈支持者。购买初回生产版本的消费者将随机获得一张精美的单曲封面角色卡（全系列共五种），以及一张Weiß Schwarz（黑白双翼）游戏公关卡（全系列共六种）。此外，唱片内还封入了“Afterglow×Pastel＊Palettes×Hello, Happy World! 6th单曲发售特别活动”的抽选券，为企划粉丝提供了参与线下声优互动活动的珍贵机会。

整体而言，《Easy come, Easy go!》不仅是一张承载着Afterglow独特音乐魅力的实体唱片，更是《BanG Dream!》企划在音乐、动画与跨媒体联动活动上的重要一环，具有极高的粉丝收藏价值。
