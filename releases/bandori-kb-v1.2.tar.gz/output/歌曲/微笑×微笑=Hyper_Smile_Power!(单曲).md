---
title: 微笑×微笑=Hyper Smile Power!(单曲)
url: https://zh.moegirl.org.cn/%E5%BE%AE%E7%AC%91%C3%97%E5%BE%AE%E7%AC%91%3DHyper%20Smile%20Power%21%28%E5%8D%95%E6%9B%B2%29
revision: 8427072
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 微笑×微笑=Hyper Smile Power!(单曲)

《にこ×にこ=ハイパースマイルパワー！》是《BanG Dream!》企划组合Hello, Happy World!的第六张单曲，发售于2020年3月18日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听动画于2019年12月22日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：单曲封面角色卡1张（共5种）、Weiß Schwarz PR卡1张（共6种）和「Afterglow×Pastel*Palettes×Hello, Happy World! 6th单曲发售特别活动」抽选券。

## 试听动画

## 收录曲目

## Blu-ray收录内容

动画《BanG Dream! 3rd Season》 #10~#11
BanG Dream! TV 特别篇#6

## 外部链接与注释

试听动画
（日文）官网CD介绍页
