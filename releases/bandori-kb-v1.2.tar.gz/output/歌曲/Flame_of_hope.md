---
title: Flame of hope
url: https://zh.moegirl.org.cn/Flame%20of%20hope
revision: 8544361
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- Raychell歌曲
- 小写标题
- 日本音乐作品
- 田所梓歌曲
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

《flame of hope》是《BanG Dream!》企划旗下女子乐队组合 Morfonica的一首代表性歌曲。该曲作为Morfonica第二张单曲《ブルームブルーム》（Bloom Bloom）的副主打曲目（C/W曲）发行，单曲唱片正式发售于2021年1月13日。

在游戏《BanG Dream! 少女乐团派对！》中，这首歌曲具有极高的活跃度与人气。它最初作为日服游戏内第120次活动《振翅高飞而作的练习曲》的活动曲目，于2020年7月11日提前实装于游戏内。在游戏谱面设计上，该曲的高难度谱面以极高的音符密度著称，对玩家的底力与手速有着较高的要求。同时，其高难度谱面也因配置特点成为了游戏内极具标志性的挑战关卡之一。

除了Morfonica的原始版本，这首歌曲还拥有极具特色的平行翻唱版本。该版本由跨企划的特别组合“COOL BEAUTIES”（酷美人）演唱，演唱者分别为Pastel*Palettes的濑田薰（CV.田所梓）、Roselia的八潮瑠唯（CV.Ayasa）以及RAISE A SUILEN的LAYER（CV.Raychell）。这一平行版本于2025年7月12日在各大数字音乐流媒体平台正式上线配信，并在同月11日追加至游戏中，其游戏谱面与原版保持完全一致。

作为一首充满乐队力量感与情感张力的作品，《flame of hope》不仅完美展现了Morfonica独特的弦乐交织与摇滚风格，更通过后续推出的跨团平行版本，生动体现了《BanG Dream!》企划中不同乐队角色之间的奇妙互动与深厚羁绊，是企划音乐多元化发展的精彩缩影。
