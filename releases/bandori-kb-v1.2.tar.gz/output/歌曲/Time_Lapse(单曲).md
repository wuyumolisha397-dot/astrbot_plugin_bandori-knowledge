---
title: Time Lapse(单曲)
url: https://zh.moegirl.org.cn/Time%20Lapse%28%E5%8D%95%E6%9B%B2%29
revision: 8462507
updated: '2026-07-01'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
- 带有失效视频的条目
---

# Time Lapse(单曲)

《Time Lapse》是《BanG Dream!》企划组合Poppin'Party的7th单曲，发售于2017年9月20日。分为Blu-ray付生产限定盘、通常盘两种规格。
主打曲《Time Lapse》的试听动画于2017年8月29日在YouTube上发布，C/W曲《八月のif》的试听动画于2017年8月30日在YouTube上发布，C/W曲《夏のドーン！》的试听动画于2017年8月31日在YouTube上发布。
初回封入特典为7th单曲发布特别纪念活动参加抽选券，角色卡等。各店铺特典是写真、海报、明信片等。

## 试听动画

Time Lapse

八月のif

夏のドーン！

## 收录曲目

## Blu-ray收录内容

BanG Dream! 3rd☆LIVE Sparklin' PARTY 2017! at TOKYO DOME CITY HOLL Live映像
节目列表：
1.ドラマ ～路上ライブデビュー！～
2.OPENING
3.Yes! BanG_Dream!
4.走り始めたばかりのキミに
5.Little Busters!（游戏《Little Busters!》片头曲）
6.Alchemy（TV动画《Angel Beats!》插曲）
7.DISCOTHEQUE（TV动画《十字架与吸血鬼(第二季)》片头曲）
8.STAR BEAT!〜ホシノコドウ〜 Acoustic Ver.
9.ぽっぴん’しゃっふる Acoustic Ver.
R1.ドラマ ～Roselia～
R2.魂のルフラン（剧场版动画《新世纪福音战士剧场版 死与新生》主题曲）
R3.Hacking to the Gate （TV动画《命运石之门》片头曲）
R4.BLACK SHOUT
10.ときめきエクスペリエンス！
11.ティアドロップス
12.キラキラだとか夢だとか ～Sing Girls～
EN1.1000回潤んだ空
EN2.STAR BEAT!〜ホシノコドウ〜
EN3.ENDING
特典映像「Making 映像～Poppin·Pappin·幕后！～」

### Live映像

## 外部链接与注释

试听动画：Time Lapse、八月のif、夏のドーン！
（日文）官网CD介绍页
