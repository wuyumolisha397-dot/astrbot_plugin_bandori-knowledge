---
title: ZEAL of proud(单曲)
url: https://zh.moegirl.org.cn/ZEAL%20of%20proud%28%E5%8D%95%E6%9B%B2%29
revision: 8552172
updated: '2026-06-28'
categories:
- 2021年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# ZEAL of proud(单曲)

《ZEAL of proud》是《BanG Dream!》企划组合Roselia的11th单曲，发售于2021年1月20日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为原创角色卡片一张（共5种）。

## 收录曲目

## Blu-ray收录内容

Roselia Live「Rausch」 Live映像
节目列表：
1.BLACK SHOUT
2.R
3.Neo-Aspect
4.Ringing Bloom
5.Re:birth day
6.BRAVE JEWEL
7.Determination Symphony
8.ONENESS
幕间映像Ⅰ
9.Legendary
10.Shangri-La
11.PASSIONATE ANTHEM
12.热色スターマイン
13.FIRE BIRD
幕间映像Ⅱ
ENCORE
14.约束
15.LOUDER

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
