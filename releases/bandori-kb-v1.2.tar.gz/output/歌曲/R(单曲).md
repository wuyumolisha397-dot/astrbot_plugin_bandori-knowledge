---
title: R(单曲)
url: https://zh.moegirl.org.cn/R%28%E5%8D%95%E6%9B%B2%29
revision: 8462474
updated: '2026-06-28'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《R》是《BanG Dream!》企划旗下组合Roselia的第六张单曲，于2018年7月25日正式发售。该单曲分为附赠Blu-ray的生产限定盘与通常盘两种规格，初回封入特典包含Roselia Fan Meeting 2018的抽选应募券，各店铺特典则提供写真与文件夹等周边。在正式发行前，官方于同年6月22日在视频平台发布了单曲的试听动画。

这张单曲在Roselia的发展历程中具有特殊的里程碑意义。它是声优中岛由贵接替远藤祐里香担任鼓手椎名立希后，乐队发行的首张唱片。除了同名主打新曲《R》之外，单曲还特别收录了由中岛由贵参与录制的《BLACK SHOUT》与《Neo-Aspect》重录版本，标志着新阵容在音乐表现上的正式起步。

在实体碟的Blu-ray光盘中，收录了Roselia此前举办的“Garupa Live”演唱会影像。该影像完整记录了2018年1月13日与1月14日两天的演出实况，演出曲目涵盖了《ONENESS》《Re:birth day》《阳だまりロードナイト》《LOUDER》《BLACK SHOUT》与《热色スターマイン》等经典曲目。此外，光盘还收录了歌曲《Neo-Aspect》的音乐录影带。
