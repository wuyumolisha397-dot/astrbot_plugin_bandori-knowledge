---
title: CiRCLING(单曲)
url: https://zh.moegirl.org.cn/CiRCLING%28%E5%8D%95%E6%9B%B2%29
revision: 8522252
updated: '2026-07-01'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《CiRCLING》是《BanG Dream!》多媒体企划中主导组合 Poppin'Party 的第九张实体单曲，于2018年3月21日正式发行。这张单曲不仅是 Poppin'Party 音乐历程中的重要作品，也通过丰富的实体特典与跨企划联动，展现了该企划独特的商业与粉丝互动模式。

单曲收录了《CiRCLING》与《Light Delight》两首歌曲。在正式发售前，官方于2018年1月27日率先在视频平台公开了主打歌《CiRCLING》的试听动画，随后又在2月3日放出了副歌《Light Delight》的试听影像，为专辑的发布进行了充分预热。

作为一首备受瞩目的商业单曲，本作在实体发售时附带了丰富的特典。初回生产限定版的封入特典包含了《BanG Dream! 5th☆LIVE》演唱会的特别二次先行抽选申请券，以及精美的角色卡。此外，各大合作唱片店铺也为顾客提供了专属的实物周边，如艺人写真、主题文件夹以及明信片等。

最具收藏价值的特别企划在于其跨界联动机制。当时正值同企划内另一支高人气乐队 Roselia 发行他们的第五张单曲《Opera of the wasteland》，官方借此推出了联合购入活动。凡是在指定店铺同时购买这两张单曲的粉丝，均可额外获赠一张特典翻唱曲CD。这套特典CD根据销售渠道的不同共分为四个颜色版本：青色版对应 Animate，赤色版对应 Gamers，黄色版对应 Tower Records，而黑色版则涵盖 Bushiroad EC、虎之穴部分门店、WonderGOO 部分门店及其他应援店铺。这些特典光盘内收录了《BanG Dream!》企划中的经典翻唱歌曲，极具纪念意义。
