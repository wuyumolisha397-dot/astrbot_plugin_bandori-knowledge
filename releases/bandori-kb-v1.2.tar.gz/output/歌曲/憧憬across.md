---
title: 憧憬across
url: https://zh.moegirl.org.cn/%E6%86%A7%E6%86%ACacross
revision: 8546247
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 秦佐和子歌曲
---

# 憧憬across

「あこがれacross」是企划《BanG Dream!》旗下组合Pastel*Palettes演唱的歌曲。为游戏第一百七十八期活动『That Day, That Song』的主题曲。

## 歌曲

QQ音乐

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

## BanG Dream! 少女乐团派对！

### 谱面

本曲并未随活动一同追加，而是在几个月后的2022年5月3日上架日服。

#### EXPERT难度

## 注释及外部链接
