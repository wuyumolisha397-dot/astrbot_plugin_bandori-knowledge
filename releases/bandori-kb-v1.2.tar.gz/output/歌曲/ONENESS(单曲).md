---
title: ONENESS(单曲)
url: https://zh.moegirl.org.cn/ONENESS%28%E5%8D%95%E6%9B%B2%29
revision: 8461241
updated: '2026-06-28'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《ONENESS》是《BanG Dream!》多媒体企划中人气女子乐队组合 Roselia 的第四张单曲，于2017年11月29日正式发行。这张单曲分为附赠 Blu-ray 的生产限定盘与通常盘两种规格，初回生产特典内含精美的角色卡，各合作店铺也分别提供了写真与文件夹等专属周边。

单曲的同名主打曲《ONENESS》与副歌《Determination Symphony》的试听动画，分别于同年11月10日和11日在视频平台上线。这两首曲目充分展现了 Roselia 一贯的交响金属风格与极具张力的音乐表现力，将乐队成员们深厚的演奏功底与极具史诗感的音乐美学完美融合。

在限定盘附赠的 Blu-ray 光盘中，特别收录了 Roselia 举办的首场单独演唱会“Rosenlied”追加公演的珍贵现场影像。这场演出不仅呈现了乐队自身的经典代表作，如《LOUDER》《BLACK SHOUT》《熱色スターマイン》以及《Re: birth day》等，还精彩演绎了多首知名动画与游戏曲目的翻唱版本。

其中包括剧场版动画《新世纪福音战士剧场版 死与新生》的主题曲《魂のルフラン》、TV动画《命运石之门》的片头曲《Hacking to the Gate》，以及TV动画《魔法少女奈叶A's》的片头曲《ETERNAL BLAZE》。整场演出在安可曲《BLACK SHOUT》与《LOUDER》的交替旋律中推向高潮。

作为 Roselia 早期音乐发展历程中的重要实体作品，《ONENESS》不仅为听众带来了两首高质量的录音室作品，更通过附赠的演唱会影像，生动记录了这支乐队在live舞台上极具感染力的成长轨迹与演出风采。
