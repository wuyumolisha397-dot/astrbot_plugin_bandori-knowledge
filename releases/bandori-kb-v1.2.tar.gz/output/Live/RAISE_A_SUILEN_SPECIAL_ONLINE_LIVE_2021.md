---
title: RAISE A SUILEN SPECIAL ONLINE LIVE 2021
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%20SPECIAL%20ONLINE%20LIVE%202021
revision: 8562204
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
---

# RAISE A SUILEN SPECIAL ONLINE LIVE 2021

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

RAISE A SUILEN SPECIAL ONLINE LIVE 2021是《BanG Dream!》企划组合RAISE A SUILEN的线上专场演唱会，于日清食品 POWER STATION [REBOOT]放送播出。

## 简介

### 概要

放送日期：2021年4月3日（星期六） 19:00
放送平台：日清食品 POWER STATION [REBOOT]
门票费用：3300日元（一般票）/6600日元（高级票）

## 出演人员

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

## 节目表

## 外部链接

RAISE A SUILEN SPECIAL ONLINE LIVE 2021. 日清食品 POWER STATION [REBOOT]. （原始内容存档于2021-03-21） （日本語）.
（日文）官网演唱会情报

## 注释
