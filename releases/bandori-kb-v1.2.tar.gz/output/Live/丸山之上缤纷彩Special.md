---
title: 丸山之上缤纷彩Special
url: https://zh.moegirl.org.cn/%E4%B8%B8%E5%B1%B1%E4%B9%8B%E4%B8%8A%E7%BC%A4%E7%BA%B7%E5%BD%A9Special
revision: 8527422
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
---

# 丸山之上缤纷彩Special

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

《Pastel＊Palettes 特別公演 ～まんまるお山に彩りスペシャル☆～》是《BanG Dream!》企划组合Pastel*Palettes的第一场专场演唱会，也是其主唱前岛亚美（饰演丸山彩）的第一场专场演唱会，举办于2020年1月27日。Pastel*Palettes中的秦佐和子、中上育实也有登场，不过并没有现场演奏。

## 简介

举办日期：2020年1月27日（星期一） 18:00开场 19:00开演
举办地点：Zepp Tokyo
费用：一层站席 JPY¥6500（不含税），二层指定席 JPY¥7000（不含税）
转播：日本国内22个转播点，海外（台北、香港、首尔）共4个转播点

## 出演人员

### 主场

Pastel*Palettes
前岛亚美

### 嘉宾

Pastel*Palettes
秦佐和子
中上育实

## 节目表

## 演唱会影像

收录于Pastel*Palettes 1st专辑《TITLE IDOL》Blu-ray付生产限定盘，商品编号：BRMM-10349，发售日：2021年5月19日

## 外部链接

（日文）官网演唱会详情
（日文）日本国内Live Viewing情报
（英文）海外Live Viewing情报

## 注释
