---
title: Roselia Stille Nacht, Rosen Nacht
url: https://zh.moegirl.org.cn/Roselia%20Stille%20Nacht%2C%20Rosen%20Nacht
revision: 8248474
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Roselia Stille Nacht, Rosen Nacht

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia「Stille Nacht, Rosen Nacht」是《BanG Dream!》企划旗下组合Roselia的一次专场演唱会。

东京公演于2024年12月14日举办，也是武藏野二日LIVE的第一日，次日在同场馆举办演唱会的Ave Mujica担当了本场的开场嘉宾。当天在现场宣布了上海追加公演的信息。
上海追加公演于2025年2月15日举办。这是Roselia第二次海外单独公演，也是企划首次将海外公演的录像收录于BD中。该场播放的幕间映像和东京场内容一致，且添加了中文字幕。
「Stille Nacht, Rosen Nacht」为德语，意为「平安夜，玫瑰夜」。

## 简介

### 概要

东京公演
举办日期：2024年12月14日（六） 开场15:30/开演17:00（东京时间）
举办地点: 武蔵野の森総合スポーツプラザ（武藏野之森综合体育广场）
上海追加公演
举办日期：2025年2月15日（六）
举办地点：浦发银行东方体育中心
联合主办方：EUPHORIC PRODUCTION（上海逸兴欢悦文化有限公司）

### 门票信息

东京公演
席位共分四档，S席24200日元，A席16500日元，一般指定席9900日元，见切席（视野受限席）8800日元。二日通票A席24200日元，一般指定席15400日元。（均含税）
2024年6月26日发售的《Roselia 3rd Album「Für immer」》中加入了最速先行抽选券，在2024年6月29日~8月19日期间可参与最速先行抽选。此外该抽选券与《BanG Dream! 翻唱曲合辑 Extra Volume》中的抽选券均可参与两日通票抽选。
票务先行办理期间为2024年8月30日~9月16日，二次先行期间为2024年9月28日~10月28日
门票一般发售日期为2024年11月9日，视野受限席发售日期为2024年11月30日。

### 网络直播与回放

东京公演于e-plus和bilibili同步付费直播。
e-plus单日票5500日元，二日通票9900日元（均含税），2024年12月7日~21日间有售。本场演唱会回放保留至21日。
bilibili单日票人民币198元，二日通票358元，当日17:00（北京时间）停止售票。不含直播回放。

## 出演人员

### 主场

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

### 东京场开场嘉宾

Ave Mujica
Vo.&Gt. Doloris（CV. 佐佐木李子）
Gt. Mortis（CV. 渡濑结月）
Ba. Timoris（CV. 冈田梦以）
Dr. Amoris（CV. 米泽茜）
Key. Oblivionis（CV. 高尾奏音）

Roselia「Stille Nacht, Rosen Nacht」出演成员

















## LIVE映像

东京公演收录于Roselia的16th单曲《Dazzle the Destiny》中。上海追加公演收录于Roselia的17th单曲《Requiem for Fate》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
