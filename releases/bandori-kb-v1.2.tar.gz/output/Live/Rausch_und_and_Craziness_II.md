---
title: Rausch und/and Craziness II
url: https://zh.moegirl.org.cn/Rausch%20und%2Fand%20Craziness%20II
revision: 8533972
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 隐藏子页面导航条的页面
---

# Rausch und/and Craziness II

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia×RAISE A SUILEN合同ライブ「Rausch und/and Craziness Ⅱ」是《BanG Dream!》企划组合Roselia与RAISE A SUILEN的第三场对邦演唱会，举办于2021年2月22日。

## 简介

### 概要

举办日期：2021年2月22日(一) 开场15:30／开演17:00
举办地点：横浜アリーナ
转播：日本国内83个转播点，海外（中国台湾）6个转播点。

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）
RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

## LIVE映像

收录于纪念专辑《BanG Dream! Dreamer's Best》中。

## 节目表

## 外部链接

（日文）官网演唱会详情
（日文）日本国内Live Viewing情报
（英文）海外Live Viewing情报

## 注释
