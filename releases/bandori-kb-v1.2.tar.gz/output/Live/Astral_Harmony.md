---
title: Astral Harmony
url: https://zh.moegirl.org.cn/Astral%20Harmony
revision: 8550465
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Astral Harmony

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

《Poppin'Party×Morfonica Friendship LIVE「Astral Harmony」》是《BanG Dream!》企划组合Poppin'Party与Morfonica的联合演唱会，举办于2021年2月23日。

## 简介

### 概要

举办日期：
2021年2月23日(二)开场15:30／开演17:00
举办地点：横浜アリーナ
转播：日本国内77个转播点，海外（中国台湾）6个转播点。

## 出演人员

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）
Morfonica
Vo. 仓田真白（CV. 进藤天音）
Gt. 桐谷透子（CV. 直田姬奈）
Ba. 广町七深（CV. 西尾夕香）
Dr. 二叶筑紫（CV. mika）
Vn. 八潮瑠唯（CV. Ayasa）

## LIVE映像

收录于纪念专辑《BanG Dream! Dreamer's Best》中。

## 节目表

## 外部链接

（日文）官网「Astral Harmony」演唱会详情
（日文）「Astral Harmony」日本国内Live Viewing情报
（英文）「Astral Harmony」海外Live Viewing情报

## 注释
