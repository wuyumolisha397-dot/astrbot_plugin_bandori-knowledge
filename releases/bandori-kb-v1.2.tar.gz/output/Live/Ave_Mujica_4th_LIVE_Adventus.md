---
title: Ave Mujica 4th LIVE Adventus
url: https://zh.moegirl.org.cn/Ave%20Mujica%204th%20LIVE%20Adventus
revision: 8448972
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Ave Mujica 4th LIVE Adventus

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Ave Mujica 4th LIVE「Adventus」是《BanG Dream!》企划组合Ave Mujica的第五场专场演唱会，举办于2024年12月15日，也是武藏野二日LIVE的第二日。前一日在同一场馆举办演唱会的Roselia担当开场嘉宾。
本次演唱会期间先行放映了TV动画《BanG Dream! Ave Mujica》第1话，在随后的演唱中成员摘下面具演奏，为专场演唱会首次。此外本次演唱会也是该组合首次不演唱翻唱曲的专场演唱会。
「Adventus」为拉丁语，直译为「到来」或是「抵达」，引申义为基督教用语「将临期」。
演唱会当天为满月。

## 简介

### 概要

举办日期：2024年12月15日（日） 开场15:30/开演17:00
举办地点: 武蔵野の森総合スポーツプラザ（武藏野之森综合体育广场）

### 门票信息

席位共分四档，S席24200日元，A席16500日元，一般指定席9900日元。当日券A席17600日元，一般指定席11000日元。二日通票仅支持先行抽选，A席24200日元，一般指定席15400日元。（均含税）
2024年7月10日发售的《BanG Dream! 翻唱曲合辑 Extra Volume》中加入了最速先行抽选券，在2024年7月10日~8月19日期间可参与最速先行抽选。此外该抽选券与《Roselia 3rd Album「Für immer」》中的抽选券均可参与两日通票抽选。
票务先行办理期间为2024年8月30日~9月16日，二次先行办理期间为2024年9月28日~10月28日
门票一般发售日期为2024年11月10日，当日券可在当日购买。

### 网络直播与回放

于e-plus和bilibili同步付费直播。本次直播不含TV动画《BanG Dream! Ave Mujica》第1话以及后续的演出内容。

e-plus单日票5500日元，二日通票9900日元（均含税），2024年12月7日~22日间（二日通票截止至21日）有售。本场演唱会回放保留至22日。
bilibili限中国大陆IP观看，单日票人民币198元，二日通票358元，当日17:00（北京时间）停止售票。不含直播回放。

## 出演人员

### 主场

Ave Mujica
Vo.&Gt. Doloris（CV. 佐佐木李子）
Gt. Mortis（CV. 渡濑结月）
Ba. Timoris（CV. 冈田梦以）
Dr. Amoris（CV. 米泽茜）
Key. Oblivionis（CV. 高尾奏音）

### 开场嘉宾

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

## LIVE映像

收录于Ave Mujica的1st专辑《Completeness》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
