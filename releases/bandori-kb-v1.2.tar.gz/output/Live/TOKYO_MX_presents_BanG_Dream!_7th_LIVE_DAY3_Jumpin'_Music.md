---
title: TOKYO MX presents BanG Dream! 7th LIVE DAY3:Jumpin' Music
url: https://zh.moegirl.org.cn/TOKYO%20MX%20presents%20BanG%20Dream%21%207th%20LIVE%20DAY3%3AJumpin%27%20Music
revision: 8532940
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# TOKYO MX presents BanG Dream! 7th LIVE DAY3:Jumpin' Music

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

TOKYO MX presents 「BanG Dream! 7th☆LIVE」DAY3:Jumpin' Music♪是《BanG Dream!》企划组合Poppin'Party的专场演唱会，举办于2019年2月23日。

## 简介

### 概要

举办日期:2019年2月23日(六)开场18:00／开演19:00(日本时间)
举办地点:日本武道馆
全日本、台湾、香港、韩国电影院放送。日本国内详情见→Live Viewing情报

## 出演人员

### 主场

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）

### 嘉宾

SILENT SIREN
すぅ（吉田堇 (Vo. & Gt.)）
ひなんちゅ（梅村妃奈子 (Dr.)）
あいにゃん（山内あいな (Ba.)）
ゆかるん（黑坂优香子 (Key.)）
协力嘉宾:Mika（在君じゃなきゃダメみたい和Only my Railgun配合Poppin'Party演奏）

TOKYO MX presents 「BanG Dream! 7th☆LIVE」DAY3:Jumpin' Music♪出演成员













## LIVE映像

收录于BD《TOKYO MX presents 「BanG Dream! 7th☆LIVE」COMPLETE BOX》及《TOKYO MX presents「BanG Dream! 7th☆LIVE」 DAY3：Poppin'Party「Jumpin' Music♪」》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
