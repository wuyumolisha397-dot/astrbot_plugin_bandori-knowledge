---
title: RAISE A SUILEN 2DAYS LIVE RUMBLEHEADZ
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%202DAYS%20LIVE%20RUMBLEHEADZ
revision: 8391228
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# RAISE A SUILEN 2DAYS LIVE RUMBLEHEADZ

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

RAISE A SUILEN 2DAYS LIVE「RUMBLEHEADZ」是《BanG Dream!》企划旗下组合RAISE A SUILEN的专场演唱会，举办于2025年11月15、16日。
「RUMBLEHEADZ」即「RUMBLE HEADS」。

## 简介

### 概要

日期：
DAY1 2025年11月15日 17:00开场／18:00开演
DAY2 2025年11月16日 16:00开场／17:00开演
地点：TACHIKAWA STAGE GARDEN

### 门票信息

票价
竞技场站立席（附特典）：16,500日元（含税）
看台指定席（附特典）：14,300日元（含税）
看台指定席：9,900日元（含税）
带注释的看台指定席（附特典）：13,200日元（含税）
带注释的看台指定席：8,800日元（含税）
带注释的看台指定席为三楼看台，视线可能因此受到影响。
抽选日程
最速先行抽选：2025年6月14日 21:00 ～ 7月13日 23:59
抽选申请券封入RAISE A SUILEN 13th Single「HOWLING AMBITION」。
Pre Guide先行（抽选）：2025年8月8日 12:00 ～ 8月31日 23:59
Pre Guide二次先行（抽选）：2025年9月13日 10:00 ～ 9月29日 23:59
一般发售（先到先得）：2025年10月11日 12:00 ～

### 网络直播与回放

于e-plus和bilibili同步付费直播。

e-plus单场票售价5,500日元，两日通票售价9,900日元（均含税）。回放保留至11月23日。
bilibili单场票售价人民币198元，两日通票售价人民币358元。不含直播回放。
本场演出于bilibili提供延迟播出，单场演出为238元充电档位限定视频，两日通票为368元充电档位限定视频，保留时限为一周。

### 公布事项

RAISE A SUILEN 15th Single将于2026年春季发售。
Fear, and Loathing in Las Vegas提供曲第2弹「Drown Out the Noise and Push Through the Trash」MV制作决定。

## 出演人员

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

## LIVE映像

Day2及仅在Day1演奏的四首歌曲收录于RAISE A SUILEN的15th单曲《WHAT AN EXPLOSION》中。

## 节目表

### 11月15日

### 11月16日

## 外部链接

（日文）官网演唱会详情

## 注释
