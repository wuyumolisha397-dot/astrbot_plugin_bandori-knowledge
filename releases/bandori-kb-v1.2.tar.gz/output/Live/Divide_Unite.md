---
title: Divide/Unite
url: https://zh.moegirl.org.cn/Divide%2FUnite
revision: 8538417
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 隐藏子页面导航条的页面
---

# Divide/Unite

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

《Poppin'Party×MyGO!!!!! 合同ライブ「Divide/Unite」》是《BanG Dream!》企划组合Poppin'Party与MyGO!!!!!的联合演唱会，举办于2024年4月29日。

## 简介

### 概要

举办日期:2024年4月29日(一)开场17:00／开演18:00（预定）
举办地点:横浜アリーナ

### 线上配信

本次公演由e-plus平台提供线上放送，票价为5500日元。
映像在公演后6日内可供回放，线上门票于2024年4月25日起发售。
BiliBili官方账号将会以充电专属视频的形式提供回放，定价为288元（包月充电238元）。
回放自北京时间4月30日12：00至5月6日11：59可观看。此版本附有全场MC、全场出演曲目歌词的中文字幕。

## 出演人员

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）
MyGO!!!!!
Vo. 高松灯（CV. 羊宫妃那）
Gt. 千早爱音（CV. 立石凛）
Gt. 要乐奈（CV. 青木阳菜）
Ba. 长崎爽世（CV. 小日向美香）
Dr. 椎名立希（CV. 林鼓子）

Poppin'Party×MyGO!!!!! 合同LIVE「Divide/Unite」出演成员













## LIVE映像

收录于BD《Poppin'Party×MyGO!!!!! 合同ライブ「Divide/Unite」Blu-ray》中，于2024年9月25日发售。完全生产限定版中附赠了两张收录LIVE音源的CD。

## 节目表

## 外部链接

（日文）官网演唱会详情
（日文）日本国内线上配信网站
海外线上配信网站
BiliBili充电专属视频详情

## 注释
