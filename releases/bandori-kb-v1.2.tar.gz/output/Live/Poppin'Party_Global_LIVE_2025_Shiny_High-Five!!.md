---
title: Poppin'Party Global LIVE 2025 Shiny High-Five!!
url: https://zh.moegirl.org.cn/Poppin%27Party%20Global%20LIVE%202025%20Shiny%20High-Five%21%21
revision: 8550479
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Poppin'Party Global LIVE 2025 Shiny High-Five!!

除非特别注明，本页面所有时间皆以东八区时间（UTC+08:00）为准。

《Poppin'Party Global LIVE 2025「Shiny High-Five!!」》是《BanG Dream!》企划组合Poppin'Party的专场演唱会，举办于2025年8月23日。
本场演唱会为Poppin'Party结成十周年以来首次海外单独演唱会。

## 简介

### 概要

举办日期:2025年8月23日(一)开场17:00／开演19:00
举办地点：浦发银行东方体育中心

### 门票信息

门票分为以下六档
内场A席位：人民币1680元
内场B席位：人民币1380元
看台A席位：人民币1080元
看台B席位：人民币880元
看台C席位：人民币680元
看台D席位：人民币480元
2025年7月31日12:00开启首轮预售
大麦平台为4682张，猫眼平台为2342张，票星球平台为391张，携程平台为391张。
2025年8月8日12:00开启二轮售票
大麦平台为1000张，猫眼平台为591张，票星球平台为109张，携程平台为109张。
2025年8月21日20:00开启三轮售票
三轮售票为大麦和猫眼平台所剩余票。

## 出演人员

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）






## LIVE映像

## 节目表

## 外部链接

官网演唱会详情 （日本語）.
逸兴欢悦EUPD票务信息 （中文）.

## 注释

## 参考资料
