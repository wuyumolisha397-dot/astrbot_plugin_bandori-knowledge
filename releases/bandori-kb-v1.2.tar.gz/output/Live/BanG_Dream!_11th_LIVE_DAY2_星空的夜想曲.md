---
title: BanG Dream! 11th LIVE DAY2:星空的夜想曲
url: https://zh.moegirl.org.cn/BanG%20Dream%21%2011th%20LIVE%20DAY2%3A%E6%98%9F%E7%A9%BA%E7%9A%84%E5%A4%9C%E6%83%B3%E6%9B%B2
revision: 8280489
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# BanG Dream! 11th LIVE DAY2:星空的夜想曲

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

BanG Dream! 11th☆LIVE DAY2:星空の夜想曲是《BanG Dream!》企划组合Roselia与Morfonica的联合演唱会，举办于2023年2月5日。
演唱会标题Sternenzelt Nocturne为德语又是德语，直译为“繁星夜曲”。

## 简介

### 概要

举办日期:2023年2月5日(日)开场17:00／开演18:00※开场表演预定于17:40开始
举办地点:有明アリーナ
本次演唱会设有线上放送，详情请见：Live Viewing情报

## 出演人员

### 主场

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）
Morfonica
Vo. 仓田真白（CV. 进藤天音）
Gt. 桐谷透子（CV. 直田姬奈）
Ba. 广町七深（CV. 西尾夕香）
Dr. 二叶筑紫（CV. mika）
Vn. 八潮瑠唯（CV. Ayasa）

### 嘉宾

开场嘉宾：MyGO!!!!!
Vo. 高松灯（CV. 羊宫妃那）
Gt. 千早爱音（CV. 立石凛）
Gt. 要乐奈（CV. 青木阳菜）
Ba. 长崎爽世（CV. 小日向美香）
Dr. 椎名立希（CV. 林鼓子）

## LIVE映像

收录于BD合集《BanG Dream! 11th☆LIVE/Mythology Chapter 2》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
