---
title: BanG Dream! 12th LIVE DAY2:小小的一瞬间
url: https://zh.moegirl.org.cn/BanG%20Dream%21%2012th%20LIVE%20DAY2%3A%E5%B0%8F%E5%B0%8F%E7%9A%84%E4%B8%80%E7%9E%AC%E9%97%B4
revision: 8548925
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# BanG Dream! 12th LIVE DAY2:小小的一瞬间

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

BanG Dream! 12th☆LIVE DAY2:ちいさな一瞬是《BanG Dream!》企划组合MyGO!!!!!的专场演唱会，举办于2023年11月4日。
演唱会标题取自一单歌曲《迷路日々》中的歌词「ちいさな一瞬　あつめたい」(想聚集起 小小的一瞬间)。

## 简介

### 概要

举办日期:2023年11月4日(六)开场17:00／开演18:00
举办地点:東京ガーデンシアター
本次演唱会设有线上放送，详情请见：日本国内Live Viewing情报与海外Live Viewing情报

## 出演人员

MyGO!!!!!
Vo. 高松灯（CV. 羊宫妃那）
Gt. 千早爱音（CV. 立石凛）
Gt. 要乐奈（CV. 青木阳菜）
Ba. 长崎爽世（CV. 小日向美香）
Dr. 椎名立希（CV. 林鼓子）

## LIVE映像

收录于MyGO!!!!!的5th单曲《端程山》中。

## 节目表

## 外部链接

（日文）官网演唱会详情
（日文）日本国内Live Viewing情报
（英文）海外Live Viewing情报

## 注释
