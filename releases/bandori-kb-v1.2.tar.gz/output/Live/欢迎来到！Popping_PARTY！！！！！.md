---
title: 欢迎来到！Popping PARTY！！！！！
url: https://zh.moegirl.org.cn/%E6%AC%A2%E8%BF%8E%E6%9D%A5%E5%88%B0%EF%BC%81Popping%20PARTY%EF%BC%81%EF%BC%81%EF%BC%81%EF%BC%81%EF%BC%81
revision: 8537120
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# 欢迎来到！Popping PARTY！！！！！

《ようこそ！ぽっぴん☆PARTY！！！！！》是《BanG Dream!》企划还未正式开始前，组合Poppin'Party的专场演唱会，举办于2015年10月11日。月刊Bushiroad TV第82回（2015-11-05放送）播出了该演唱会的片段。

## 简介

举办日期:2015年10月11日
举办地点: ディファ有明

## 出演人员

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）

## 节目表

Yes!BanG_Dream!
空色デイズ
God knows…
正解はひとつ!じゃない!!
ライオン
Ob-La-Di, Ob-La-Da
STARBEAT! ~ホシノコドウ~
ティアドロップス
ぽっぴん’しゃっふる
夏空 SUN! SUN! SEVEN!
Yes!BanG_Dream!
ENCORE

STAR BEAT! ～ホシノコドウ～

## 外部链接

## 注释
