---
title: Roselia 2nd Live Zeit
url: https://zh.moegirl.org.cn/Roselia%202nd%20Live%20Zeit
revision: 8263778
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Roselia 2nd Live Zeit

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia 2nd Live「Zeit」是《BanG Dream!》企划组合Roselia的第二场专场演唱会，举办于2017年10月8日。
「Zeit」是德语，意为「时间」。

## 简介

举办日期：2017年10月8日
举办地点：幕張メッセイベントホール

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 远藤祐里香）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 明坂聪美）

## LIVE影像

收录于Roselia的专辑《Anfang》及《Roselia 2017-2018 LIVE BEST -Soweit-》中。

## 节目表

## 注释

## 外部链接

（日文）官网演唱会详情
