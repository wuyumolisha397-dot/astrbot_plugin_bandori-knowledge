---
title: Rausch und/and Craziness
url: https://zh.moegirl.org.cn/Rausch%20und%2Fand%20Craziness
revision: 8533902
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 隐藏子页面导航条的页面
---

# Rausch und/and Craziness

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia×RAISE A SUILEN合同ライブ「Rausch und/and Craziness」是《BanG Dream!》企划组合Roselia与RAISE A SUILEN的首次对邦演唱会，举办于2019年11月30与12月1日。
「Rausch und/and Craziness」意为「迷醉与疯狂」，其中前半部分的「Rausch」又双叒叕是德语，且「und/and」不发音。

## 简介

### 概要

时间：
2019年11月30日 开场17:30／开演19:00
2019年12月1日 开场14:30／开演16:00
地点：幕張メッセ国際展示場4～6ホール
转播：日本国内57个转播点，海外（台北、香港、首尔、曼谷、新加坡）共9个转播点。另外计划在美国20个城市举办Delay Viewing。

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）
RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

Roselia×RAISE A SUILEN合同live「Rausch und/and Craziness」出演成员









## LIVE映像

收录于同名BD《Roselia×RAISE A SUILEN「Rausch und/and Craziness」》中。
Roselia追加公演「Rausch」收录于Roselia的11th单曲《ZEAL of proud》中。
RAISE A SUILEN追加公演「Craziness」收录于RAISE A SUILEN的6th单曲《mind of Prominence》中。

## 节目表

### 11月30日

### 12月1日

## 追加公演「Rausch」

### 简介

举办日期：2020年2月1日
举办地点：武蔵野の森総合スポーツプラザ

### 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

「Rausch」









### 节目表

## 追加公演「Craziness」

### 简介

举办日期：2020年2月9日
举办地点：静岡エコパアリーナ

### 出演人员

#### 主场

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

#### 开场嘉宾

小笠原仁（GYROAXIA 旭那由多 役）

「Craziness」









### 节目表

## 外部链接

（日文）官网「Rausch und/and Craziness」演唱会详情
（日文）「Rausch und/and Craziness」日本国内Live Viewing情报
（英文）「Rausch und/and Craziness」海外Live Viewing情报
（英文）「Rausch und/and Craziness」美国Delay Viewing情报
（日文）官网追加公演「Rausch」详情
（日文）官网追加公演「Craziness」详情

## 注释
