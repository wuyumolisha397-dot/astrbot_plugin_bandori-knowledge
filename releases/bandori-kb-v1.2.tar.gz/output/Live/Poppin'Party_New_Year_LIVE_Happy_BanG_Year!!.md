---
title: Poppin'Party New Year LIVE Happy BanG Year!!
url: https://zh.moegirl.org.cn/Poppin%27Party%20New%20Year%20LIVE%20Happy%20BanG%20Year%21%21
revision: 8468926
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Poppin'Party New Year LIVE Happy BanG Year!!

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

《Poppin'Party New Year LIVE「Happy BanG Year!!」》是《BanG Dream!》企划组合Poppin'Party的专场演唱会，举办于2026年1月3日。

## 简介

### 概要

举办日期:2026年1月3日(六) 开场17:00／开演18:00
举办地点：東京ガーデンシアター

### 门票信息

票价
Premium Seat（附特典）：22,000日元（含税）
一般指定席（附特典）：15,400日元（含税）
一般指定席：9,900日元（含税）
抽选日程
最速先行抽选：2025年5月26日 22:00 ～ 7月14日 23:59
抽选申请券封入Poppin'Party 3rd Album「POPIGENIC」。
Pre Guide先行（抽选）：2025年8月2日 12:00 ～ 9月8日 23:59
Pre Guide二次先行（抽选）：2025年9月26日 18:00 ～ 11月3日 23:59
一般发售（先到先得）：2025年11月15日 10:00 ～

### 网络直播与回放

本次演唱会于e-plus提供付费直播，bilibili上由于“多方面原因”只提供直播回放。

e-plus票价5500日元，本场演唱会回放保留至10日23:59。
bilibili票价人民币368元，与Morfonica 5th Anniversary LIVE「Maestoso」捆绑售卖，不可单独购买，本场演唱会回放保留至10日北京时间22:59。

## 出演人员

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）

## LIVE映像

收录于Poppin'Party的22nd单曲《どきどきデエト》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
