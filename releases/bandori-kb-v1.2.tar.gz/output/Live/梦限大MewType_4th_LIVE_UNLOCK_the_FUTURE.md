---
title: 梦限大MewType 4th LIVE UNLOCK the FUTURE
url: https://zh.moegirl.org.cn/%E6%A2%A6%E9%99%90%E5%A4%A7MewType%204th%20LIVE%20UNLOCK%20the%20FUTURE
revision: 8487615
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 虚拟UP主演唱会
---

# 梦限大MewType 4th LIVE UNLOCK the FUTURE

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

夢限大みゅーたいぷ 4th LIVE「アンロック・ザ・フューチャー」是《BanG Dream!》企划旗下组合梦限大MewType的专场演唱会，举办于2025年9月7日。
本次公演的安可环节，首次在网络上公开五位中之人的容貌，并宣布了TV动画《BanG Dream! YUME∞MITA》2026年内播出、首张专辑以及演唱会BD发售等信息。

## 简介

### 概要

地点：TACHIKAWA STAGE GARDEN
日期：2025年9月7日（星期日）开场17:00／开演18:00

### 门票信息

抽选日程
最速先行抽选：2025年5月7日 21:00 ～ 6月16日 23:59
抽选券封入梦限大MewType 2nd Single「Hi-Vision」。
在本阶段抽选中选并付款，可获得限定特典：特制塑封PASS
票价
附商品指定席：11,000日元（含税）
一般指定席：8,800日元（含税）
两种门票的观演位置没有优劣区别，全部为随机抽选。
每人最多可申请每场两张门票。

### 直播

分别于YouTube和bilibili免费直播了本次公演的安可与告知部分。

## 出演人员

梦限大MewType
Vo. 仲町阿拉蕾
Gt. 宫永野乃花
Gt. 峰月律
Key. 藤都子
DJ&Mp. 千石由乃

## 节目表/歌单

## 外部链接

（日文）官网演唱会详情

## 注释
