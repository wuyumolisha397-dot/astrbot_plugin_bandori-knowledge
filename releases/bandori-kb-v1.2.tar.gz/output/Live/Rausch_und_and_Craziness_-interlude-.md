---
title: Rausch und/and Craziness -interlude-
url: https://zh.moegirl.org.cn/Rausch%20und%2Fand%20Craziness%20-interlude-
revision: 8533946
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 隐藏子页面导航条的页面
---

# Rausch und/and Craziness -interlude-

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia×RAISE A SUILEN合同オンラインライブ「Rausch und/and Craziness -interlude-」是《BanG Dream!》企划组合Roselia与RAISE A SUILEN的线上合同演唱会，也是企划首次以无观众线上形式举办的演唱会，于2020年12月12日在线上直播平台进行付费放送。

## 简介

### 概要

放送日期：2020年12月12日（星期六） 18:00开始放送
放送平台：U-NEXT、PIA LIVE STREAM、ローチケ LIVE STREAMING、Thumva、ニコニコ生放送、ABEMA、ZAIKO、bilibili（仅限中国大陆地区观看）
门票费用：5,500日元/320元

### 其他

本场线上演唱会是提前收录并制作成映像的形式进行放送的。

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）
RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

## 节目表

## 外部链接

（日文）官网演唱会详情
（日文）日本Liveviewing网情报
（中文）bilibili直播特设网站

## 注释
