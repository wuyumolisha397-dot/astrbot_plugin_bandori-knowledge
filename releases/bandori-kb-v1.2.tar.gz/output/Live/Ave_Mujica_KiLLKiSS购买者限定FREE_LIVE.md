---
title: Ave Mujica KiLLKiSS购买者限定FREE LIVE
url: https://zh.moegirl.org.cn/Ave%20Mujica%20KiLLKiSS%E8%B4%AD%E4%B9%B0%E8%80%85%E9%99%90%E5%AE%9AFREE%20LIVE
revision: 8448969
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Ave Mujica KiLLKiSS购买者限定FREE LIVE

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Ave Mujica「KiLLKiSS」購入者限定フリーライブ是《BanG Dream!》企划组合Ave Mujica的第六场专场演唱会，举办于2025年2月2日。
本次演唱会不售通常门票，购买二单初回生产分限定盘可参与本次演唱会入场券抽选。虽说是免费演唱会但是还是会收系统费和饮料费
和隔壁MyGO!!!!! 5th LIVE一样，本次演唱会举办于《BanG Dream! Ave Mujica》剧中乐队解散之际，因而被不少观众吐槽。

## 简介

### 概要

举办日期：2025年2月2日（日） 开场18:00/开演18:30
举办地点: KT Zepp Yokohama

### 网络直播与回放

于YouTube和bilibili同步免费直播。不含直播回放。

## 出演人员

Ave Mujica
Vo.&Gt. Doloris（CV. 佐佐木李子）
Gt. Mortis（CV. 渡濑结月）
Ba. Timoris（CV. 冈田梦以）
Dr. Amoris（CV. 米泽茜）
Key. Oblivionis（CV. 高尾奏音）

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
