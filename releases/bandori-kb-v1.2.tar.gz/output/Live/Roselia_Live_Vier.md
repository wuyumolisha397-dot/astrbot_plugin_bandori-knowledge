---
title: Roselia Live Vier
url: https://zh.moegirl.org.cn/Roselia%20Live%20Vier
revision: 8255453
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Roselia Live Vier

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia Live 「Vier」是《BanG Dream!》企划组合Roselia的第四场专场演唱会，举办于2018年11月7日。
「Vier」是德语，意为「4」，代表第四次专场Live，也暗示了明坂聪美毕业后、志崎桦音加入前，Roselia在三次元乐队上仅有四人的一个过渡状态。
本次Live中声优志崎桦音做为键盘手加入Roselia。RAISE A SUILEN主唱Raychell做为惊喜嘉宾登场与相羽爱奈合唱魂のルフラン，并宣布做为开场嘉宾登场BanG Dream! 6th☆LIVE Day1。

## 简介

举办日期：2018年11月7日（三） 开场18:00／开演19:00
举办地点：品川ステラボール（品川Stella Hall）
费用：站席 JPY¥7000（含税）
转播：日本国内60个转播点，海外（台湾、香港、韩国）共6个转播点

## 出演人员

### 主场

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）

### 嘉宾

志崎桦音（Roselia 白金燐子 役）
惊喜嘉宾：Raychell（RAISE A SUILEN）

## Live映像

收录于《Roselia 2017-2018 LIVE BEST -Soweit-》中。

## 节目表

## 外部链接

（日文）官网演唱会详情
（日文）日本国内Live Viewing情报
（英文）海外Live Viewing情报

## 注释
