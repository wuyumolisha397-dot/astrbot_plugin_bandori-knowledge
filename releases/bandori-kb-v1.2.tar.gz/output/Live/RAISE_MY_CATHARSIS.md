---
title: RAISE MY CATHARSIS
url: https://zh.moegirl.org.cn/RAISE%20MY%20CATHARSIS
revision: 8342475
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- GIRLS BAND CRY
- 使用标题替换的页面
---

# RAISE MY CATHARSIS

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

《RAISE MY CATHARSIS》是《BanG Dream!》企划旗下组合RAISE A SUILEN与《GIRLS BAND CRY》企划旗下组合TOGENASHI TOGEARI的联合演唱会，举办于2025年12月7日。

## 简介

### 概要

举办日期：
2025年12月7日（日）开场16:00／开演17:30
举办地点：京王アリーナ TOKYO（武藏野森林综合体育广场）

### 票务

票价
附带周边商品的指定席 16500日元（含税）
一般指定席 11000日元（含税）
视野受限的一般指定席 9900日元（含税）
最速先行：
1.于RAISE A SUILEN 13th单曲《HOWLING AMBITION》发售纪念活动指定商店消费满8000日元。或2. 购买トゲナシトゲアリ的《2nd ONE-MAN LIVE “凛音の理”》 、《3rd ONE-MAN LIVE “咆哮の奏”》BD与DVD。
申请期间：2025年7月23日20:00～8月24日23:59
抽选结果公布：2025年10月18日18:00～
购票时间：2025年10月18日18:00～10月22日21:00

### 网络直播

本次演出将进行存档直播，具体日期安排待公布。

## 出演

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）
TOGENASHI TOGEARI
井芹仁菜 (理名 (Vo.))
河原木桃香 (夕莉 (Gt.))
RUPA (朱李 (Ba.))
鼓手、键盘手分别由宫内沙弥、铃木荣奈替补。

## 节目表

## 外部链接

（日文）官网演唱会详情（BanG Dream!）
（日文）官网演唱会详情（TOGENASHI TOGEARI）

## 注释
