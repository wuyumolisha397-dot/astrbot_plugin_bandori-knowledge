---
title: Hello, Happy World! Special Event Happy! Lucky! Smile! Festival!
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%20Special%20Event%20Happy%21%20Lucky%21%20Smile%21%20Festival%21
revision: 8557762
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Hello, Happy World! Special Event Happy! Lucky! Smile! Festival!

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

ハロー、ハッピーワールド！ スペシャルイベント「ハッピー！ラッキー！スマイル！フェスティバル！」是《BanG Dream!》企划中登场乐队Hello, Happy World!的第一次线下专场活动，举办于2023年9月9日。

## 简介

### 概要

举办日期：2023年9月9日（星期六）
1部：开场11:30／开演12:30
2部：开场16:30／开演17:30
举办地点: KT Zepp Yokohama

### 门票信息

票价
1F站立席（附特典）：11,000 日元（含税）
1F站立席（附特典、当日票）：12,100 日元（含税）
2F指定席（附特典）：11,000 日元（含税）
1F站立席：8,800 日元（含税）
1F站立席（当日票）：9,900 日元（含税）
2F指定席：8,800 日元（含税）
2F指定席（当日票）：9,900 日元（含税）
入场需另外支付饮品费。
特典：毛巾（フルグラフィックタオル）
抽选日程
最速先行抽选：
日程：2023年6月28日 10:00 ～ 2023年7月31日 23:59
抽选申请券封入Hello, Happy World! 2nd Album「SMILE ON PARADE」。

### 网络直播与回放

提供延迟直播，票价为每场5,500日元（含税）
申请开始时间：2023年9月7日（四）22:00至2023年9月16日（六）22:00
观看时间：至2023年9月16日（六）23:59

## 出演人员

Hello, Happy World!
弦卷心（CV. 伊藤美来）
濑田薰（CV. 田所梓）
北泽育美（CV. 吉田有里）
松原花音（CV. 丰田萌绘）
奥泽美咲(米歇尔)（CV. 黑泽朋世）
仅在1部出演

## 节目表

以下只详细列出Live部分的节目内容。

### 1部

### 2部

## 部分推特返图

BanG Dream! 公式
伊藤美来
丰田萌绘
田所梓
Bushiroad Music公式
アニバース編集部

## 注释

## 外部链接

（日文）官网活动详情
