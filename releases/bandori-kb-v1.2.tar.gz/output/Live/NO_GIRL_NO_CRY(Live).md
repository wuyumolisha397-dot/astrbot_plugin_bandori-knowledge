---
title: NO GIRL NO CRY(Live)
url: https://zh.moegirl.org.cn/NO%20GIRL%20NO%20CRY%28Live%29
revision: 8550475
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题格式化的页面
---

# NO GIRL NO CRY(Live)

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Poppin’Party×SILENT SIREN 対バンライブ「NO GIRL NO CRY」是《BanG Dream!》企划组合Poppin'Party与SILENT SIREN的对邦演唱会，举办于2019年5月18日、19日。

## 简介

### 概要

举办日期:
2019年5月18日(六)开场15:00／开演17:00
2019年5月19日(日)开场15:00／开演17:00
举办地点:メットライフドーム
全日本、台湾、香港、韩国电影院放送。

### 其他

此两天LIVE为2019年「BanG Dream!周」第五、六天活动内容之一。

## 出演人员

### 主场

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）
SILENT SIREN
Vo.&Gt. すぅ（吉田堇）
Dr. ひなんちゅ（梅村妃奈子）
Ba. あいにゃん（山内爱菜）
Key. ゆかるん（黑坂优香子）

### 开场嘉宾

#### 2019年5月18日

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

#### 2019年5月19日

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

## LIVE映像

收录于BD《Poppin'Party×SILENT SIREN対バンライブ「NO GIRL NO CRY」atメットライフドーム》中。

## 节目表

### 5月18日

### 5月19日

## 外部链接

（日文）官网演唱会详情

## 注释
