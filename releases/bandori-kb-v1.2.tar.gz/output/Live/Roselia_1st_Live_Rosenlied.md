---
title: Roselia 1st Live Rosenlied
url: https://zh.moegirl.org.cn/Roselia%201st%20Live%20Rosenlied
revision: 8557428
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
---

# Roselia 1st Live Rosenlied

Roselia 1st Live「Rosenlied」是《BanG Dream!》企划组合Roselia的第一场专场演唱会，举办于2017年6月30日。之后于同年7月29日追加一场公演。
演唱会名称Rosenlied是两个德语单词的结合，分别是“Rosen”（玫瑰）和“Lied”（歌曲），这在一定程度上也奠定了R组德语狂魔的基础。

## 简介

举办日期:2017年6月30日
举办地点: shibuya duo MUSIC EXCHANGE

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 远藤祐里香）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 明坂聪美）

## LIVE映像

收录于Roselia的专辑《Anfang》及《Roselia 2017-2018 LIVE BEST -Soweit-》中。

## 节目表

## 追加公演

### 简介

追加公演日期:2017年7月29日
追加公演地点:有明コロシアム

### LIVE映像

收录于Roselia的4th单曲《ONENESS》及《Roselia 2017-2018 LIVE BEST -Soweit-》中。

### 节目表

## 注释

## 外部链接

（日文）官网演唱会详情
（日文）官网演唱会详情(追加公演)
