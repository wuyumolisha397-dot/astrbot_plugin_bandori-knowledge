---
title: BanG Dream! 9th LIVE Mythology
url: https://zh.moegirl.org.cn/BanG%20Dream%21%209th%20LIVE%20Mythology
revision: 8377656
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# BanG Dream! 9th LIVE Mythology

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

BanG Dream! 9th☆LIVE「Mythology」是《BanG Dream!》企划组合RAISE A SUILEN与Morfonica的联合演唱会，举办于2021年9月4、5日。

## 简介

### 概要

举办日期：
2021年9月4、5日(六、日)开场15:30／开演17:00 预定
※开场表演预定于16:30开始
举办地点：富士急ハイランド・コニファーフォレスト

## 出演人员

### 主场

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）
Morfonica
Vo. 仓田真白（CV. 进藤天音）
Gt. 桐谷透子（CV. 直田姬奈）
Ba. 广町七深（CV. 西尾夕香）
Dr. 二叶筑紫（CV. mika）
Vn. 八潮瑠唯（CV. Ayasa）

### 嘉宾

开场嘉宾（From D4DJ）
DJ：各务华梨
DJ：高木美佑
DJ：叶月阳葵

## LIVE影像

收录于《BanG Dream! 9th☆LIVE COMPLETE BOX》中。

## 节目表

### 9月4日

### 9月5日

## 外部链接

（日文）官网「Mythology」演唱会详情
（日文）官网BanG Dream! 9th☆LIVE COMPLETE BOX详情

## 注释
