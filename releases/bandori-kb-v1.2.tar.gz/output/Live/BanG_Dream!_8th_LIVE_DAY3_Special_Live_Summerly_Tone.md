---
title: BanG Dream! 8th LIVE DAY3:Special Live Summerly Tone
url: https://zh.moegirl.org.cn/BanG%20Dream%21%208th%20LIVE%20DAY3%3ASpecial%20Live%20Summerly%20Tone
revision: 8548957
updated: '2026-07-01'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# BanG Dream! 8th LIVE DAY3:Special Live Summerly Tone

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

BanG Dream! 8th☆LIVE 夏の野外3DAYS DAY3:Special Live Summerly Tone是《BanG Dream!》企划组合Poppin'Party、Morfonica、Pastel*Palettes的拼盘演唱会，举办于2020年8月23日。

## 简介

举办日期:2020年8月23日（日）开场15:30/开演17:00
举办地点:富士急ハイランド·コニファーフォレスト
全日本、台湾、韩国、泰国电影院放送。日本国内详情见→Live Viewing情报

## 出演人员

### 主场

Poppin'Party
Vo.&Gt. 户山香澄（CV. 爱美）
Gt. 花园多惠（CV. 大冢纱英）
Ba. 牛込里美（CV. 西本里美）
Dr. 山吹沙绫（CV. 大桥彩香）
Key. 市谷有咲（CV. 伊藤彩沙）
Morfonica
Vo. 仓田真白（CV. 进藤天音）
Gt. 桐谷透子（CV. 直田姬奈）
Ba. 广町七深（CV. 西尾夕香）
Dr. 二叶筑紫（CV. mika）
Vn. 八潮瑠唯（CV. Ayasa）
前岛亚美（Pastel*Palettes 丸山彩 役）

### 嘉宾

协力嘉宾:RAISE A SUILEN（配合前岛亚美演奏）即使在自己专场不打工了还是要在别人场子打工
Raychell (Vo. + Ba.)
小原莉子(Gt.)
夏芽 (Dr.)
仓知玲凤 (Key. + Vo.)
纺木吏佐 (DJ)
协力嘉宾:mika（夏空 SUN! SUN! SEVEN!和八月のif配合Poppin'Party演奏，连跑两节，新一代打工狂魔）
惊喜嘉宾:
上坂堇(Pastel*Palettes白鹭千圣役)(视频出演)
相羽爱奈(安可环节登场)

BanG Dream! 8th☆LIVE 夏の野外3DAYS DAY3:Special Live Summerly Tone













## 节目表

## 演唱会影像

Morfonica部分收录于Morfonica的3rd单曲《ハーモニー・デイ》Blu-ray付生产限定盘，商品编号：BRMM-10436，发售日：2021年10月6日
Poppin'Party部分收录于Poppin'Party的迷你专辑《Live Beyond!!》Blu-ray付生产限定盘，商品编号：BRMM-10424，发售日：2021年8月18日
Pastel*Palettes部分收录于Pastel*Palettes Special Live 「TITLE DREAM」Blu-ray，商品编号：BRMM-10552，发售日：2022年08月03日

## 外部链接

（日文）官网演唱会详情

## 注释
