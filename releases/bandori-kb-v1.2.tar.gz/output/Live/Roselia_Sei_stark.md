---
title: Roselia Sei stark
url: https://zh.moegirl.org.cn/Roselia%20Sei%20stark
revision: 8248441
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Roselia Sei stark

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Roselia「Sei stark」是《BanG Dream!》企划旗下组合Roselia的一次专场演唱会，举办于2025年6月15日。
「Sei stark」是德语，意为「（要）坚强」。

## 简介

### 概要

日期：2025年6月15日 16:30开场／17:30开演
地点：有明アリーナ

### 门票信息

票价
Premium席位（带特典）：22,000日元
一般指定席（带特典）：15,400日元
一般指定席：9,900日元
带注释指定席：8,800日元
抽选日程
最速先行抽选：2024年12月14日 22:00 ～ 2025年2月10日 23:59
抽选申请券封入Roselia 15th Single「礎の花冠」。
Pre Guide先行（抽选）：2025年2月21日 19:00 ～ 3月17日 23:59
Pre Guide二次先行（抽选）：2025年3月29日 12:00 ～ 4月6日 23:59
一般发售（先到先得）：2025年4月20日 12:00 ～

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

#### 开场嘉宾

梦限大MewType
Vo. 仲町阿拉蕾
Gt. 宫永野乃花
Gt. 峰月律
Key. 藤都子
DJ&Mp. 千石由乃

Roselia「Sei stark」出演成员













## LIVE映像

收录于Roselia的18th单曲《Steadfast Spirits》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
