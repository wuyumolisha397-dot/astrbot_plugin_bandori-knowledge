---
title: 梦限大MewType 3rd LIVE Fleeting Moment
url: https://zh.moegirl.org.cn/%E6%A2%A6%E9%99%90%E5%A4%A7MewType%203rd%20LIVE%20Fleeting%20Moment
revision: 8311523
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 虚拟UP主演唱会
---

# 梦限大MewType 3rd LIVE Fleeting Moment

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

夢限大みゅーたいぷ 3rd LIVE「ふりーてぃんぐ もーめんと」是《BanG Dream!》企划旗下组合梦限大MewType的专场演唱会，举办于2025年5月3、4、7日。

## 简介

### 概要

大阪公演
地点：UMEDA CLUB QUATTRO
日期：2025年5月3日（星期六）开场17:00／开演18:00
爱知公演
地点：NAGOYA CLUB QUATTRO
日期：2025年5月4日（星期日）开场16:30／开演17:30
东京公演
地点：Spotify O-EAST
日期：2025年5月7日（星期三）开场18:00／开演19:00

### 门票信息

抽选日程
先行抽选：2025年2月16日 20:00 ～ 3月2日 23:59
票价
站席（附带特制商品）：9,900日元（含税）
站席：7,700日元（含税）
需另行支付饮品费用。
两种门票的观演位置没有优劣区别，全部为随机抽选。
每人最多可申请每场各两张门票。

### 网络直播

东京公演在YouTube（BanG Dream!官频）和bilibili（梦限大MewType官频）直播了开场前三曲内容。

## 出演人员

梦限大MewType
Vo. 仲町阿拉蕾
Gt. 宫永野乃花
Gt. 峰月律
Key. 藤都子
DJ&Mp. 千石由乃

## 节目表/歌单

## 外部链接

（日文）官网演唱会详情
（日文）特典视频观看页

## 注释
