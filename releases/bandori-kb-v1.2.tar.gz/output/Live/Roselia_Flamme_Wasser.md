---
title: Roselia Flamme Wasser
url: https://zh.moegirl.org.cn/Roselia%20Flamme%20Wasser
revision: 8226302
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Roselia Flamme Wasser

《Roselia「Flamme」/「Wasser」》是《BanG Dream!》企划组合Roselia的第六场专场演唱会，举办于2019年8月3、4日。Flamme和Wasser分别是德语的“火”和“水”。

## 简介

举办日期:
Flamme：2019年8月3日(六)
Wasser：2019年8月4日(日)
举办地点: 富士急ハイランド·コニファーフォレスト
日本、韩国、香港和台湾地区电影院放送。

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

Roselia「Flamme」/「Wasser」出演成员









## LIVE映像

收录于Roselia的2nd专辑《Wahl》中。

## 节目表

### Day 1: 「Flamme」

### Day 2: 「Wasser」

## 注释

## 外部链接

（日文）官网演唱会详情
