---
title: Ave Mujica 0th LIVE Primo die in scaena
url: https://zh.moegirl.org.cn/Ave%20Mujica%200th%20LIVE%20Primo%20die%20in%20scaena
revision: 8448978
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Ave Mujica 0th LIVE Primo die in scaena

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Ave Mujica 0th LIVE「Primo die in scaena」是《BanG Dream!》企划组合Ave Mujica的第一场专场演唱会，举办于2023年6月4日。
「Primo die in scaena」是拉丁语，意为「第一次登台」。所以这个看上去很帅，名字中有「die」的演唱会名称，意思其实还蛮可爱的。
TV动画《BanG Dream! It's MyGO!!!!!》中，Ave Mujica的第一场演出与本场演唱会同名。
这场演唱会也是目前企划内唯一一场名义序号为“0”的演唱会。
演唱会当天为满月。

## 简介

### 概要

举办日期：2023年6月4日(日) 开场17:30／开演18:30
举办地点：中野太阳广场

### 门票信息

票价
门票票价为7,150日元（含税）
抽选日程
在2023年2月4日至4月16日于Ave Mujica官方主页内可FC抽选。
在2023年4月17日至4月23日于”再见中野太阳广场音乐祭“官方主页内可先行抽选。
在2023年4月26日至5月7日于pia内可Pre-reserve先行抽选。
在2023年5月13日进行门票一般发售。

### 网络直播与回放

由eplus平台提供付款的网上配信，票价为5,500圆。录像原定将在公演完结7日内可供观看，网上配信门票于2023年5月28日发售。

### 其他

本场演出是《さよなら中野サンプラザ音楽祭》（再见中野太阳广场音乐祭）(注)当时中野太阳广场即将拆除重建，于2023年5月3日至7月2日在此举办的演艺活动均为“再见中野太阳广场音乐祭”的一部分。系列活动之一。

## 出演人员

Ave Mujica
Vo.&Gt. Doloris（CV. 佐佐木李子）
Gt. Mortis（CV. 渡濑结月）
Ba. Timoris（CV. 冈田梦以）
Dr. Amoris（CV. 米泽茜）
Key. Oblivionis（CV. 高尾奏音）

## LIVE映像

收录于Ave Mujica的1st迷你专辑《Alea jacta est》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
