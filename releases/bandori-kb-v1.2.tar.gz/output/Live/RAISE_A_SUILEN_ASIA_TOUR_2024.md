---
title: RAISE A SUILEN ASIA TOUR 2024
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%20ASIA%20TOUR%202024
revision: 8296409
updated: '2026-06-28'
categories:
- BanG Dream!演唱会
---

# RAISE A SUILEN ASIA TOUR 2024

除非特别注明，本页面所有时间皆以东八区时间（UTC+08:00）为准。

RAISE A SUILEN ASIA TOUR 2024是《BanG Dream!》企划组合RAISE A SUILEN名义上的第二次巡回演唱会，分别在连锁音乐厅Zepp旗下位于台北的Zepp New Taipei与上海宛平剧院的大剧场举办。此次巡演亦为BanG Dream!企划组合首次在海外举办的主场演唱会。

## 简介

### 概要

举办日期：
台北公演2024年3月23日(六)开场17:00／开演18:00 预定
上海公演2024年3月30日(六)开演19:00 预定2024年3月31日(日)开演18:00 预定
票价：
台北公演1层站席VIP：3400新台币1层站席：2600新台币2层A区坐席：2800新台币2层B区坐席：2600新台币1层残疾人席位：1200新台币
台北公演VIP特典：成员签名卡，可参加演出结束后的见送会。
上海公演SVIP票：1280元VIP票：1080元一般票：780元
上海公演SVIP特典：印刷签名海报，可观看公开彩排，可参加演出结束后的见送会。

## 出演人员

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

RAISE A SUILEN ASIA TOUR 2024出演成员













## 节目表

## 外部链接

（日文）官网演唱会详情
台北公演票务信息
上海公演票务信息

## 注释
