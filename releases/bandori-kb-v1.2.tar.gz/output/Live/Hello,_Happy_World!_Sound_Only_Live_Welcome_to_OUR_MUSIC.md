---
title: Hello, Happy World! Sound Only Live Welcome to OUR MUSIC
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%20Sound%20Only%20Live%20Welcome%20to%20OUR%20MUSIC
revision: 8557760
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Hello, Happy World! Sound Only Live Welcome to OUR MUSIC

除非特别注明，本页面所有时间皆以东八区时间（UTC+08:00）为准。
《ハロー、ハッピーワールド！ Sound Only Live「うぇるかむ to OUR MUSIC♪」》是《BanG Dream!》企划中所举办的第三场Sound Only Live，也是Hello, Happy World!第一场专场SOL，举办于2021年5月15日、16日。

## 介绍

### 概要

配信日期：2021年5月15日、16日 开演19:00
配信媒体:YouTube LIVE

## 出演人员

Hello, Happy World!
弦卷心（CV. 伊藤美来）
濑田薰（CV. 田所梓）
北泽育美（CV. 吉田有里）
松原花音（CV. 丰田萌绘）
奥泽美咲(米歇尔)（CV. 黑泽朋世）

## 节目表

## LIVE映像

收录于Hello, Happy World!的1st专辑《にこにこねくと！》中。

## 注释

## 外部链接

（日文）官网演唱会详情
