---
title: Ave Mujica 6th LIVE Ulterius Procedere
url: https://zh.moegirl.org.cn/Ave%20Mujica%206th%20LIVE%20Ulterius%20Procedere
revision: 8519008
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Ave Mujica 6th LIVE Ulterius Procedere

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Ave Mujica 6th LIVE「Ulterius Procedere」是《BanG Dream!》企划组合Ave Mujica的第八场专场演唱会，东京公演举办于2025年12月14日、大阪公演举办于2026年1月15日。
「Ulterius Procedere」是拉丁语，意为「继续前进」。

## 简介

### 概要

东京公演
举办日期：2025年12月14日(日) 开场16:30／开演17:30
举办地点：東京国際フォーラム ホールA（东京国际论坛 A厅）
大阪公演
举办日期：2026年1月15日(四) 开场17:30／开演18:30
举办地点：グランキューブ大阪 メインホール（大阪府立国际会议场 主厅）

### 门票信息

票价
特典附S席：19,800日元（含税）
特典附A席：14,300日元（含税）
一般指定席：8,250日元（含税）
抽选日程
最速先行抽选：2025年7月27日 21:00 ～ 8月19日 23:59
抽选申请券封入Ave Mujica 1st Album「Completeness」；每个抽选码可以同时参与两场公演的门票抽选。
Pre Guide先行（抽选）：2025年9月19日 12:00 ～ 10月5日 23:59

### 网络直播与回放

本次演唱会于e-plus提供东京公演付费直播，bilibili上由于“多方面原因”只提供东京公演直播回放。

e-plus票价5500日元，本场演唱会回放保留至21日23:59。
bilibili票价人民币368元，与MyGO!!!!! 8th LIVE「想いのかたちが積もるとき」捆绑售卖，不可单独购买，本场演唱会回放保留至21日北京时间22:59。

### 其他

与「Nova Historia」一样，本场演唱会的歌单依然是Diggy-MO'排的，参与了「Sophie」作编曲的ÐIK也来看了本场演唱会的东京公演。
本次Live有许多新奇的花活如八芒星ダンス的侧手翻，但也出现了一些事故。东京场在演奏天球（そら）のMúsica的时候李子不小心踩空，歌曲结束后有约5分钟的休息（关灯黑幕）时间，在后面的Angles吉他的弦又崩断了。

## 出演人员

Ave Mujica
Vo.&Gt. Doloris（CV. 佐佐木李子）
Gt. Mortis（CV. 渡濑结月）
Ba. Timoris（CV. 冈田梦以）
Dr. Amoris（CV. 米泽茜）
Key. Oblivionis（CV. 高尾奏音）

Ave Mujica 6th LIVE「Ulterius Procedere」

















## LIVE映像

东京公演收录于Ave Mujica的精选专辑《Ave Música》中。

## 节目表

## 外部链接

（日文）官网演唱会详情（东京公演）
（日文）官网演唱会详情（大阪公演）

## 注释
