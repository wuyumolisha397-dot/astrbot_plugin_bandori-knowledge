---
title: Ave Mujica 2nd LIVE Quaerere Lumina
url: https://zh.moegirl.org.cn/Ave%20Mujica%202nd%20LIVE%20Quaerere%20Lumina
revision: 8434478
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Ave Mujica 2nd LIVE Quaerere Lumina

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Ave Mujica 2nd LIVE「Quaerere Lumina」是《BanG Dream!》企划组合Ave Mujica的第三场专场演唱会，神奈川公演举办于2024年6月8日、爱知公演举办于2024年7月7日。
「Quaerere Lumina」是拉丁语，意为「寻找光芒」。
演唱会当天为新月。

## 简介

### 概要

神奈川公演
举办日期：2024年6月8日(六) 开场17:00／开演18:00
举办地点：神奈川県民ホール 大ホール
爱知公演
举办日期：2024年7月7日(日) 开场17:00／开演18:00
举办地点：愛知県芸術劇場 大ホール

### 门票信息

票价
特典附SS席：19,800日元（含税）
特典附S席：14,300日元（含税）
一般指定席：8,250日元（含税）
一般指定席（当日券）：9,350日元（含税）
抽选日程
最速先行抽选：2024年4月24日 10:00 ～ 5月8日 23:59
抽选申请券封入Ave Mujica 1st Single「素晴らしき世界 でも どこにもない場所」。

### 网络直播与回放

神奈川公演由eplus平台提供付款的网上配信，票价为5,500圆。录像在公演完结7日内可供观看，网上配信门票于2024年5月25日发售。

## 出演人员

Ave Mujica
Vo.&Gt. Doloris（CV. 佐佐木李子）
Gt. Mortis（CV. 渡濑结月）
Ba. Timoris（CV. 冈田梦以）
Dr. Amoris（CV. 米泽茜）
Key. Oblivionis（CV. 高尾奏音）

## LIVE映像

神奈川公演的LIVE收录于Ave Mujica 2nd迷你专辑《ELEMENTS》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
