---
title: Pastel*Palettes Sound Only Live Flowerful*
url: https://zh.moegirl.org.cn/Pastel%2APalettes%20Sound%20Only%20Live%20Flowerful%2A
revision: 8557770
updated: '2026-06-27'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
---

# Pastel*Palettes Sound Only Live Flowerful*

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

Pastel*Palettes Sound Only Live「Flowerful*」是《BanG Dream!》企划中所举办的第二场Sound Only Live，也是Pastel*Palettes第一场专场SOL，举办于2021年2月27日、28日。

## 介绍

### 概要

配信日期：2021年2月27日、28日 开演18:00
配信媒体:YouTube LIVE

## 出演人员

Pastel*Palettes
丸山彩（CV. 前岛亚美）
冰川日菜（CV. 小泽亚李）
白鹭千圣（CV. 上坂堇）
大和麻弥（CV. 中上育实）
若宫伊芙（CV. 秦佐和子）

## LIVE映像

收录于Pastel*Palettes的1st专辑《TITLE IDOL》中。

## 节目表

## 注释

## 外部链接

（日文）官网演唱会详情
