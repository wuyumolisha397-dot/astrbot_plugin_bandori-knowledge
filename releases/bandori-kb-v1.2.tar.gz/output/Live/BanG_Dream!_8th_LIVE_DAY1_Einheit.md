---
title: BanG Dream! 8th LIVE DAY1:Einheit
url: https://zh.moegirl.org.cn/BanG%20Dream%21%208th%20LIVE%20DAY1%3AEinheit
revision: 8538403
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# BanG Dream! 8th LIVE DAY1:Einheit

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

《BanG Dream! 8th☆LIVE 夏の野外3DAYS DAY1:Einheit》是《BanG Dream!》企划组合Roselia名义上的第八场专场演唱会，举办于2020年8月21日。Einheit即德语“团结”。

## 简介

### 概要

举办日期:2020年8月21日(四)开场15:30／开演17:00(日本时间)
举办地点:富士急ハイランド・コニファーフォレスト
全日本、台湾、韩国、泰国电影院放送。日本国内详情见→Live Viewing情报

## 出演人员

Roselia
Vo. 凑友希那（CV. 相羽爱奈）
Gt. 冰川纱夜（CV. 工藤晴香）
Ba. 今井莉莎（CV. 中岛由贵）
Dr. 宇田川亚子（CV. 樱川惠）
Key. 白金燐子（CV. 志崎桦音）

### 嘉宾

开场嘉宾:Merm4id
平岛夏海
冈田梦以
叶月阳葵
根岸爱

## LIVE映像

收录于BD《劇場版「BanG Dream! Episode of Roselia」Theme Songs Collection》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
