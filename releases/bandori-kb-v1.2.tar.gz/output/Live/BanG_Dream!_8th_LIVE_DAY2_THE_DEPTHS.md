---
title: BanG Dream! 8th LIVE DAY2:THE DEPTHS
url: https://zh.moegirl.org.cn/BanG%20Dream%21%208th%20LIVE%20DAY2%3ATHE%20DEPTHS
revision: 8480026
updated: '2026-06-30'
categories:
- BanG Dream!演唱会
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# BanG Dream! 8th LIVE DAY2:THE DEPTHS

除非特别注明，本页面所有时间皆以东九区时间（UTC+09:00）为准。

BanG Dream! 8th☆LIVE 夏の野外3DAYS DAY2:THE DEPTHS是《BanG Dream!》企划组合RAISE A SUILEN名义上的第四场专场演唱会，举办于2020年8月22日。
「THE DEPTHS」意为「深渊」。

## 简介

### 概要

举办日期：2020年8月22日(五) 开场16:10／开演17:40
举办地点：富士急ハイランド・コニファーフォレスト
全日本、台湾、韩国、泰国电影院放送。日本国内详情见→Live Viewing情报

### 公布事项

宣布RAS第五张单曲「Sacred world」。

### 其他

和7th一样，这场LIVE没有安可曲。

## 出演人员

### 主场

RAISE A SUILEN
Vo.&Ba. LAYER（CV. Raychell）
Gt. LOCK（CV. 小原莉子）
Dr. MASKING（CV. 夏芽）
Key. PAREO（CV. 仓知玲凤）
DJ CHU²（CV. 纺木吏佐）

### 嘉宾

开场嘉宾：Happy Around!
西尾夕香连演两天
各务华梨
三村遥佳
志崎桦音连演两天*2
其实RAS要打工，也是连演两天

## LIVE映像

收录于RAISE A SUILEN的8th单曲《Domination to world》中。

## 节目表

## 外部链接

（日文）官网演唱会详情

## 注释
