---
title: Raychell
url: https://zh.moegirl.org.cn/Raychell
revision: 8393384
updated: '2026-06-29'
categories:
- 1985年出生
- 1月13日
- 歌手
- 配音演员
- 需要长期关注及更新的条目
- BanG Dream!
- 声优
---

# Raychell

Raychell是日本的女性歌手、声优。

## 经历

2009年12月，为动画《拓麻歌子！》演唱片尾曲。
2010年，为电影《チョルラの詩，ムラサキカガミ，ハダカの美奈子》制作音乐。
2010年，以『Lay』的名义通过avex出道。
2013年，更名为『Raychell』。
2013年，为游戏《龙族教义：黑暗再临》演唱主题曲。
2013年3月，为电影《トラベラーズ 次元警察》制作音乐。
2017年，做为第二主唱加入视觉系乐团SHAZNA。
2018年，做为主唱兼贝斯手成为RAISE A SUILEN的一员。
2019年2月22日，以RAISE A SUILEN贝斯兼主唱的名义在日本武道馆进行了演出。
2020年4月10日，在KT Zepp Yokohama举办了出道十周年纪念演出「"R" WORLD Special Live『I am … RAYCHELL』」。
2022年9月13日，开通个人YouTube频道。
2024年1月1日，宣布入驻小红书。

## 人物

Poppin'Party的大冢纱英为同事务所的后辈，两人曾和夏芽一同以「Raychell feat.大冢纱英」参与LIVE活动。
开始唱歌的契机是小时候参加婚礼时听到的Whitney Houston的I Will Always Love You。也是在livehouse演唱这首歌后被事务所的人搭话，从而进入了现在的事务所。
在做Are you ready to FIGHT的时候曾经想过“要是这次不行的话就放弃吧”，而实际上这张专辑是Raychell和武士道最早的联系(Vanguard NEXT的ED)，与大冢纱英和夏芽在武士道10周年live以3人乐队形式表演的Are you ready to FIGHT也被称为RAS最初的起点。
家中有一个哥哥。
在Live最终排练时会为大家制作大量的饭团。妈妈
除了音乐活动以外，也曾参与舞台剧与电影的演出。
为了练习节奏感而开始弹贝斯。
为了锻炼身体而扔掉了家里所有的椅子，吃饭化妆等活动都是坐在平衡球上进行的。
画伯。与纺木吏佐在Instagram上做过画图直播，十周年纪念Live时还发售了画伯贴纸。
很容易咬舌。在BanG Dream TV#74说自己近期的烦恼是经常在重要的MC咬舌例如把スペシャル(special)读成スペサル(spesal)，得到秦佐和子的建议说就算咬了也要装作没有咬舌继续进行从此在宣传里就把スペサル当スペシャル用了。レイチェルさんは噛んでない！。
继仓知玲凤买了叫くまち的玩偶小熊并让其在Radio RIOT出场后，在美国买了一只彩色的玩偶小老鼠并起名ちぇるち，在Radio RIOT和くまち常常一起用奇怪的声音出场。
座右铭是“Live in the moment”，在和服装品牌LIVERTINEAGE合作制作的外套上也印了这句话。

## 音乐作品

### Blue-ray

### 单曲

### 专辑

### 迷你专辑

### Tie-up曲

## 出演作品

主要角色以粗体显示

### 电视动画

2019年

LAYER————《BanG Dream! 2nd Season》
2020年

姬神纱乃————《D4DJ First Mix》
LAYER————《BanG Dream! 3rd Season》
LAYER————《BanG Dream! Girls Band Party!☆PICO～大份～》
2021年

姬神纱乃————《Puchimiku♪ D4DJ Petit Mix》
花风艾莉娜————《扰乱 THE PRINCESS OF SNOW AND BLOOD》
LAYER————《BanG Dream! Girls Band Party!☆PICO Fever!》
2022年

LAYER————《BanG Dream! 少女乐团派对！5th Anniversary Animation -CiRCLE THANKS PARTY!-》
2025年

LAYER————《BanG Dream! Ave Mujica》
LAYER————《元祖！BanG Dream Chan》

### 剧场版动画

2021年

LAYER————《BanG Dream! FILM LIVE 2nd Stage》
2022年

LAYER————《剧场版 BanG Dream! Poppin'Dream!》
2024年

女歌手————《剧场版草莓王子 开始的物语～Strawberry School Festival!!!～》

### 游戏

2020年

LAYER————《BanG Dream! 少女乐团派对！》
2022年

姬神纱乃————《D4DJ Groovy Mix》

### 舞台剧

2015年

ソフィー·ホーム/Sophie Home————
2016年

バンドウ反派————
2017年

《のど自慢～上を向いて步こう～》
2020年

LAYER————《We are RAISE A SUILEN～BanG Dream! The Stage～》
2021年

花风艾莉娜————《扰乱 THE PRINCESS OF SNOW AND BLOOD》
2026年

阿龟————《剧场版怪化猫 前日谭～二首女～》

### 电影

2017年

敏也是反派————《爱·革命》/《暴走曼谷》

### 广播

2010年10月7日开始于「The Nutty Radio Show おに魂」中的固定环节「LayのTrip Lip」
2013年更名后改为「RaychellのTrip Lip」
2015年1月7日于FM NACK5正式开始个人广播「R WORLD RADIO」，广播助手先后为大冢纱英和志崎桦音
2021年5月14日于FM Odawara开始新广播「RaychellのエンタメLOVERS♡」

### 电视综艺

2015年

12月09日 「THEカラオケ★バトル」2時間スペシャル 最強女子ボーカリスト No.1決定戦
2016年

02月24日 「THEカラオケ★バトル」最強女子ボーカリストNo.1決定戦
2017年

05月10日 「THEカラオケ★バトル」歌の異種格闘技~悲願の初優勝争奪戦

### 电视剧

2014年

Raychell本人————《博多ステイハングリー》

## 注释

## 外部链接

（日文）avex官网
（日文）事务所个人介绍页
（日文）个人推特
（日文）个人Instagram
（日文）个人YouTube频道
个人小红书账号
