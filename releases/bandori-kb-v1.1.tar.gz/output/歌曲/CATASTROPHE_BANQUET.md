---
title: CATASTROPHE BANQUET
url: https://zh.moegirl.org.cn/CATASTROPHE%20BANQUET
revision: 8545172
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Raychell歌曲
- 大桥彩香歌曲
- 工藤晴香歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 黑泽朋世歌曲
---

# CATASTROPHE BANQUET

## 简介

《CATASTROPHE BANQUET》是手游BanG Dream! 少女乐团派对！中的歌曲，由RAISE A SUILEN的主唱兼贝斯手LAYER、Roselia的吉他手冰川纱夜、Poppin'Party的鼓手山吹沙绫、Hello, Happy World!的DJ奥泽美咲以及Morfonica的小提琴手八潮瑠唯组成的 「气势逼人！王道RPG最终BOSS主题乐队（大迫力！王道RPGラスボステーマバンド）」演唱。该组合为第四次BanG Dream!Girls Band Party!总选举中的随机组合之一，并在日服的本次选举中得到最高票数。本曲为该选举中获得第1位奖励的特别制作歌曲。
本曲的完整版收录在纪念专辑《BanG Dream! Dreamer’s Best》中，于2022年3月16日发售。

## 歌曲试听

### Game Ver.

### 完整版

## 歌词

该歌词已还原BK翻译：BurstAlpha

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  冰川纱夜  山吹沙绫  米歇尔  八潮瑠唯  合唱

## BanG Dream! 少女乐团派对！

### EXPERT难度

邦多利第四个29级谱面，第二个EXPERT29级谱面，六兆年EX终于不再孤独。
主要难点：

充满了160BPM下的12分四连硬抗（四连点）（以及一个七连硬抗（六连点）），后半部分很多四连点的结尾还是粉键（相当于240BPM下的8分连点，对比一下六兆年的尾杀8分连续双押只有186BPM）；
几处需要位移接的24分节点起绿条同时吃定位和手速（按歪了慢了直接miss）；
有一处24分七连交互（相当于240BPM下的16分交互，对比下Y.O.L.O！！！！！的劲爆交互也就210BPM下的16分）；
几处32分节点、呈“>”“<”型的绿条；
尾杀的三组三连12分双押接粉双爆发后的三组12分双押-单-双押-粉双需要稳定性，定位（由于摆位问题容易吃邻轨判定），和协调。
比起同为29级的新SP，这张谱的绿条考验并不多，总体和两个29兆年一样，是个底力谱。本曲的等效BPM达到240，很多爆发配置是先前邦邦没有的。因此在某些手速较高的ranker眼里本谱就是个28（
此外，本曲EX难度出分仅次于SOS和A2Z，与EXIST并列第3位。但由于本曲时间过长，加上难度太大，因此无缘效率曲。不过对邦炸人效率很高，EX和hard出分差距还挺大，这点和SOS一样，不过野车SOS还有不少人敢选EX，这首几乎没有

## 注释与外部链接
