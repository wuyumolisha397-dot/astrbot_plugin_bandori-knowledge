---
title: Morfonica翻唱歌曲 - Memento
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - Memento

## Memento

《Memento》由Morfonica演唱。原曲是动画《Re:从零开始的异世界生活》的片尾曲，原唱是nonoc。

### 歌曲试听

#### 游戏版

### 歌词（游戏版）

### 谱面

于第196期活动，即Re:从零开始的异世界生活第二次联动活动「ゼロに還る夏」追加。

#### Expert难度
