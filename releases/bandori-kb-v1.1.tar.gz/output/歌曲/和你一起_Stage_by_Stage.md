---
title: 和你一起 Stage by Stage
url: https://zh.moegirl.org.cn/%E5%92%8C%E4%BD%A0%E4%B8%80%E8%B5%B7%20Stage%20by%20Stage
revision: 8527455
updated: '2026-06-28'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# 和你一起 Stage by Stage

《きみと Stage by Stage》是《BanG Dream!》企划组合Pastel*Palettes的第2张迷你专辑，发售于2025年8月13日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为一张《JR東海 presents 出発進行！バンドリ！10周年記念トークジャーニー！》谈话会巡演的最速先行抽选申请券以及一张角色卡片（共5种）。

## 试听动画

## 收录曲目

## Blu-ray收录内容

Pastel*Palettes特别活动「Together!!」1部&2部公演

## 外部链接

（日文）官网专辑介绍页
