---
title: We Can Hooray Hooray!(单曲)
url: https://zh.moegirl.org.cn/We%20Can%20Hooray%20Hooray%21%28%E5%8D%95%E6%9B%B2%29
revision: 8462510
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题替换的页面
---

# We Can Hooray Hooray!(单曲)

《うぃーきゃん☆フレフレっ！》是《BanG Dream!》企划组合Hello, Happy World!的7th单曲，发售于2020年11月25日。主打曲《うぃーきゃん☆フレフレっ！》的试听动画于2020年10月30日在YouTube上发布。
初回封入特典为原创角色卡片一张（共5种）。

## 单曲试听

## 收录曲目

## 外部链接与注释

试听视频
（日文）官网CD介绍页
