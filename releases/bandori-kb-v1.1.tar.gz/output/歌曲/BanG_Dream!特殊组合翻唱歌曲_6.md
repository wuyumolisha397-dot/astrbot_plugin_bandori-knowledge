---
title: BanG Dream!特殊组合翻唱歌曲 - 创圣的大天使
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 创圣的大天使

## 创圣的大天使

《創聖のアクエリオン》由Poppin'Party、凑友希那（CV.相羽爱奈）共同演唱。原曲是TV动画《创圣的大天使》的第一期片头曲，原唱为AKINO。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.5，发售于2021年2月24日。

### 歌曲试听

Game size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  凑友希那  合唱

### 谱面

第101期活动《恭贺新年 梦物语》追加，作为当期对邦指定曲。
难度在25中不算突出，挑战AP时只需留意结尾减速的部分即可。
猫和猫奴情歌对唱
PPP六人全员集合
