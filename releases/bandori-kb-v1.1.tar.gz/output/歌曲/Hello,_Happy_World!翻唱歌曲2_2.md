---
title: Hello, Happy World!翻唱歌曲2 - 音阶圆舞曲
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - 音阶圆舞曲

## 音阶圆舞曲

《ドレミファロンド》由Hello, Happy World!演唱。原曲是一首VOCALOID传说曲，原唱为初音未来。
完整版收录于VOCALOID翻唱曲合辑，发售于2020年12月16日。

### 歌曲试听

游戏版

完整版

### 歌词

翻译：MIU

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

### EXPERT难度

由于全曲都是三拍子，因此打起来的手感与另一首相同难度的HHW原创曲很接近。
充满40大爷香甜奶粉气息的儿歌（×）
