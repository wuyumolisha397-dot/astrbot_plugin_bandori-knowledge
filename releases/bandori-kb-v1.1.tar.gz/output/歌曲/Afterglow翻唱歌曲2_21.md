---
title: Afterglow翻唱歌曲2 - 注释与外部链接
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545299
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Afterglow翻唱歌曲2 - 注释与外部链接

## 注释与外部链接
