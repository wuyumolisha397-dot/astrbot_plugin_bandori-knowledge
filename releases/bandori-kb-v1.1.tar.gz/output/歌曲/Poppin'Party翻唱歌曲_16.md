---
title: Poppin'Party翻唱歌曲 - Wake up!
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - Wake up!

## Wake up!

《Wake up!》由Poppin'Party演唱。原曲是TV动画《海贼王》的片头曲17，原唱为AAA。

### 歌曲试听

### 歌词

翻译：动漫音乐娘

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

在第65期活动 全体集合！New Year Party！！！ 配信，作为该期对邦指定曲。

#### EXPERT难度

节奏很快，大量容易上手的单双单双配置穿插其中，手感非常舒服。比较难的地方有两个：副歌最后有几组双押+双红，结尾有一些Teardrops SP结尾的弱化。综合难度26级中下，可与Life Will Change争夺PPP最水26的位置。

三田警告！
