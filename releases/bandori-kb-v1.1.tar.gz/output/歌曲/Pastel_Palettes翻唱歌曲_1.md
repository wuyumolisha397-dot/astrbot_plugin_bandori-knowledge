---
title: Pastel*Palettes翻唱歌曲 - secret base～你给我的所有～
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - secret base～你给我的所有～

本条目收录乐队企划《BanG Dream!》中组合Pastel*Palettes的翻唱歌曲。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## secret base～你给我的所有～

《secret base～君がくれたもの～》由Pastel*Palettes演唱。原曲是日本流行乐坛经典名曲。原唱为ZONE。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.1，发售于2018年6月27日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EASY难度

现有的3个5级谱之一，是全游平均密度最低的谱面。

#### HARD难度

整体算是容易的19级，就谱面整体配置可能不到19放现在可能要标17，但FC难度有个人差，主要是中间还是有一些非对称长押容易在初见一不小心手滑/眼残吃判尾good/bad/miss。

#### EXPERT难度

Hard谱面的正统强化，非对称长押的配置在初见情况下容易吃判尾good/bad/miss，但是由于歌曲演奏时间长，音符密度以25级来说意外的低，打熟了以后会觉得是简单的25。在后期新25级难度普遍上升的趋势下，本曲属于逆诈称。放现在可能要标23。由于协力效率过低（2:23秒时长、出分过低），本曲在协力的存在感极低。
