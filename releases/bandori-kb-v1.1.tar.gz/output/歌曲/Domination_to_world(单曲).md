---
title: Domination to world(单曲)
url: https://zh.moegirl.org.cn/Domination%20to%20world%28%E5%8D%95%E6%9B%B2%29
revision: 8461192
updated: '2026-06-28'
categories:
- 2021年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Domination to world(单曲)

《Domination to world》是《BanG Dream!》企划组合RAISE A SUILEN的8th单曲，发售于2021年9月29日。分为Blu-ray付生产限定盘、通常盘两种规格。
专辑试听已于2021年9月6日在YouTube上发布。
初回封入特典：一张巡演演唱会RAISE A SUILEN ZEPP TOUR 2021「BE LIGHT」追加公演的最速先行抽选券，以及一张成员卡片（[Zepp TOUR Ver.]全5种，随机1种）。

## 专辑试听

## 收录曲目

## Blu-ray收录内容

「BanG Dream! 8th☆LIVE」夏の野外3DAYS DAY2：RAISE A SUILEN「THE DEPTHS」
1.Invincible Fighter
2.A DECLARATION OF ×××
3.SOUL SOLDIER
4.UNSTOPPABLE
5.HELL! or HELL?
6.Beautiful Birthday
7.Takin' my Heart
8.激動
9.恋しさとせつなさと心強さと
10.DEPARTURES
11.DRIVE US CRAZY
12.!NVADE SHOW!
813.Sacred world
14.REIGNING
15.EXPOSE 'Burn out!!!'
16.R･I･O･T

## 外部链接

（日文）官网CD介绍页
