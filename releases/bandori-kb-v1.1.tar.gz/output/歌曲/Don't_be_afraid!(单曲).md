---
title: Don't be afraid!(单曲)
url: https://zh.moegirl.org.cn/Don%27t%20be%20afraid%21%28%E5%8D%95%E6%9B%B2%29
revision: 8461193
updated: '2026-06-30'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Don't be afraid!(单曲)

《Don't be afraid!》是《BanG Dream!》企划组合Glitter*Green的唯一一张单曲，发售于2018年11月21日。试听动画于2018年10月1日在YouTube上发布。
与Milky Holmes的最后一张单曲《毎日くらいまっくす☆／そして、群青にとけていく》联动特典兑换券可以在2019年1月28日举办的Milky Holmes Final Live in武道馆(暂名)上兑换一张特别CD，其中收录了Glitter*Green翻唱的这就是原唱吧啊喂PSP游戏《侦探歌剧 少女福尔摩斯》的主题曲《雨上がりのミライ》。

## 试听动画

## 收录曲目

## Blu-ray收录内容

三森すずこ(Glitter*Green 牛込ゆり役)+バックバンド：THE THIRD(仮) ガルパライブ(2018.1.13)
三森すずこ(Glitter*Green 牛込ゆり役)ミルキィホームズ ファンクラブイベント
『ゆくミル くるミル 2016-2017』(2016.12.31)

### Live映像

## 外部链接与注释

试听动画
（日文）官网CD介绍页
