---
title: 心动不已DATE(单曲)
url: https://zh.moegirl.org.cn/%E5%BF%83%E5%8A%A8%E4%B8%8D%E5%B7%B2DATE%28%E5%8D%95%E6%9B%B2%29
revision: 8560531
updated: '2026-07-01'
categories:
- 2026年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 心动不已DATE(单曲)

《どきどきデエト》是《BanG Dream!》企划组合Poppin'Party的22nd单曲，发售于2026年4月29日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为一张BanG Dream! 13th☆LIVE DAY1的最速先行抽选申请券以及一张原创角色卡片（共5种）。
在特定实体或电子商店与Roselia的19单一并购买还会限量赠送特制两团A3海报，并包含爱美（Poppin'Party户山香澄役）和相羽爱奈（Roselia凑友希那役）的签名复制品（共一种）。

## 收录曲目

## Blu-ray收录内容

Poppin'Party New Year LIVE「Happy BanG Year!!」Live映像
Yes! BanG_Dream!
What's the POPIPA!?
開けたらDream!
Hello! Wink!
DOKI DOKI SCARY
前へススメ！
切ないSandglass
Drive Your Heart
Time Lapse
Moonlight Walk
キズナミュージック♪
ぽっぴん'どりーむ！
Encore:

Yes! BanG_Dream!
FIRE BIRD
TARINAI

## 注释和参考链接

## 外部链接

（日文）官网单曲介绍页
