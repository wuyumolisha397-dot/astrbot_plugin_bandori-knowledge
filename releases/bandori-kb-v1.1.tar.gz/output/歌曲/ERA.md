---
title: ERA
url: https://zh.moegirl.org.cn/ERA
revision: 8533954
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- Bushiroad Music音乐单曲
---

# ERA

《ERA》是《BanG Dream!》企划组合RAISE A SUILEN的1st专辑，发售于2020年8月19日。分为Blu-ray付生产限定盘、通常盘两种规格。Blu-ray付生产限定盘还另外赠送「Heaven and Earth」小册子，全52p。
初回封入特典：一张Roselia×RAISE A SUILEN合同ライブ「Rausch und/and Craziness Ⅱ」演唱会的最速先行抽选券，以及一张封面图贴纸（限定盘贴纸有闪亮效果）。
ERA意为时代。

## 收录曲目

## Blu-ray收录内容

RAISE A SUILEN 「Heaven and Earth」 Live映像

## 外部链接与注释

试听动画：
（日文）官网CD介绍页
