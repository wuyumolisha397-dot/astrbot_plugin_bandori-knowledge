---
title: CiRCLING
url: https://zh.moegirl.org.cn/CiRCLING
revision: 8542668
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 带有失效视频的条目
- 日本音乐作品
- 爱美歌曲
- 西本里美歌曲
---

# CiRCLING

## 简介

《CiRCLING》是《BanG Dream!》企划组合Poppin'Party9th单曲《CiRCLING》中的主打歌曲。单曲发售于2018年3月21日。
2021年上映的FILM LIVE 2为安可曲，还是七团35人合唱的。

## 歌曲试听

## 歌词

户山香澄
花园多惠
牛込里美
山吹沙绫
市谷有咲
合唱
翻：Stevie@LoveDream

## BanG Dream! 少女乐团派对！

在第三十期活动 Fun Fun Circling Fivestar 配信，同时是该期对邦指定曲。

### Hard难度

谱面出现了一个地雷玩梗圆形绿条，很容易断combo，可谓ppp目前最难18级，FC难度大于20级的yes bangdream ex。

### EX难度

谱面二次出现了地雷玩梗圆形绿条，很容易断combo，而且总体物量颇高，标25级有诈称味道。

## 曲目联动

本歌曲作为SEGA街机音游音击与BanG Dream!手游的第二波联动曲目，于2018年12月在音击上配信。由于授权到期，于2021年7月8日（RED Plus版本期间）被删除。
BanG Dream本家的玩梗圆形长条在音击谱面中得以重现，但在音击上只需按住对应的按键即可（至于摇杆那是用来操控角色来吃BELL躲炸弹和打滑键的）。

## 外部链接与注释
