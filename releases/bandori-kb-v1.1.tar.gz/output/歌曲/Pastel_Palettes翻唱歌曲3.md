---
title: Pastel*Palettes翻唱歌曲3
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B23
revision: 8496780
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲3

本条目收录乐队企划《BanG Dream!》中组合Pastel*Palettes的翻唱歌曲。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## 最上等的可爱！

《最上級にかわいいの！》由Pastel*Palettes演唱。原唱是超ときめき♡宣伝部。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

### 歌词

### 谱面

#### EXPERT难度

（待补充）

## 想要沉溺于恋爱陷阱

《アイワナムチュー》由Pastel*Palettes演唱。原曲是《福星小子》新版动画的OP2，原唱是asmi。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 恋爱循环

《恋愛サーキュレーション》由Pastel*Palettes演唱。原曲是小说《化物语》衍生TV动画中的歌曲，用作动画“抚子蛇”篇的片头曲，亦是登场角色千石抚子的角色歌。原唱是千石抚子（CV:花泽香菜）。

### 歌曲试听

Game Size

### 歌词

### 谱面

#### EXPERT难度

（待补充）

## 星期五的早上好

《金曜日のおはよう》由Pastel*Palettes演唱。原曲是HoneyWorks创作的一首VOCALOID传说曲，原唱是GUMI。
完整版于2026年3月20日以数字单曲形式发行。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 向着光

《ヒカリへ》由Pastel*Palettes演唱。原曲是电视剧《富贵男与贫穷女》的主题曲，原唱是miwa。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 超最强

《超最強》由Pastel*Palettes演唱，原唱是超ときめき♡宣伝部。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 注释与外部链接
