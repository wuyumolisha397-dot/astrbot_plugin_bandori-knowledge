---
title: BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91Vol.3
revision: 8544296
updated: '2026-06-30'
categories:
- 2019年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 条目中存在只限中国内地播放的音频
- 翻唱专辑
---

# BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3

《バンドリ！ ガールズバンドパーティ！ カバーコレクション Vol.3》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》的3rd翻唱曲专辑，发售于2019年12月18日。分为限定周边付特装盘、通常盘两种规格。
收录了手游五大团和RAISE A SUIREN每团各2首翻唱曲，共12首。

## 歌曲试听

### 逸闻

天使动漫论坛本专辑的发布者在发布时附赠了一张上述特典CD，网易云在添加曲库时误将这首歌加入了本专辑，本格盗传本专辑事实上仅有12首翻唱歌曲。现已删除。

## 收录曲目

## 注释与外部链接

（日文）官网CD介绍页
