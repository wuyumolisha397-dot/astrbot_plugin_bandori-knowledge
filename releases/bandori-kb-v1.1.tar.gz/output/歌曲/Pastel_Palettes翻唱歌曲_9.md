---
title: Pastel*Palettes翻唱歌曲 - SAKURA SKIP
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - SAKURA SKIP

## SAKURA SKIP

《SAKURAスキップ》由Pastel*Palettes演唱。原曲是TV动画《NEW GAME!》的片头曲。原唱为fourfolium。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。

### 歌曲试听

完整版

### 歌词

翻译：千代雪

### 谱面

第三十三期活动《初次挑战！？冬季运动》追加，作为该期挑战曲。

#### EXPERT难度

相当正常的25级，比较需要注意的是副歌结束以后尾奏有类似R‧I‧O‧T式的曲折滑条出现，但因为速度较慢，并不会太困难。
