---
title: SAVAGE
url: https://zh.moegirl.org.cn/SAVAGE
revision: 8528984
updated: '2026-06-28'
categories:
- 2024年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# SAVAGE

《SAVAGE》是《BanG Dream!》企划组合RAISE A SUILEN的2nd专辑，发售于2024年6月12日。分为Blu-ray付生产限定盘、通常盘两种规格。
本专辑包含5首新曲目，以及单曲《Sacred world》、《mind of Prominence》、《EXIST》、《Domination to world》、《THE WAY OF LIFE》、《CORUSCATE -DNA-》和《-N-E-M-E-S-I-S-》中的曲目。
初回封入特典为一张巡演演唱会RAISE A SUILEN ZEPP TOUR 2024-2025「PANDEMONIUM」的最速先行抽选申请券，以及一张全息封面图贴纸（仅Blu-ray付生产限定盘）或一张单角色贴纸（仅通常盘，随机一种，共5种）。

## 收录曲目

## Blu-ray收录内容

BanG Dream! 12th☆LIVE DAY3:REVEAL Live映像
Apocalypse
EXPOSE ‘Burn out!!!’
JUST THE WAY I AM
TWIN TALE
Invincible Fighter
HELL! or HELL?
STRAY CERBERUS
Takin’ my Heart
A DECLARATION OF ×××
BERSER-KEY
-N-E-M-E-S-I-S-
SOUL SOLDIER
DRIVE US CRAZY
R·I·O·T
UNSTOPPABLE
POLARIS
特典映像：成员对焦镜头影像
Apocalypse 【CHU²】
TWIN TALE 【PAREO】
STRAY CERBERUS 【MASKING】
BERSER-KEY 【LOCK】
POLARIS 【LAYER】

## 外部链接

（日文）官网CD介绍页
