---
title: Poppin'Party翻唱歌曲2 - 青鸟
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - 青鸟

## 青鸟

《ブルーバード》由Poppin'Party演唱。原唱为生物股长。原曲为TV动画《火影忍者疾风传》OP3。

### 歌曲试听

### 歌词

### 谱面

95期对邦活动《秋色暖心的信笺》追加，作为该期对邦课题曲。

#### EXRERT难度

不难的25

三田警告（边发Twitter（青鸟（指标志））边打ブルーバード（青鸟（指歌曲）））！
