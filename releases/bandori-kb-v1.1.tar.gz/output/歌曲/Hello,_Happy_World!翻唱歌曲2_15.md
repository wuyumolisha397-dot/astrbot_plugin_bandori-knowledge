---
title: Hello, Happy World!翻唱歌曲2 - 混合坚果
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - 混合坚果

## 混合坚果

《ミックスナッツ》由Hello, Happy World!演唱。原曲是TV动画《间谍过家家》的片头曲。原唱为Official髭男dism。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

该歌是第206期活动その鐘は夜を知らない对邦课题曲。

#### EXPERT难度

又是一首27儿歌（不是）
