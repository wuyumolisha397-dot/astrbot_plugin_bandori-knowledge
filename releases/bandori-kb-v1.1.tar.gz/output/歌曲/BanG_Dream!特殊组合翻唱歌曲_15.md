---
title: BanG Dream!特殊组合翻唱歌曲 - 拿去吧！水手服
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 拿去吧！水手服

## 拿去吧！水手服

《もってけ！セーラーふく》由Hello, Happy World!、户山香澄（CV.爱美）、市谷有咲（CV.伊藤彩沙）、若宫伊芙（CV.秦佐和子）共同演唱。原曲是TV动画《幸运星》的片头曲，原唱是泉此方(CV.平野绫)、柊镜(CV.加藤英美里)、柊司(CV.福原香织)、高良美幸(CV.远藤绫)。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 弦卷心  北泽育美  户山香澄  市谷有咲  若宫伊芙  合唱

### 谱面

#### EXPERT难度

（待补充）
