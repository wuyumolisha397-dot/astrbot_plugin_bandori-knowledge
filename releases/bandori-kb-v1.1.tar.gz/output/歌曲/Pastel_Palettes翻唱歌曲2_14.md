---
title: Pastel*Palettes翻唱歌曲2 - 魔法少女与巧克力
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 魔法少女与巧克力

## 魔法少女与巧克力

《魔法少女とチョコレゐト》由Pastel*Palettes演唱。原曲是VOCALOID传说曲。原唱为初音未来。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

简中服于2024年5月28日第239期活动期间以“5周年纪念翻唱歌曲”名义实装。

#### EXPERT难度
