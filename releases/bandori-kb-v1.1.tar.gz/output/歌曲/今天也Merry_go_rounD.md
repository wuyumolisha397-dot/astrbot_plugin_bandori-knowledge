---
title: 今天也Merry go rounD
url: https://zh.moegirl.org.cn/%E4%BB%8A%E5%A4%A9%E4%B9%9FMerry%20go%20rounD
revision: 8543428
updated: '2026-06-28'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

# 今天也Merry go rounD

《きょうもMerry go rounD》是企划《BanG Dream!》旗下组合Morfonica的迷你专辑Forte中的曲目，专辑发售于2023年12月6日。

## 简介

官方歌词MV于2023年10月5日在YouTube发布。
本曲描写了主唱仓田真白内心的挣扎和痛苦，以及克服困难坚强的一面。

## 歌曲

## 歌词

该歌词已还原BK翻译：Mikoi

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 仓田真白  桐谷透子  广町七深  二叶筑紫  八潮瑠唯  合唱

## 注释与外部链接
