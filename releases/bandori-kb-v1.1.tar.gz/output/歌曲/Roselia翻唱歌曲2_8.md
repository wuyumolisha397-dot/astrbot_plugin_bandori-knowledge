---
title: Roselia翻唱歌曲2 - KING
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - KING

## KING

《KING》由Roselia演唱。原曲是Kanaria创作的VOCALOID歌曲。原唱为GUMI。
相比原曲，前奏有所缩短，最后一句“YOU ARE KING”也被去除。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

完整版

### 歌词

### 谱面

#### EXRERT难度

唱到“YOU ARE KING”时会有“K”形状的绿条
不太好对付的27（中上左右），难点如下：
1. 副歌绿接粉（8分间隔），一共出现6组，考验手速
2. 间奏的连打，移位的规律有点复杂，长度也不短，需要留意
3. 第二次副歌的四连红双押（8分间隔）
4. 尾杀，节点取24分音的高密度滑条（容易让你挑战FC时功败垂成笔者初见就经历过了）
除此之外，本谱面在2:02秒内（只比RB长了1秒）塞入了高达1000整的物量，因此对耐力要求很高。打歌耐力较差者建议不要长时间周回本谱面。
