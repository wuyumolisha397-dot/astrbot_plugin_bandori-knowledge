---
title: Fly with the night(单曲)
url: https://zh.moegirl.org.cn/Fly%20with%20the%20night%28%E5%8D%95%E6%9B%B2%29
revision: 8461203
updated: '2026-06-28'
categories:
- 2022年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题替换的页面
---

# Fly with the night(单曲)

《fly with the night》是《BanG Dream!》企划组合Morfonica的4th单曲，发售于2022年3月30日。分为Blu-ray付生产限定盘、通常盘两种规格。

## 收录曲目

## Blu-ray收录内容

Morfonica Special Live「Andante」
《fly with the night》MV

## 注释及外部链接

（日文）官网CD介绍页
