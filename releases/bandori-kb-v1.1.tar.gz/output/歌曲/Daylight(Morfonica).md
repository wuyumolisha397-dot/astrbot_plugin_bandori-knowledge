---
title: Daylight(Morfonica)
url: https://zh.moegirl.org.cn/Daylight%28Morfonica%29
revision: 8544331
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- 使用标题格式化的页面
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

# Daylight(Morfonica)

《Daylight -デイライト- 》是企划《BanG Dream!》旗下组合Morfonica的第一张单曲《Daylight -デイライト-》的主打歌，单曲于2020年05月27日发售。

## 简介

该歌曲的MV于2020年3月1日发布，真人MV于2020年3月25日发布。

## 歌曲

游戏版

完整版

动画MV

真人MV

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 仓田真白  桐谷透子  广町七深  二叶筑紫  八潮瑠唯  合唱

## BanG Dream! 少女乐团派对！

拥有MV演出，但由于本曲MV以蓝色为主色调，对读谱有很大影响

#### Expert难度

虽说有845个Note，但排不进26密度前10，时长2分2秒——意味着效率中低还不是很好打。
前奏和B melo妖娆的绿条隔壁HHW：？？？宣示着小提琴那厚重的存在感，附带的乱打也些许展示着鼓手的实力……编不下去了。
进副歌前一小段，和开fever后的密度略高；曲终前最后的绿条应该是某种特殊的形状？

MV模式

LIVE2D模式

#### Special难度

日服4周年追加SP谱面。采用了新note类型，而且造成了各处难度很高的配置，满满的初见杀。开头的绿条是很明显的蝴蝶状。

## 注释与外部链接
