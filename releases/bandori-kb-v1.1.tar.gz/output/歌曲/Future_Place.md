---
title: Future Place
url: https://zh.moegirl.org.cn/Future%20Place
revision: 8545632
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 日本音乐作品
- 爱美歌曲
- 西本里美歌曲
---

# Future Place

## 简介

《Future Place》是《BanG Dream!》企划组合Poppin'Party的原创歌曲。为游戏第201期活动『Campus Beat!!』的主题曲。完整版收录于Mini专辑《青春 To Be Continued》中，于2023年5月31日发售。

## 歌曲试听

## 歌词

翻译：步飞破应援组
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  花园多惠  牛込里美  山吹沙绫  市谷有咲

## BanG Dream! 少女乐团派对！

### EXPERT难度

## 注释及外部链接
