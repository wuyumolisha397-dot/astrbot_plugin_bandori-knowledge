---
title: Hello, Happy World!翻唱歌曲 - 向日葵的约定
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542918
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲 - 向日葵的约定

## 向日葵的约定

《ひまわりの約束》由Hello, Happy World!演唱。原曲是剧场版动画《哆啦A梦：伴我同行》的主题曲。原唱为秦基博。
完整版收录于Hello, Happy World! 2nd专辑《SMILE ON PARADE》Disc2，发售于2023年6月28日。

### 歌曲试听

完整版

### 歌词

翻译：莎士比亚书店

### 谱面

#### EXPERT难度

hhw最简单的一首ex，难度仅为21，慢节奏而又好听的歌曲，可以很放松地去打，但是AP的难度远高于隔壁另一首21。
六周年荣升为23级，这就体现了上面AP难度这点。
