---
title: Pastel*Palettes翻唱歌曲2 - Sparkling Daydream
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - Sparkling Daydream

## Sparkling Daydream

《Sparkling Daydream》由Pastel*Palettes演唱。原曲是TV动画《中二病也要谈恋爱！》的片头曲，原唱是ZAQ。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.7，发售于2022年12月14日。

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度
