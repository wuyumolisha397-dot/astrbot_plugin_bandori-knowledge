---
title: Hello, Happy World!翻唱歌曲2 - SHINY DAYS
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - SHINY DAYS

## SHINY DAYS

《SHINY DAYS》由Hello, Happy World!演唱。原曲是TV动画《摇曳露营△》的OP。原唱为亚咲花。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

谱面大部分看起来是个23，但是开头的一段滑条、进入副歌前的小楼梯以及副歌中出现的两次32分小三角都是超出23级范畴的配置，实际难度约为24中位到25下位（有个人差）。HHW的23都这么喜欢搞诈称吗？
