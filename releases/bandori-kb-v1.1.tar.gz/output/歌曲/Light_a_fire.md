---
title: Light a fire
url: https://zh.moegirl.org.cn/Light%20a%20fire
revision: 8545652
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 带有失效视频的条目
- 日本音乐作品
- 纺木吏佐歌曲
---

# Light a fire

「Light a fire」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲。

## 简介

本曲MV公开于2022年3月23日，这也是RAS的首个真人MV，完整版收录于2022年4月27日发售的RAISE A SUILEN的9th单曲《CORUSCATE -DNA-》中。
本曲于「OVERKILL」上被首次演奏。

## 歌曲

完整版

完整版MV

## 歌词

该歌词已还原BK

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

## 外部链接与注释
