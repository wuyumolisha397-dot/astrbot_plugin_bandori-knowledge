---
title: Hello, Happy World!翻唱歌曲2 - 橙色少女心
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - 橙色少女心

## 橙色少女心

《オレンジ》由Hello, Happy World!演唱。原曲是TV动画《龙与虎》的第二首片尾曲。原唱为逢坂大河(CV:钉宫理惠)&栉枝实乃梨(CV:堀江由衣)&川岛亚美(CV:喜多村英梨)。
完整版收录于Hello, Happy World! 2nd专辑《SMILE ON PARADE》Disc2，发售于2023年6月28日。

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

国服以庆祝2周年名义于2021年6月5日超前实装。

#### EX难度

（待补充）
