---
title: 青春 To Be Continued(专辑)
url: https://zh.moegirl.org.cn/%E9%9D%92%E6%98%A5%20To%20Be%20Continued%28%E4%B8%93%E8%BE%91%29
revision: 8505214
updated: '2026-07-01'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
---

# 青春 To Be Continued(专辑)

《青春 To Be Continued》是《BanG Dream!》企划组合Poppin'Party的第二张迷你专辑，发售于2023年5月31日。分为Blu-ray付生产限定盘、通常盘两种规格。

## 专辑介绍

Poppin'Party的新迷你专辑终于发布啦！
以“永远的青春”为主题创作出全新的歌曲，用以名为《青春 To Be Continued》的新歌曲作为主打歌。收录了面向智能手机的游戏《BanG Dream! 少女乐团派对！》中发布的原创歌曲《Future Place》《大好き！》和《Five Letters》，并且，《BanG Dream! 少女乐团派对！》迎来了6周年，popipa升了一年级之后开始的全新生活，充满了欢欣雀跃和悸动不已的新篇章故事的歌曲《RiNG A BELL》，并且收录了Poppin'Party送给全世界的应援歌，由HoneyWorks制作的《最強☆ソング》。全专辑共计收录6首新曲子！
Blu-ray付生产限定盘中收录了2022年9月在有明Arena举行的BanG Dream! 10th☆LIVE DAY3 : Poppin'Party「Hoppin'☆Poppin'☆Dreamin'!!」！
另外，Blu-ray付生产限定盘中附赠了使用演唱会照片制作而成的相片册。
希望大家能够入手这份充满了Poppin'Party闪闪发光而令人心动的青春的作品。

## 歌曲试听

## 收录曲目

## Blu-ray收录内容

BanG Dream! 10th☆LIVE DAY3：Poppin'Party「Hoppin'☆Poppin'☆Dreamin'!!」

## 相册

Blu-ray付生产限定盘中包含通常盘中没有的使用演唱会照片制作而成的相片册。

## 初回生产限定封入特典

预定于2023年11月3日（周五）举行的《BanG Dream! 12th☆LIVE DAY1 : Poppin'Party 「Welcome to Poppin'Land」》的最速先行抽选申请券
预定于2023年8月11日（周五）举行的Poppin'Party线下活动《ぽぴばん！のおでかけin SUMMER》的最速先行抽选申请券
随机可替换封面1张（共计五种）

Poppinland年票风格塑料卡片（Blu-ray付生产限定盘限定）

## 外部链接

（日文）官网专辑介绍页面
