---
title: Everyday flower
url: https://zh.moegirl.org.cn/Everyday%20flower
revision: 8546275
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小写标题
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
---

# Everyday flower

「everyday flower」是企划《BanG Dream!》旗下组合Pastel*Palettes演唱的歌曲。为游戏第207期活动『グッナイ・センチメンタル』（对伤感说晚安）的主题曲。

## 歌曲试听

## 歌词

翻译：面向局外的边缘人（网易云音乐）

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙

## BanG Dream! 少女乐团派对！

### 谱面

由于丸山彩声优前岛亚美活动暂停，日服第207期活动开展期间并没有立即追加此歌曲。
各区服追加此歌曲的时间参见下表：

#### EXPERT难度

（待补充）

## 注释及外部链接
