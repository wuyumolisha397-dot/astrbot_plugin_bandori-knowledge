---
title: Poppin'Party翻唱歌曲 - GLAMOROUS SKY
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - GLAMOROUS SKY

## GLAMOROUS SKY

《GLAMOROUS SKY》由Poppin'Party演唱。原曲是电影《NANA》的主题曲。原唱为中岛美嘉。

### 歌曲试听

### 歌词

翻译：红鲤鱼与绿鲤鱼与鹿与驴与栗与梨

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### HARD难度

比较简单的17级，谱面中没有绿条节点大触玩家可以用这首歌练习All Great的超没素质玩法（神仙请移步Happy Synthesizer的EX）如果GBP也有0dan。

#### EXPERT难度

谱面密度较低，也没有什么过于卡手的配置，在如今新26难度普遍偏高的形势下，本曲难度已成为26下位。由于演奏时长比较长、理论HSR偏低且协力效率也低，因此在游戏中显得很没存在感，协力请慎选。但和Hard一样也是没有滑条，可以All Great的谱面（仅有的6张可AG的EX谱面之一。而且推上的确有人做到了）。
