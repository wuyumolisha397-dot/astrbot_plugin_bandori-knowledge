---
title: Roselia翻唱歌曲 - The Everlasting Guilty Crown
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - The Everlasting Guilty Crown

## The Everlasting Guilty Crown

《The Everlasting Guilty Crown》由Roselia演唱。原曲是TV动画《罪恶王冠》第2期的片头曲。原唱为EGOIST。
该歌曲在很长一段时间内只在日服上线。直到国服和台服分别在2021年1月22日及4月1日实装。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

该谱面曾经被很多玩家认为是26级中的魔王，尤其是副歌部分的连续移位双押DNA双押，读谱比较难，是部分玩家冲击FC/AP的障碍之一。但在目前新26整体难度偏高的形势下，该谱面充其量算是一个中上等26，没到诈称水平。
