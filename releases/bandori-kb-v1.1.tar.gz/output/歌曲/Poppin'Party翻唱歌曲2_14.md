---
title: Poppin'Party翻唱歌曲2 - 星夜之雪
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - 星夜之雪

## 星夜之雪

《スターナイトスノウ》由Poppin'Party演唱。原曲是「雪未来 2017」主题曲。原唱为初音未来。

### 歌曲试听

### 歌词

### 谱面

日服于2022年12月24日15点追加。
国服于2023年12月24日13点追加。

#### EXPERT难度
