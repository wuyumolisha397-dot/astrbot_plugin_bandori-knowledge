---
title: RAISE A SUILEN翻唱歌曲 - Keep the Heat and Fire Yourself Up
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - Keep the Heat and Fire Yourself Up

## Keep the Heat and Fire Yourself Up

《Keep the Heat and Fire Yourself Up》由RAISE A SUILEN演唱。原曲是TV动画《霸穹 封神演义》OP。原唱为Fear, and Loathing in Las Vegas。
本曲是RAISE A SUILEN翻唱的第一首全英文歌词的歌曲。完整版收录于RAISE A SUILEN 9th单曲《CORUSCATE -DNA-》（B形态），发售于2022年4月27日，成为本企划中首批被收录进原创单曲CD的翻唱曲之一。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  CHU²

### 谱面

#### EXPERT难度
