---
title: Brand new Pastel Road!
url: https://zh.moegirl.org.cn/Brand%20new%20Pastel%20Road%21
revision: 8545116
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 秦佐和子歌曲
---

# Brand new Pastel Road!

## 简介

《Brand new Pastel Road!》是《BanG Dream!》企划旗下组合Pastel*Palettes演唱的歌曲，是Garupa Station的4.5周年特别节目上公开的Tie-up曲中的第四首。
完整版先于2022年3月26日配信，后收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc1，发售于2023年5月31日。

## 歌曲

完整版

QQ音乐

完整版MV

## 歌词

翻译：Sisterのnoise

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

## 注释及外部链接
