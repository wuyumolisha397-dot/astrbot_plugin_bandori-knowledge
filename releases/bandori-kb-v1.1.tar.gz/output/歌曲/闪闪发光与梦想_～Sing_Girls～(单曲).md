---
title: 闪闪发光与梦想 ～Sing Girls～(单曲)
url: https://zh.moegirl.org.cn/%E9%97%AA%E9%97%AA%E5%8F%91%E5%85%89%E4%B8%8E%E6%A2%A6%E6%83%B3%20%EF%BD%9ESing%20Girls%EF%BD%9E%28%E5%8D%95%E6%9B%B2%29
revision: 8550485
updated: '2026-07-01'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
---

# 闪闪发光与梦想 ～Sing Girls～(单曲)

《キラキラだとか夢だとか ～Sing Girls～》是《BanG Dream!》企划组合Poppin'Party的5th单曲，同时也是TV动画的片尾曲专辑，发售于2017年2月15日。宣传映像于2017年1月28日在YouTube上发布。
初回封入特典为TV动画《BanG Dream!》OP＆ED主题曲与Weiß Schwarz Trial Deck联动礼物活动报名券、角色卡等。各店铺特典为贴纸、徽章等。封入特典为Weiß Schwarz PR卡1枚。

## 宣传映像

## 收录曲目

## 外部链接与注释

宣传映像
（日文）官网CD介绍页
