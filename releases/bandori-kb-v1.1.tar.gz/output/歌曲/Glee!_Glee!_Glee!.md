---
title: Glee! Glee! Glee!
url: https://zh.moegirl.org.cn/Glee%21%20Glee%21%20Glee%21
revision: 8542686
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Glitter*Green歌曲
- 三森铃子歌曲
- 佐佐木未来歌曲
- 带有失效视频的条目
- 德井青空歌曲
- 插曲
- 日本音乐作品
- 橘田泉歌曲
---

# Glee! Glee! Glee!

## 简介

《Glee! Glee! Glee!》是TV动画《BanG Dream!》第13话的插曲，由Glitter*Green演唱。收录于TV动画OST。发售于2017年4月26日。
2018年11月21日Glitter*Green发售了唯一一张单曲《Don't be afraid!》，收录了该曲的完整版作为C/W曲。

## 歌曲

## 歌词

翻译来源：网易云音乐

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

本曲作为TV动画第一季中登场的歌曲，却在接近6年的一段极长时间内未被游戏收录，和小星星一起成为有生之年系列的一员。
在游戏6周年时，官方宣布将在周年当天追加本曲，是Glitter*Green在游戏内第一次追加歌曲。（当然他们只有2首原创歌曲，而且原来的那首是开服之初已有的歌曲。）

## 注释与外部链接
