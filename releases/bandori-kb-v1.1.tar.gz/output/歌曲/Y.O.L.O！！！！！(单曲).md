---
title: Y.O.L.O！！！！！(单曲)
url: https://zh.moegirl.org.cn/Y.O.L.O%EF%BC%81%EF%BC%81%EF%BC%81%EF%BC%81%EF%BC%81%28%E5%8D%95%E6%9B%B2%29
revision: 8527484
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Y.O.L.O！！！！！(单曲)

《Y.O.L.O！！！！！》是《BanG Dream!》企划组合Afterglow的4th单曲，发售于2019年2月20日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2019年1月3日在YouTube上发布。
初回封入特典为角色卡片一张（共5种），及预计在2019年春季后举办的活动抽选申请卷。
在各店铺与RAISE A SUILEN2nd单曲《A DECLARATION OF ×××》一同购入还将赠送特典BD一张，内容为「RAISE A SUILEN スタジオライブ」。

## 试听动画

## 收录曲目

## Blu-ray收录内容

迷你动画《BanG Dream! Girls Band Party!☆PICO》 #19 ~ #26

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
