---
title: High Five Adventure
url: https://zh.moegirl.org.cn/High%20Five%20Adventure
revision: 8543308
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Hello, Happy World!歌曲
- 丰田萌绘歌曲
- 伊藤美来歌曲
- 使用标题替换的页面
- 吉田有里歌曲
- 带有失效视频的条目
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 田所梓歌曲
- 黑泽朋世歌曲
---

# High Five Adventure

## 简介

《ハイファイブ∞あどべんちゃっ》是《BanG Dream!》企划组合Hello, Happy World!的4th单曲《ハイファイブ∞あどべんちゃっ》中的主打歌曲。单曲于2019年2月20日发售。

## 歌曲试听

Game Size

完整版

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

第四十八期活动《HELLO HAPPY大冒险！~藏有笑容的宝岛~》追加曲目。

### EXPERT难度

极其考验玩家底力的正统26级谱面。接近200的BPM和超过850的物量，非常考验玩家的手速和耐力，7.29的平均物量密度在全游也属于较高水平。据天堂EGHD大佬的说法，本曲EX前半段和后半段的谱面offset貌似有差别

### SPECIAL难度

第一百五十三期活动はぐみとハッピーダイナソー追加，作为该期挑战曲。

## 外部链接与注释
