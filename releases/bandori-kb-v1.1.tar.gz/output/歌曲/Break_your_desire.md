---
title: Break your desire
url: https://zh.moegirl.org.cn/Break%20your%20desire
revision: 8544316
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# Break your desire

## 简介

《Break your desire》是《BanG Dream!》企划组合Roselia 2nd 专辑《Wahl》中的曲目。专辑于2020年7月15日发售。
本曲是2019年7月23日举行的第三回「BanG Dream! Girls Band Party!总选举」优胜特别制作的新歌曲。因为总选举系列的传统，本曲成为Roselia第一首以ACG角色形象出现在封面的原创曲。这封面，确定没跑错片场？本曲还是Roselia有史以来第一首bpm破200的原创曲。
因为总选举主题的原因，乐曲以“接受挑战”和“对邦live”为主题，但作词走向和Roselia上一首对邦曲PASSIONATE ANTHEM相差不小。而且作词也不是织田明日香。

## 歌曲试听

Game size

完整版

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  冰川纱夜  今井莉莎  宇田川亚子  白金燐子  合唱

## BanG Dream! 少女乐团派对！

#### Expert难度

BPM205的底力谱，你确定这是26？这就不是26！
本曲诈称较严重，但比起那三个26还差了点，难度更是超过了某丢人27
开头：这是26？ 打完：这是26？
但是认真的讲，本曲难度仅仅在于高bpm的交互，在绿条、粉键和读谱上基本毫无难点，算是和玩家“正面决胜负”的底力谱，标个26也在情理之中。
六周年难度标级调整荣升27

## 外部链接与注释
