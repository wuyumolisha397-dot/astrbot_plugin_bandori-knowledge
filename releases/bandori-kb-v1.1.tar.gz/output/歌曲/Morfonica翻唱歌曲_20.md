---
title: Morfonica翻唱歌曲 - Overdose
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - Overdose

## Overdose

《Overdose》由Morfonica演唱。原唱是なとり。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

简中服于2024年5月29日第239期活动期间以“5周年纪念翻唱歌曲”名义实装。

#### EXPERT难度

（待补充）
