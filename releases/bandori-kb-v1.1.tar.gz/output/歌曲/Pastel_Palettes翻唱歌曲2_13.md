---
title: Pastel*Palettes翻唱歌曲2 - 这么可爱真是抱歉
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 这么可爱真是抱歉

## 这么可爱真是抱歉

《可愛くてごめん》由Pastel*Palettes成员冰川日菜（CV.小泽亚李）、白鹭千圣（CV.上坂堇）、大和麻弥（CV.中上育实）、若宫伊芙（CV.秦佐和子）演唱。原曲是HoneyWorks制作的告白实行委员会系列原创歌曲。原唱为かぴ。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

完整版

### 歌词

### 谱面

（待补充）
