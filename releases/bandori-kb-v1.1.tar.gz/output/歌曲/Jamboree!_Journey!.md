---
title: Jamboree! Journey!
url: https://zh.moegirl.org.cn/Jamboree%21%20Journey%21
revision: 8542697
updated: '2026-06-30'
categories:
- Afterglow歌曲
- BanG Dream!音乐
- C/W曲
- 三泽纱千香歌曲
- 佐仓绫音歌曲
- 加藤英美里歌曲
- 日本音乐作品
- 日笠阳子歌曲
- 条目中存在只限中国内地播放的音频
- 金元寿子歌曲
---

# Jamboree! Journey!

## 简介

《Jamboree! Journey!》是《BanG Dream!》企划组合Afterglow的3rd单曲《ツナグ、ソラモヨウ》中的C/W曲。单曲于2018年10月31日发售。

## 歌曲试听

完整版

## 歌词

翻译：LoveDream字幕组

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 美竹兰  青叶摩卡  上原绯玛丽  宇田川巴  羽泽鸫  合唱

## BanG Dream! 少女乐团派对！

第三十七期活动《奔跑！夕阳下的巡游之旅》追加曲目。

### EXPERT难度

AG早期25，只需留意300combo左右双手非对称绿条，以及最后大转折绿条划到位即可，总体上不难。

## 注释与外部链接
