---
title: DOKI DOKI SCARY
url: https://zh.moegirl.org.cn/DOKI%20DOKI%20SCARY
revision: 8547273
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 爱美歌曲
- 西本里美歌曲
---

# DOKI DOKI SCARY

「DOKI DOKI SCARY」是企划《BanG Dream!》旗下组合Poppin'Party演唱的歌曲。为游戏第276期活动『Let's make a Horror Movie!!!!!』的主题曲。

## 歌曲试听

## 歌词

该歌词已还原BK

歌曲翻译：歩飛破应援组
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  花园多惠  牛込里美  山吹沙绫  市谷有咲

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

（待补充）

## 注释及外部链接
