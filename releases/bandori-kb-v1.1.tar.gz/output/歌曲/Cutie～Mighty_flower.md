---
title: Cutie～Mighty*flower
url: https://zh.moegirl.org.cn/Cutie%EF%BD%9EMighty%2Aflower
revision: 8543340
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 仓知玲凤歌曲
- 前岛亚美歌曲
- 夏芽歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
- 西本里美歌曲
---

# Cutie～Mighty*flower

## 简介

きゅ～まい＊flower是《BanG Dream!》企划组合Pastel*Palettes5th单曲《きゅ～まい＊flower》中的主打歌曲，同时也在TV动画《BanG Dream! 2nd Season》第13话中被用作插曲。单曲于2019年9月18日发售。
本曲亦有由スキを貫け♡（坚持所爱♡）（牛込里美（CV.西本里美）、大和麻弥（CV.中上育实）、MASKING（CV.夏芽）、PAREO（CV.仓知玲凤））演唱的平行歌曲版本，于2026年1月4日在各音乐平台配信。

## 歌曲试听

TV size

完整版

平行歌曲

## 歌词

## BanG Dream! 少女乐团派对！

日服于2026年1月3日追加SPECIAL难度。

### EXPERT难度

都说了PP26级原创没一个简单的你们怎么还不信！好啦现在有WGSP啦
开局就给你一个Afterglow级别的交互，中盘又存在一部分HHW级别的滑条和PP祖传的绿条白点交互组合，而全曲还到处贯穿着Roselia级别的红键配置，单红、一白一红、双红等基础红键配置应有尽有。仍然是局部看起来很简单，但综合起来就会各种爆炸各种断Combo的配置，再加上位居PP原创曲第二的BPM（仅次于SURVIVOR Never Give Up!），中上位26级的难度是有的，但仍然比天下AZ弱一些。
另外本曲时长比天下AZ只长1秒，而且出分和效率也颇高。

### FULL EXPERT难度

3分37秒的长度是目前完整版谱面最短的。由于后半只是重复游戏版的配置，即使在完整版长度加持之下也只是27级下位水平，耐力比较好的人会觉得它是26。

### Parallel Ver.

日服于2026年1月3日追加，谱面与原版谱面一致。
有关Parallel Vocals，详见此条目。

## 外部链接与注释
