---
title: Beautiful Birthday
url: https://zh.moegirl.org.cn/Beautiful%20Birthday
revision: 8544325
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# Beautiful Birthday

「Beautiful Birthday」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲，也是TV动画《BanG Dream! 3rd Season》第11话、第13话的插入曲。

## 简介

本曲第11话版本收录于2020年4月8日发售的《TV动画2&3季OST》中，Remix版（完整版）收录于2020年8月19日发售的RAISE A SUILEN的1st专辑《ERA》中。
在动画中是由PAREO为CHU²所写的生日告白歌曲，第11话中为一般配置乐器演奏，第13话中加入了CHU²演唱部分与DJ合成器音效，两个版本的演唱方式也有不同。
本曲是手游活动第117期「RAISE A SUILEN～御簾を上げろ～（後編）」的活动曲，日服实装于2020年8月31日。
本曲于舞台剧「We are RAISE A SUILEN～BanG Dream! The Stage～」上被首次演奏，于演唱会上的首次演奏则是在「THE DEPTHS」上。

## 歌曲试听

TV Anime Size

完整版

## 歌词

翻译：黑骸
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

### 歌词彩蛋

歌词里满含成员们对CHU²想说的话所以并不只是PAREO一个人的情歌而是来自全员的表白。

「冷えた夢に　突き刺さった光　眩しいまま」→LOCK上京以来一直想要组乐队，然而过了近半年也没有眉目，直到CHU²在演唱会上将聚光灯打在她身上并宣言要招揽她。（动画2nd&3rd Season）
「僕のすべて 抱きしめた」→LOCK为了能够上京而做出的一切。（漫画、动画2nd Season）
「地獄だって構わない　あなたの元で生きれるなら」→CHU²宣布要击溃Roselia时，意识到CHU²逐渐偏离初心的PAREO所做出的觉悟。（舞台剧）
「カミサマなんて　要らないくらいの　完璧なBeautiful World」→因为遇见了CHU²，PAREO的本性和欲望得以释放。陪在CHU²身边的机会对她来说是无比珍贵的宝物。（漫画、动画3rd Season、舞台剧）
「理解されずに　なじられても　進もう」→被人尊称为“狂犬”的MASKING，同时又被人所忌惮。真心想要组乐队的她被一次又一次地拒绝了。（漫画、舞台剧）
「あなたがいる　居場所がある」→只有CHU²……只有RAS能够接受MASKING狂犬般的鼓点。（漫画、舞台剧）
「震わせた右脳左脳　ヤケドするような衝撃で　与えられたリリック」→武道馆支援演出结束后，CHU²交给LAYER的《R·I·O·T》音源。（动画2nd Season、舞台剧）
「欠けたココロ」→在支援工作中逐渐失去自我、忘记初心、变成工作机器的LAYER。（漫画、舞台剧）

## BanG Dream! 少女乐团派对！

### EXPERT难度

EXPERT谱面除了频繁出现的连打之外毫无难点，会打即可轻松FC。

## 注释与外部链接
