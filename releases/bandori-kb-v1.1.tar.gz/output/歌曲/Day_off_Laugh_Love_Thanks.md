---
title: Day off Laugh Love Thanks
url: https://zh.moegirl.org.cn/Day%20off%20Laugh%20Love%20Thanks
revision: 8547419
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
- 需要翻译的条目
---

# Day off Laugh Love Thanks

「デイオフ・ラフ・ラブ・サンクス」是企划《BanG Dream!》旗下组合Pastel*Palettes演唱的歌曲，为游戏第290期活动『花咲く季節のオフショット』（花开季节的幕后剪影）的主题曲。

## 歌曲试听

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

（待补充）

## 注释及外部链接
