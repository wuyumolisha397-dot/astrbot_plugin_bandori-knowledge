---
title: Roselia翻唱歌曲2 - STYX HELIX
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - STYX HELIX

## STYX HELIX

《STYX HELIX》由Roselia演唱。原曲是动画《Re:从零开始的异世界生活》第一季的片尾曲。原唱为MYTH & ROID。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

●26下位难度，且BPM不算高，比较容易全连
●496combo处出现了甘城OP式转折大滑条的弱化版
●一些16分交互之间夹杂了一些24分音或粉键
