---
title: Furetto Palette Fight Song!!
url: https://zh.moegirl.org.cn/Furetto%20Palette%20Fight%20Song%21%21
revision: 8547262
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
---

# Furetto Palette Fight Song!!

「フレっとパレットFight Song!!」是企划《BanG Dream!》旗下组合Pastel*Palettes演唱的歌曲。为游戏第257期活动『Step Together』的主题曲。

## 歌曲试听

## 歌词

该歌词已还原BK
翻译：鲨鱼字幕组

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

（待补充）

## 注释及外部链接
