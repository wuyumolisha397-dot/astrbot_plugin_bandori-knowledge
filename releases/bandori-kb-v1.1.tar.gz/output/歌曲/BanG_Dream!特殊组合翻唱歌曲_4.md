---
title: BanG Dream!特殊组合翻唱歌曲 - 革命Dualism
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 革命Dualism

## 革命Dualism

《革命デュアリズム》由Roselia和美竹兰（CV.佐仓绫音）共同演唱。原曲是TV动画《革命机Valvrave》的片头曲。原唱为水树奈奈×T.M.Revolution。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.2，发售于2019年3月16日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：奈亚拉托提普

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  美竹兰  合唱

### 谱面

美竹兰是本曲中的水树部分担当……五主唱翻水树进度3/5

#### EXPERT难度

谱面继承了Roselia26级谱面一贯的综合型风格，中间也有考验爆发力的205BPM16分五连、九连小交互这交互，很Afterglow。作为高BPM曲，手速当然是硬性要求，但本曲的采音还是很好的，难度控制适中的标准26级，构不成诈称。
奶一口sp27
