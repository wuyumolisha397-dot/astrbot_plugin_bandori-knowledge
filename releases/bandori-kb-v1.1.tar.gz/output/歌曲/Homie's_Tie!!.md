---
title: Homie's Tie!!
url: https://zh.moegirl.org.cn/Homie%27s%20Tie%21%21
revision: 8558863
updated: '2026-06-28'
categories:
- BanG Dream!音乐
- 一家Dumb Rock!歌曲
- 使用标题替换的页面
- 凉泉樱花歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 橘芽衣歌曲
- 花宫初奈歌曲
- 菱川花菜歌曲
- 远野光歌曲
---

# Homie's Tie!!

「ホーミー・タイッ！！」是企划《BanG Dream!》旗下组合一家Dumb Rock!的第一支原创歌曲。于2026年3月2日作为数字独立单曲发售。

## 歌曲试听

## 歌词

翻译：Aki惊蛰
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 须贺蕾叶  马桥心玖

## 注释及外部链接
