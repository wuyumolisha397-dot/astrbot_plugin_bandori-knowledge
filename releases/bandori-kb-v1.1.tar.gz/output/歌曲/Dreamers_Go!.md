---
title: Dreamers Go!
url: https://zh.moegirl.org.cn/Dreamers%20Go%21
revision: 8543339
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 插曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 爱美歌曲
- 西本里美歌曲
---

# Dreamers Go!

## 简介

《Dreamers Go!》是《BanG Dream!》企划组合Poppin'Party 14th 单曲《Dreamers Go!/Returns》中的主打歌。单曲于2019年5月15日发售。
设定上是由户山香澄作词作曲例如大好き　止まらない！这种歌词……。而且香澄和本曲真正的作曲菊田大介的生日都是在夏天（菊田大介为8.12）。
在TV动画《BanG Dream!》第二季的第12、13话用作插曲，其中12话是户山香澄单独演唱的版本。

## 歌曲试听

Game Size

Full Size

## 歌词

该歌词已还原BK

歌曲翻译：LoveDream字幕组
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  花园多惠  牛込里美  山吹沙绫  市谷有咲

## BanG Dream! 少女乐团派对！

本曲的正式版游戏内封面采用了"专辑封面图+单曲名称"的假封面形式（即游戏内封面只有Dreamers Go!的标题，Returns同理），而非完全使用原专辑封面。邦邦手游中使用这种假封面的单曲还有八月的if、B.O.F和Light Delight、HEROIC ADVENT、轨迹和Legendary。
本曲在第二季动画中的Live影像在2019年8月21日作为MV追加进游戏中。

### EXPERT难度

（待补充）

## 外部链接与注释
