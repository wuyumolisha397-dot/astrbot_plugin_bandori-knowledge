---
title: '''S/'' The Way / Sophie'
url: https://zh.moegirl.org.cn/%27S%2F%27%20The%20Way%20%2F%20Sophie
revision: 8542111
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

《'S/' The Way / Sophie》是《BanG Dream!》企划组合Ave Mujica的第三张单曲，于2025年12月10日发售。该单曲分为数量限定生产特装盘、Blu-ray付生产限定盘与通常盘三种规格。初回生产分限定封入特典包括Ave Mujica LIVE TOUR 2026「Exitus」最速先行抽选申请券（申请时间为东京时间2025年12月14日至2026年1月18日）、一张角色卡片（共五种）以及一张《卡片战斗先导者》PR卡。购买数量限定生产特装盘额外附赠一个亚力克板。在特定实体或电子商店购买该单曲，限量赠送包含Ave Mujica 5th LIVE「Nova Historia」曲目的特典CD（共五种，不限规格）。

Blu-ray付生产限定盘与通常盘的封面区别在于丰川祥子裙摆上的水印不同，分别为「Sophie」和「S/」。此外，该单曲另有Ave Mujica音响制作人Diggy-MO'演唱的Demo Mix版本《Sophie / 'S/' The Way -ver.D-》，于2026年4月17日起在Ave Mujica LIVE TOUR 2026「Exitus」巡演会场限定发售。这一版本伴奏与正式版本不同，两首歌的序号顺序相反，且封面非纯黑，印有Diggy-MO'手写的单曲名、签名及手绘的上帝之眼（仅眼睛部分）。这也是《BanG Dream!》企划第一张Demo Mix唱片。

数量限定生产特装盘封面上有一对被斜线隔开的颠倒的「$」符号，该符号来自Diggy-MO'对「S/」的写法。在雅克·拉康的精神分析理论中，符号「$」代表被划杠的主体，即分裂的、非完整自主的主体，亦见于拉康的欲望公式「$◇a」中。

该单
