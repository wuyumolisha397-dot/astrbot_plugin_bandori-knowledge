---
title: THRONE OF ROSE(单曲)
url: https://zh.moegirl.org.cn/THRONE%20OF%20ROSE%28%E5%8D%95%E6%9B%B2%29
revision: 8543172
updated: '2026-06-28'
categories:
- 2023年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
---

# THRONE OF ROSE(单曲)

《THRONE OF ROSE》是《BanG Dream!》企划组合Roselia的13th单曲，发售于2023年4月26日。分为Blu-ray付生产限定盘、凑友希那Ver.、冰川纱夜Ver.、今井莉莎Ver.、宇田川亚子Ver.与白金燐子Ver.六种规格。
试听动画于2023年4月7日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：一张2023年Roselia单独Live的抽选券，以及一张对应版本的角色卡片。

## 试听动画

## 收录曲目

## Blu-ray收录内容

BanG Dream! 10th☆LIVE DAY1:Sonnenschein Live映像
1.THE HISTORIC...
2.BRAVE JEWEL
3.Opera of the wasteland
4.PASSIONATE ANTHEM
5.Ringing Bloom
6.“UNIONS” Road
幕间映像Ⅰ
7.Determination Symphony
8.Swear ～Night & Day～
9.Sprechchor
10.陽だまりロードナイト
11.R
12.overtuRe
13.FIRE BIRD
幕间映像Ⅱ
ENCORE
1.ROZEN HORIZON
2.－HEROIC ADVENT－

## 外部链接

（日文）官网CD介绍页
