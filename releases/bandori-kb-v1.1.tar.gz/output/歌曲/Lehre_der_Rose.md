---
title: Lehre der Rose
url: https://zh.moegirl.org.cn/Lehre%20der%20Rose
revision: 8557395
updated: '2026-06-28'
categories:
- 2026年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# Lehre der Rose

《Lehre der Rose》是《BanG Dream!》企划组合Roselia的十周年精选专辑，预定发售于2026年8月26日。分为数量限定生产特装盘、Blu-ray付生产限定盘和通常盘三种规格。

## 简介

本专辑共收录24首Roselia的原创歌曲，其中包含于2026年2月15日至3月16日在Roselia十周年特设网站上进行的歌曲投票活动中所选出的10首歌曲。
专辑中歌曲《PASSIONATE ANTHEM》、《陽だまりロードナイト》、《礎の花冠》、《BLACK SHOUT》、《FIRE BIRD》及《VIOLET LINE》均为十周年的实演音源版本。
数量限定生产特装盘只在Roselia的现场演唱会场地及武士道在线商店限定发售，包含特制三边盒套、高箱尺寸内封和纪念手册，并且附赠特制双陆棋套装商品、纪念盒以及《Roselia ASIA TOUR「Neuweltfahrt」》巡演旗帜。Blu-ray付生产限定盘仅包含特制纸套。
初回封入特典为一张Roselia专场演唱会（预定于2027年举办）的最速先行抽选券以及一张角色卡片（共6种）。
官方还于2026年8月29至30日举办本专辑的发售纪念演唱会。

## 收录曲目

## Blu-ray收录内容

Disc 1

Roselia ASIA TOUR「Neuweltfahrt」东京公演 -Final- 两日Live映像
Disc 2

Roselia ASIA TOUR「Neuweltfahrt」大阪·东京公演 幕间映像（角色设定不可崩!!：Roselia的宝岛篇）
Disc 3（数量限定生产特装盘限定）

Roselia ASIA TOUR「Neuweltfahrt」大阪公演 Live映像
Roselia ASIA TOUR「Neuweltfahrt」新加坡公演 定点映像
Song I am
約束
Roselia ASIA TOUR「Neuweltfahrt」首尔公演 定点映像
Neo-Aspect
FIRE BIRD
Roselia ASIA TOUR「Neuweltfahrt」台北公演 定点映像
R
BRAVE JEWEL
Roselia ASIA TOUR「Neuweltfahrt」大阪追加公演 DAY2 定点映像
陽だまりロードナイト
Steadfast Spirits

## 外部链接

（日文）官网专辑介绍页
（日文）Roselia十周年特设网站
（日文）武士道在线商店的生产特装盘商品页
