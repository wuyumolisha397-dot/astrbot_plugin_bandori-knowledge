---
title: Pastel*Palettes翻唱歌曲2 - 飞舞！小魔女
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 飞舞！小魔女

## 飞舞！小魔女

《DANCE! おジャ魔女》由Pastel*Palettes演唱。原曲是动画《小魔女DoReMi 大合奏》的OP，原唱是MAHO堂。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

小魔女DoReMi联动追加。

#### EXPERT难度

与这次联动的另一首曲子一样，由于Fever段安排不甚合理，协力出分不怎么样，低于天下AZ hard和点兔ED2。个人出分比较好，比点兔ED2高一点点。
主体配置只是25下位程度，但红尾变轨绿条双押部分需要注意避免手按在错误轨道。
