---
title: Fear Nothing(单曲)
url: https://zh.moegirl.org.cn/Fear%20Nothing%28%E5%8D%95%E6%9B%B2%29
revision: 8545270
updated: '2026-06-28'
categories:
- 2026年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Fear Nothing(单曲)

《Fear Nothing》是《BanG Dream!》企划组合Roselia的19th单曲，发售于2026年4月29日。分为Blu-ray付生产限定盘以及通常盘两种规格。
初回封入特典为一张十周年精选专辑《Lehre der Rose》发售纪念演唱会的最速先行抽选券以及一张角色卡片（共五种）。
在特定实体或电子商店与Poppin'Party的22单一并购买还会限量赠送特制两团A3海报，并包含爱美（Poppin'Party户山香澄役）和相羽爱奈（Roselia凑友希那役）的签名复制品（共一种）。

## 收录曲目

## Blu-ray收录内容

Roselia Special Live「Stolz」 Live映像
BLACK SHOUT
Requiem for Fate
BRAVE JEWEL
R
Neo-Aspect
Ringing Bloom
FIRE BIRD
ENCORE

Re:birth day
Dazzle the Destiny
BLACK SHOUT

## 参考资料

## 外部链接

（日文）官网单曲介绍页
