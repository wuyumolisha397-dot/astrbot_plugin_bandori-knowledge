---
title: Roselia翻唱歌曲2 - 乙女解剖
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - 乙女解剖

## 乙女解剖

《乙女解剖》由Roselia演唱。原曲是由DECO*27创作的VOCALOID歌曲，原唱是初音未来。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）
