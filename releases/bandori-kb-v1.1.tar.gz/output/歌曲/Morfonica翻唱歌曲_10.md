---
title: Morfonica翻唱歌曲 - COLORFUL BOX
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - COLORFUL BOX

## COLORFUL BOX

《COLORFUL BOX》由Morfonica演唱。原曲是动画《白箱》的OP1，原唱是石田燿子。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.7，发售于2022年12月14日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

第159期活动ガールズ・ビー・アンビシャス！追加，作为该期挑战曲。

#### Expert难度

第四首物量超过800的25级，但是由于歌曲十分平缓，节奏很均匀，再加上有一些多节点绿条的存在，使得整张谱面并不会让人很有压迫感，算是中位25。时长超过2分钟，所以协力效率也不佳。
