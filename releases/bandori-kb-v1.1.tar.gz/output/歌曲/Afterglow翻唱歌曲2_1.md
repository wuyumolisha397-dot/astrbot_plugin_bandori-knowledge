---
title: Afterglow翻唱歌曲2 - 疮痂
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545299
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《カサブタ》是日本多媒体企划《BanG Dream!》旗下女子乐队Afterglow的一首翻唱歌曲。Afterglow由美竹兰（主唱）、青叶摩卡（吉他）、上原绯玛丽（贝斯）、宇田川巴（鼓手）和羽泽鸫（键盘手）五位成员组成，以青春活力、朋克摇滚的风格著称。这首《カサブタ》原为电视动画《金童卡修》的第一期片头曲，由千绵伟功演唱，是一首节奏明快、充满少年热血感的经典动画歌曲。

Afterglow的翻唱版本在保留原曲激昂旋律的基础上，融入了乐队特有的吉他驱动和紧凑鼓点，主唱美竹兰富有穿透力的嗓音赋予歌曲新的能量。该曲的完整版收录于Afterglow的第二张专辑《STAY GLOW》的Disc2中，专辑于2023年4月26日正式发售。这首翻唱曲在游戏《BanG Dream! 少女乐团派对！》中亦有收录，作为可游玩曲目，深受玩家喜爱。

作为Afterglow翻唱曲库中的重要曲目，《カサブタ》展现了乐队驾驭经典热血摇滚的能力，也延续了Afterglow一贯积极向上的音乐气质。歌曲在粉丝群体中反响热烈，被视为Afterglow现场演出中点燃气氛的必备曲目之一。通过这首翻唱，Afterglow不仅向原曲致敬，也进一步巩固了自身在《BanG Dream!》音乐宇宙中的独特定位。
