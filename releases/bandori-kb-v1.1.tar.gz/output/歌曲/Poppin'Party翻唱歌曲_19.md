---
title: Poppin'Party翻唱歌曲 - 白日梦咖啡店
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - 白日梦咖啡店

## 白日梦咖啡店

《Daydream café》由Poppin'Party演唱。原曲是TV动画《请问您今天要来点兔子吗》的片头曲，原唱为Petit Rabbit's。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3，发售于2019年12月18日。
佐仓绫音：为什么翻唱这首歌不叫上我！Bushiroad：樱小姐，要不再唱十遍号哭缓解一下？

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  花园多惠  牛込里美  山吹沙绫  市谷有咲  合唱

### 谱面

该歌是《请问您今天要来点兔子吗？》第二季联动活动追加曲之一。

#### EXPERT难度

音符密度有点高，但是节奏还是容易掌握，也没有奇怪的绿条配置/红尾绿条，FC难度不高。其实本曲虽然BPM仅150，但是节奏紧凑，采谱很明显有所保留，这歌可以做难的。←奶一口出sp

一般皮肤：
联动皮肤特效：
