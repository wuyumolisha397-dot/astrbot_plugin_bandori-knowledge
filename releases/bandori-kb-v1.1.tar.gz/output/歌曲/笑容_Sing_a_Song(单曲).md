---
title: 笑容 Sing a Song(单曲)
url: https://zh.moegirl.org.cn/%E7%AC%91%E5%AE%B9%20Sing%20a%20Song%28%E5%8D%95%E6%9B%B2%29
revision: 8540392
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 笑容 Sing a Song(单曲)

《えがお･シング･あ･ソング》是《BanG Dream!》企划组合Hello, Happy World!的5th单曲，发售于2019年8月21日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为「BanG Dream! 3rd Season」制作发表会＆BanG Dream! Xmas Party 2019的抽选申请卷。

## 试听动画

## 收录曲目

## Blu-ray收录内容

动画《BanG Dream! 2nd Season》 #7~#8
Web版下回预告 #7~#8
动画《BanG Dream! 2nd Season》CM Hello, Happy World! 篇

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
