---
title: 两翼的Brilliance(单曲)
url: https://zh.moegirl.org.cn/%E4%B8%A4%E7%BF%BC%E7%9A%84Brilliance%28%E5%8D%95%E6%9B%B2%29
revision: 8461227
updated: '2026-06-28'
categories:
- 2024年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 两翼的Brilliance(单曲)

《両翼のBrilliance》是《BanG Dream!》企划组合Morfonica的6th单曲，发售于2024年5月1日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为《Morfonica Concept LIVE「ff」》的最速先行抽选申请券以及一张原创角色卡（共5种）。

## 收录曲目

## Blu-ray收录内容

Morfonica ZEPP TOUR 2023「forte」东京公演Live映像

## 外部链接

（日文）官网CD介绍页
