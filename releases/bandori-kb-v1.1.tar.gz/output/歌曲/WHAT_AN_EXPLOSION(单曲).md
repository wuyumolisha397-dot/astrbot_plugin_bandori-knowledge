---
title: WHAT AN EXPLOSION(单曲)
url: https://zh.moegirl.org.cn/WHAT%20AN%20EXPLOSION%28%E5%8D%95%E6%9B%B2%29
revision: 8545276
updated: '2026-06-28'
categories:
- 2026年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# WHAT AN EXPLOSION(单曲)

《WHAT AN EXPLOSION》是《BanG Dream!》企划组合RAISE A SUILEN的15th单曲，发售于2026年6月10日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为一张BanG Dream! 13th☆LIVE DAY3的最速先行抽选申请券以及一张原创角色卡片（共5种）。生产限定盘的角色卡片有一定几率包含角色亲笔签名，且包装与通常盘的角色卡片略有不同。

## 试听动画

## 收录曲目

## Blu-ray收录内容

RAISE A SUILEN 2DAYS LIVE「RUMBLEHEADZ」Live映像
DAY2:

'FIGHT' ADDICT
Invincible Fighter
SOUL SOLDIER
DEAD HEAT BEAT
BIBIBABI BRAVER
THE WAY OF LIFE
V.I.P MONSTER
VIVID FIRST TIME
REIGNING
FIVE as ONE
HOWLING AMBITION
JUST THE WAY I AM
HELL! or HELL?
ENCORE:

A DECLARATION OF ×××
Bad Kids All Bet
DRIVE US CRAZY
DAY1部分歌曲Live映像:

UNSTOPPABLE
OUTSIDER RODEO
!NVADE SHOW!
EXPOSE ‘Burn out!!!’

## 外部链接

（日文）官网单曲介绍页
