---
title: Completeness
url: https://zh.moegirl.org.cn/Completeness
revision: 8542119
updated: '2026-06-28'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# Completeness

《Completeness》是《BanG Dream!》企划组合Ave Mujica的第一张专辑，发售于2025年4月23日。分为5,000枚限定生产特装盘、Blu-ray付生产限定盘与通常盘三种规格。
5,000枚限定生产特装盘采用豪华包装盒进行包装（约W25cm×H8cm)，包含专辑CD、特典Blu-ray、带有封面插图的特殊亚克力立牌（共5种，约W6cm×H15cm）以及动画中登场的Mortis充气挂饰（约W9cm×H12cm)，但只在武士道在线商店（ブシロードオンラインストア）独家限量销售。
初回生产分限定封入特典为Ave Mujica 6th LIVE「Ulterius Procedere」的最速先行抽选申请券以及一张角色卡片（共5种；另有5种附带烫印角色签名）。
在特定实体或电子商店购买该专辑将限量赠送包含Ave Mujica 4th LIVE「Adventus」中演唱曲目的特典CD（共5种；不限购买规格）。
在特定实体或电子商店与MyGO!!!!!的六单一并购买还会限量赠送CRYCHIC纪念色纸（不限购买规格）。
官方还于2025年6月至8月间于日本各地举办该专辑的发售纪念握手会。
本专辑的完全生产限定盘（黑胶唱片）于2026年5月20日发售。

## 试听动画

## 收录曲目

### CD

### 黑胶

Disc1-A

KiLLKiSS
Georgette Me, Georgette You
Imprisoned XII

Disc1-B

Crucifix X
八芒星ダンス

Disc2-A

顔
天球（そら）のMúsica

## Blu-ray收录内容

Ave Mujica 4th LIVE「Adventus」Live影像
黒のバースデイ
ふたつの月 ~Deep Into The Forest~
Choir 'S' Choir
神さま、バカ
Mas?uerade Rhapsody Re?uest
Ave Mujica
素晴らしき世界 でも どこにもない場所
Angles
Symbol I : 🜂
Symbol II : 🜁
Symbol III : 🜄
Symbol IV : 🜃
Ether
KiLLKiSS

## 握手会

## 注释和参考链接

## 外部链接

（日文）官网CD介绍页
（日文）发售纪念握手会介绍页
（日文）官网完全生产限定盘介绍页
