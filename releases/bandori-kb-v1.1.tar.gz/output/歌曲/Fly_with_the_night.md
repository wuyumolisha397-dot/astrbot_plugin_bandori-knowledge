---
title: Fly with the night
url: https://zh.moegirl.org.cn/Fly%20with%20the%20night
revision: 8545127
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- 小写标题
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

# Fly with the night

## 简介

《fly with the night》是《BanG Dream!》旗下组合Morfonica的第四张单曲《fly with the night》的主打曲，单曲于2022年3月30日发售。

## 歌曲试听

Game size

完整版

## 歌词

该歌词已还原BK
翻译：面向局外的边缘人

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 仓田真白  桐谷透子  广町七深  二叶筑紫  八潮瑠唯  合唱

## BanG Dream! 少女乐团派对！

### 谱面

本曲是日服在2021年10月10日举办的Morfonica二章活动的课题曲目。

#### Expert难度

并没有任何能称得上是26级的配置，除了副歌部分的大跨度绿条之外，其他地方的难度都大概落在25级中位，比起其他三个标成26级的二章曲，本曲明显是比较容易的，给它标成25级也不过分。

## 外部链接与注释
