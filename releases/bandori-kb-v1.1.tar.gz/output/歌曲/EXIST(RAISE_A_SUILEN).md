---
title: EXIST(RAISE A SUILEN)
url: https://zh.moegirl.org.cn/EXIST%28RAISE%20A%20SUILEN%29
revision: 8545045
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 使用标题格式化的页面
- 夏芽歌曲
- 小原莉子歌曲
- 扰乱 THE PRINCESS OF SNOW AND BLOOD音乐
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 片头曲
- 纺木吏佐歌曲
---

# EXIST(RAISE A SUILEN)

「EXIST」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲，也是TV动画《扰乱 THE PRINCESS OF SNOW AND BLOOD》的片头曲。

## 简介

本曲收录于2021年4月21日发售的RAISE A SUILEN的7th单曲《EXIST》中，后又收录于2024年6月12日发售的RAISE A SUILEN的2nd专辑《SAVAGE》中。
本曲于「BE LIGHT」上被首次演奏。

## 歌曲

《扰乱》NCOP

游戏版

完整版

## 歌词

翻译：BurstAlpha

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

国服以RAS登场的名义随RAS一同实装。

### Expert难度

RAS新晋效率曲，各项数据与Jumpin'近似︰时长、效率和NPS皆一样，Notes数仅比Jumpin'少1个。然而BPM只有140 (Jumpin'为195)，因此难度上较为友善。
出分仅次于SAVIOR OF SONG的EX难度和SP难度，为全服第3位。
效率也仅次于SOS EX和SP、A2Z EX和ALIVE EX，为全服第5位，但由于SOS是令手残闻风丧胆的标称28，A2Z EX是卡手点众多的上位26，ALIVE绿条易断连，相比之下这首歌就是儿歌中的儿歌，FC及AP难度都远不如标定的26级水平，对于打不动28级SOS的人来说应该是最优选择，因此协力里本曲更受青睐，尤其是活动结束前2天内。但是同样的条件下，SOS EX打出90%的P率（约77gr）时出分仍能和EXIST AP持平，打出80%的P率（约154gr）时效率才降到EXIST AP水平，因此如果能通关SOS，追求效率的时候仍然推荐打SOS。

## 外部链接与注释
