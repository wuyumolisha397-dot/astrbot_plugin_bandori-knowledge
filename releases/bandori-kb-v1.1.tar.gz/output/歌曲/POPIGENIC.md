---
title: POPIGENIC
url: https://zh.moegirl.org.cn/POPIGENIC
revision: 8540485
updated: '2026-07-01'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# POPIGENIC

《POPIGENIC》是《BanG Dream!》企划组合Poppin'Party的3rd专辑，发售于2025年2月26日。分为Blu-ray付生产限定盘、通常盘两种规格。
本专辑包含4首新曲目，以及单曲《Photograph》、《ぽっぴん'どりーむ！》、《夏に閉じこめて》、《新しい季節に》和《TARINAI/トレモロアイズ》中的曲目。
专辑封面与1st单曲《Yes! BanG_Dream!》的封面非常相似。
初回封入特典为一张Poppin'Party New Year LIVE「Happy BanG Year!!」的最速先行抽选申请券以及一张角色卡片（共5种）。

## 试听动画

## 收录曲目

## Blu-ray收录内容

Poppin'Party LIVE 2024「Poppin'Canvas 〜芸術の秋、音楽の秋！〜」 Live映像
キラキラだとか夢だとか ～Sing Girls～
ときめきエクスペリエンス！
青春 To Be Continued
What's the POPIPA!?
Home Street
キズナミュージック♪
星の約束
怪獣の花唄
走り始めたばかりのキミに
TARINAI
Time Lapse
Moonlight Walk
ENCORE：

トレモロアイズ
ティアドロップス

## 外部链接

（日文）官网CD介绍页
