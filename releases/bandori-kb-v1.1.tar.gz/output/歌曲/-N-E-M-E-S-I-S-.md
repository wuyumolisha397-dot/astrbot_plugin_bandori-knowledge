---
title: -N-E-M-E-S-I-S-
url: https://zh.moegirl.org.cn/-N-E-M-E-S-I-S-
revision: 8547250
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

《-N-E-M-E-S-I-S-》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的原创歌曲，收录于2023年6月28日发售的同名11th单曲中。曲名源自希腊语“涅墨西斯”，意为“复仇”，在希腊神话中象征冷酷无情的报应女神。歌曲的A段旋律采用中东风格，但希腊实际位于南欧而非中东，这一对比成为乐曲的独特话题。该曲首次在演唱会“EXCLAMATION HIGHLAND”上演奏。在手机游戏《BanG Dream! 少女乐团派对！》中，本曲于2023年11月5日在日服追加，同年12月31日随“年末倒计时歌曲追加庆典”在简体中文服上线。作为RAISE A SUILEN的代表作品之一，《-N-E-M-E-S-I-S-》延续了乐队充满力量感和节奏冲击力的风格，歌词与旋律共同传递出强烈的戏剧性与复仇主题，展现了乐队成员LAYER、LOCK、MASKING、PAREO、CHU²在演奏与演唱上的协作能力。
