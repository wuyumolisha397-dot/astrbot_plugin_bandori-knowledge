---
title: Hello, Happy World!翻唱歌曲2 - 小魔女嘉年华！！
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - 小魔女嘉年华！！

## 小魔女嘉年华！！

《おジャ魔女カーニバル!!》由Hello, Happy World!演唱。原曲是TV动画《小魔女DoReMi》的OP，原唱为MAHO堂。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.5，发售于2021年2月24日。

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 弦卷心  濑田薰  北泽育美  松原花音  合唱

### 谱面

小魔女DoReMi联动活动追加。

#### EXPERT难度

时长仅93秒，HHW第三短歌曲，但由于Fever段的位置问题，协力模式下效率并不是很高。若在对邦模式下，时间效率依然略低于难度仅21的アイウエ黄谱，HSR分数也不算好，远不及同为25的龙王和船SP。
