---
title: RAISE A SUILEN翻唱歌曲 - 激动
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - 激动

## 激动

《激動》由RAISE A SUILEN演唱。原曲是TV动画《驱魔少年》OP4。原唱为UVERworld。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.3，发售于2019年12月18日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  CHU²

### 谱面

#### EXPERT难度

套路：又是RAS，之前的三首RAS曲都水，那这首肯定也是水歌
本曲一改之前三首RAS曲的温柔难度，在谱面中动用了大量16分混合连打、短条、斜短条、红键的复合配置；此外在副歌前也出现了高密度转折滑条，Rebel One段落更是出现了红尾短绿条，提升了谱面的整体技巧要求，拉高了整体难度。但所幸BPM不高，整体上是中规中矩的26级，可作为其他连打型和技巧性谱面的前置练习曲。

#### SPECIAL难度

相比于EXPERT难度的谱面，SPECIAL难度的采音更加细致，而且谱面中添加了更多的锁手16分三连等配置，对底力要求还是比较高的，而且从504combo-522combo出现了很长的16分单键双押交替的配置，并且在之后还出现了16分四连双押接双押横滑113BPM? 226BPM! ，底力不是很够的小伙伴很容易在这里爆很多slow Great乃至miss。不仅如此，谱面中还有较多的32分小三角和271combo处的32分5连交互，爆发不是很好的小伙伴也容易在这里爆Great。相较于大量的单手16分多连，SPECIAL谱面中弯曲绿条以及横滑却非常中规中矩，没有太多碍眼配置以及卡手的地方，是一个纯底力谱，可以作为CATASTROPHE BANQUET的前置练习曲。
