---
title: 八月的if
url: https://zh.moegirl.org.cn/%E5%85%AB%E6%9C%88%E7%9A%84if
revision: 8540606
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- C/W曲
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 带有失效视频的条目
- 插曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 爱美歌曲
- 西本里美歌曲
---

# 八月的if

## 简介

《八月のif》是《BanG Dream!》企划组合Poppin'Party7th单曲《Time Lapse》中的C/W曲,同时也是TV动画《BanG Dream!》OVA的插曲。单曲发售于2017年9月20日。

## 歌曲试听

## 歌词

户山香澄
山吹沙绫
翻译：AndyZengAS

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

沙绫都有两首和cdd的合唱曲了，李美丽一首都还没有（

### Expert难度

在PPP的歌曲中算是较为简单的一首，初见fc难度不大。需要注意的几个点分别在前奏的数个三连打及副歌部分的片手粉键，全部处理好的话可以轻松fc。

## 注释与外部链接
