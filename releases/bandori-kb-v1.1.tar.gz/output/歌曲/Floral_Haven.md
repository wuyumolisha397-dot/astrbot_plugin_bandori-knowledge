---
title: Floral Haven
url: https://zh.moegirl.org.cn/Floral%20Haven
revision: 8546324
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# Floral Haven

「Floral Haven」是《BanG Dream!》企划组合Roselia的原创歌曲。

## 简介

该曲游戏版于2024年5月5日实装，完整版配信于2024年5月27日，后收录于2024年6月26日发售的Roselia的3rd专辑《Für immer》中。
在官方的歌曲介绍中，被形容为“充满温暖和力量的一首歌”。
本曲于「Rosenchor」上被首次演奏，音源作为「Floral Haven (LIVE ver.)」配信于2024年9月6日。

## 歌曲试听

## 歌词

该歌词已还原BK
翻译：蔷薇之心字幕组

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  冰川纱夜  今井莉莎  宇田川亚子  白金燐子  合唱

## BanG Dream! 少女乐团派对！

日服于2024年5月5日实装。

## 外部链接与注释
