---
title: Invincible Fighter(单曲)
url: https://zh.moegirl.org.cn/Invincible%20Fighter%28%E5%8D%95%E6%9B%B2%29
revision: 8531901
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Invincible Fighter(单曲)

《Invincible Fighter》是《BanG Dream!》企划组合RAISE A SUILEN的3rd单曲，发售于2019年6月19日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2019年4月17日在YouTube上发布。
初回封入特典为一张Roselia×RAISE A SUILEN合同ライブ「Rausch und/and Craziness」演唱会的最速先行抽选券，以及卡片战斗先导者特制卡片一张（共5种，随机1种）。
这张专辑的两首歌曲分别为《卡片战斗先导者》续·高校生编的OP和ED。
封面的模特是Raychell。

## 试听动画

## 收录曲目

## Blu-ray收录内容

TV动画《BanG Dream! 2nd Season》第3、4话
Web版下集预告#3~#4
「History of RAS」再编集版

## 注释与外部链接

试听动画
（日文）官网CD介绍页
