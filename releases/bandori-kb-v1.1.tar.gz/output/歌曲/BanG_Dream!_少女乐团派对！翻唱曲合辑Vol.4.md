---
title: BanG Dream! 少女乐团派对！翻唱曲合辑Vol.4
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91Vol.4
revision: 8544337
updated: '2026-06-30'
categories:
- 2020年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 条目中存在只限中国内地播放的音频
- 翻唱专辑
---

# BanG Dream! 少女乐团派对！翻唱曲合辑Vol.4

《バンドリ！ ガールズバンドパーティ！ カバーコレクション Vol.4》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》的4th翻唱曲专辑，发售于2020年5月27日。
收录了Poppin'Party、Pastel*Palettes、Roselia和Hello, Happy World!四大团各2首翻唱曲，以及Afterglow、RAISE A SUILEN、Morfonica和特殊组合各1首翻唱曲，共12首。
值得一提的是，封面除了五大团的代表以外，和奏瑞依和仓田真白首次代表RAISE A SUILEN和Morfonica在游戏专辑封面亮相。

## 歌曲试听

## 收录曲目

## 外部链接与注释

（日文）官网CD介绍页
