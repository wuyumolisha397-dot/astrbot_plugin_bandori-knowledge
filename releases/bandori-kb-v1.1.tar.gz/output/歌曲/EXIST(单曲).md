---
title: EXIST(单曲)
url: https://zh.moegirl.org.cn/EXIST%28%E5%8D%95%E6%9B%B2%29
revision: 8461159
updated: '2026-06-28'
categories:
- 2021年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# EXIST(单曲)

《EXIST》是《BanG Dream!》企划组合RAISE A SUILEN的7th单曲，发售于2021年4月21日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听动画于2021年3月12日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：一张巡回演唱会RAISE A SUILEN ZEPP TOUR 2021 BE LIGHT的抽选券，以及一张原创角色卡（共5种，随机1种）。

## 试听动画

## 收录曲目

## Blu-ray收录内容

《THE CREATION～We are RAISE A SUILEN～》Live映像

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
