---
title: HOWLING AMBITION
url: https://zh.moegirl.org.cn/HOWLING%20AMBITION
revision: 8547309
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# HOWLING AMBITION

「HOWLING AMBITION」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲。

## 简介

本曲是手游活动288期「Illumination and Shadow」的活动曲，完整版收录于2025年6月11日发售的RAISE A SUILEN的13th单曲《HOWLING AMBITION》中。
本曲于「REBEL SOUNDWAVE」上被首次演奏，在每次演奏本曲之前都会有一段固定的成员Solo。

## 歌曲

试听

Live视频

## 歌词

该歌词已还原BK

翻译：Layer单推人
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

（待补充）

## 注释及外部链接
