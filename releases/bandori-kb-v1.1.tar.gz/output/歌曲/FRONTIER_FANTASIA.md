---
title: FRONTIER FANTASIA
url: https://zh.moegirl.org.cn/FRONTIER%20FANTASIA
revision: 8547248
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# FRONTIER FANTASIA

## 简介

《FRONTIER FANTASIA》是《BanG Dream!》企划组合Roselia在手游《BanG Dream! 少女乐团派对！》第273期活动『トラブル・トラベル・トーク』中演唱的活动曲，收录于2024年12月11日发售的单曲《礎の花冠》。
在剧情中，友希那和亚子没有赶上Roselia其他成员乘坐的巴士，二人为了赶上回家的新干线踏上了一段跌宕起伏的旅途，这首歌曲也是由二人共同演唱的。

## 歌曲试听

游戏版

## 歌词

翻译：蔷薇之心字幕组

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  宇田川亚子  合唱

## BanG Dream! 少女乐团派对！

日服于2024年10月9日随活动『トラブル・トラベル・トーク』(第273期)实装。

## 外部链接与注释
