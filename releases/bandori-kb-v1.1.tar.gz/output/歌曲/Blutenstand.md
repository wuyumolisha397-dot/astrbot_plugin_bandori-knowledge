---
title: Blutenstand
url: https://zh.moegirl.org.cn/Blutenstand
revision: 8457811
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题替换的页面
---

# Blutenstand

《Blütenstand》是《BanG Dream!》衍生企划梦的结唱角色ROSE的1st专辑，发售于2023年7月12日。分为1000个周边付特装盘、通常盘两种规格。
本专辑包含12首新曲目，音乐多数由VOCALOID P提供。
1000个周边付特装盘包含特制亚克力立牌和7张复制原画。

## 试听动画

## 收录曲目

## 外部链接

（日文）官网CD介绍页
