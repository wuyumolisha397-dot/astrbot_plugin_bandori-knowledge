---
title: Poppin'Party翻唱歌曲 - Alchemy
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - Alchemy

## Alchemy

《Alchemy》由Poppin'Party演唱。原曲是TV动画《Angel Beats!》的插曲。原唱为Girls Dead Monster，实际演唱者为岩泽雅美的歌唱声优marina。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

开头一处1→7轨的跨屏绿条容易造成初见杀，需注意，其余部分是下位26，压gr不难，甚至可以说是逆诈称。

##### SPECIAL难度

第一百三十次活动《Welcome to Open School！》追加，作为该期挑战曲。
难度显著比EX上升了，休息段很少，谱面质量有争议。开头的折线形绿条明显neta了歌曲封面上类似于心电图的线条。
