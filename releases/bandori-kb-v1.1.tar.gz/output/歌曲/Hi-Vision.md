---
title: Hi-Vision
url: https://zh.moegirl.org.cn/Hi-Vision
revision: 8483421
updated: '2026-06-28'
categories:
- BanG Dream!音乐
- 仲町阿拉蕾歌曲
- 千石由乃歌曲
- 宫永野乃花歌曲
- 峰月律歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 梦限大MewType歌曲
- 藤都子歌曲
---

# Hi-Vision

「Hi-Vision」是企划《BanG Dream!》旗下组合梦限大MewType的原创歌曲，为2025年4月30日发售的梦限大MewType第二张单曲《Hi-Vision》的同名主打曲。
本曲用作视觉小说游戏《VIRTUAL GIRL @ WORLD'S END》的主题曲。

## 歌曲

歌曲MV

《VIRTUAL GIRL @ WORLD'S END》OP

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## 音游收录

### D4DJ Groovy Mix

本曲作为与《VIRTUAL GIRL @ WORLD'S END》的联动曲目，于2025年6月12日实装。顺便恭喜梦团又一首曲子还没实装在本家先实装在别家

## 注释与外部链接
