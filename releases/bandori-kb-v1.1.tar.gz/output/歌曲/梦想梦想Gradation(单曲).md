---
title: 梦想梦想Gradation(单曲)
url: https://zh.moegirl.org.cn/%E6%A2%A6%E6%83%B3%E6%A2%A6%E6%83%B3Gradation%28%E5%8D%95%E6%9B%B2%29
revision: 8461228
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 梦想梦想Gradation(单曲)

《ゆめゆめグラデーション》是《BanG Dream!》企划组合Pastel*Palettes的7th单曲，发售于2020年9月30日。主打曲《ゆめゆめグラデーション》的试听动画于2020年8月28日在YouTube上发布。
初回封入特典为原创角色卡片一张（共5种）。

## 试听动画

## 收录曲目

## 外部链接与注释

试听动画：[1]
（日文）官网CD介绍页
