---
title: Poppin'Party翻唱歌曲 - only my railgun
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - only my railgun

## only my railgun

《only my railgun》由Poppin'Party常盘和美的CV演唱。原曲是TV动画《某科学的超电磁炮》的片头曲。原唱为fripSide明智小衣的CV。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3，发售于2019年12月18日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：哈吉bye、skzzy00

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EX难度

本曲主体配置在25上位到26下位，最大难点为红键双押接绿条双押达到26的水平，掌握好这段就能冲击FC，难度在26里面不突出。在推出时，本曲属于效率曲，加上名曲效应曾经是热门协力曲。

#### SP难度

超炮联动活动追加，成为第一首不在挑战活动追加的SP曲目。
什么你告诉我这个26还能更简单？竟然成了个25？
跟同为超炮主题曲的吵你妹sister's noise物量555⋯是在暗（明）示什么呢？
重要提示！协力时此歌曲SP难度的分数要高于EX难度，所以除非刻意练歌否则没有理由选择EX。单人分数SP和EX大致一样。
