---
title: FIRE BIRD(单曲)
url: https://zh.moegirl.org.cn/FIRE%20BIRD%28%E5%8D%95%E6%9B%B2%29
revision: 8540384
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# FIRE BIRD(单曲)

《FIRE BIRD》是《BanG Dream!》企划组合Roselia的9th单曲，发售于2019年7月24日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为Rausch und/and Craziness的抽选申请卷。
该枚单曲是志崎桦音加入Roselia后首次参与收录的单曲。

## 试听动画

## 收录曲目

## Blu-ray收录内容

动画《BanG Dream! 2nd Season》 #5~#6
Web版下回预告 #5~#6
动画《BanG Dream! 2nd Season》CM Roselia篇

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
