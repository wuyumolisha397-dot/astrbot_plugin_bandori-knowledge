---
title: Morfonica翻唱歌曲 - CQCQ
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - CQCQ

## CQCQ

《CQCQ》由Morfonica演唱。原曲是日剧《其实并不在乎你》主题曲，原唱为神啊，我已经察觉到了。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

游戏版

完整版

### 歌词

### 谱面

（待补充）
