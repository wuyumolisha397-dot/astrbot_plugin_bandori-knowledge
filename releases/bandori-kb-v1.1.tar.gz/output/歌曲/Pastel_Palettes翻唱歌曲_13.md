---
title: Pastel*Palettes翻唱歌曲 - DISCOTHEQUE
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - DISCOTHEQUE

## DISCOTHEQUE

《DISCOTHEQUE》由Pastel*Palettes演唱。原曲是TV动画《十字架与吸血鬼》第二季的OP。原唱为水树奈奈。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。
在日服实装后很长一段时间内都没有外服上线。但随着国际服在2021年11月18日实装这首歌后，台服已于2022年12月26日实装此曲，国服也于22年12月31日实装。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

此曲被翻唱后，Roselia已不再是水树奈奈的御用翻唱歌姬。
也标志着声优御三家的翻唱PP已得其二，剩下那位或许也不会远了

#### EXPERT难度

（待补充）
