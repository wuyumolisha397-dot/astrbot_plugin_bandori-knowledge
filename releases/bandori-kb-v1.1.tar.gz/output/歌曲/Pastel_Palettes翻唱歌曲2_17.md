---
title: Pastel*Palettes翻唱歌曲2 - 所以，不再是独自一人
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 所以，不再是独自一人

## 所以，不再是独自一人

《だから、ひとりじゃない》由Pastel*Palettes演唱。原曲是电视动画《我的英雄学院》第2季片尾曲。原唱为Little Glee Monster。
时隔两年，预告已久的这首歌终于在日服实装了，泪目
但由于一些众所周知的原因，这首歌无法在国服实装。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）
