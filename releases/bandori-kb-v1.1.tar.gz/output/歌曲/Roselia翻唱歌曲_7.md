---
title: Roselia翻唱歌曲 - 深爱
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - 深爱

## 深爱

《深愛》由Roselia演唱。原曲是TV动画《白色相簿》片头曲。原唱为水树奈奈。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.2，发售于2019年3月16日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：奈亚拉托提普

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

不愧是水树首登红白使用的名曲，连邦邦的物量都打出了666
标准略偏上的25级谱面，抓判定可能是攻略本谱途中的唯一问题。虽然结尾有24分四连打，但跟蔷薇辉石和残酷天使的尾杀相比，这里的24分根本不值一提，把握好整体才是打好本谱的关键。
