---
title: CULTIVATION
url: https://zh.moegirl.org.cn/CULTIVATION
revision: 8457814
updated: '2026-06-28'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- Synthesizer V音乐专辑
---

# CULTIVATION

《CULTIVATION》是《BanG Dream!》衍生企划梦的结唱的专辑，发售于2025年07月16日。分为数量限定生产周边付特装盘、通常盘两种规格。
本专辑包含19首新曲目，音乐多由职业音乐人提供。其中《Leap up Lollipop》《心の愛》为梦的结唱作词大赛「ポピーちゃんローズちゃん　おかしできたわよ～！」获奖作品。
数量限定生产周边付特装盘包含特制亚克力立牌。

## 试听动画

## 收录曲目

## 外部链接

（日文）官网CD介绍页
