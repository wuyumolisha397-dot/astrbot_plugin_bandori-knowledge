---
title: 献给刚刚开始奔跑的你／Teardrops
url: https://zh.moegirl.org.cn/%E7%8C%AE%E7%BB%99%E5%88%9A%E5%88%9A%E5%BC%80%E5%A7%8B%E5%A5%94%E8%B7%91%E7%9A%84%E4%BD%A0%EF%BC%8FTeardrops
revision: 8540550
updated: '2026-07-01'
categories:
- 2016年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
---

# 献给刚刚开始奔跑的你／Teardrops

《走り始めたばかりのキミに／ティアドロップス》是《BanG Dream!》企划组合Poppin'Party的3rd单曲，发售于2016年12月7日，是Poppin'Party第一张两A面单曲。分为Blu-ray付生产限定盘、通常盘两种规格。宣传MV于2016年11月13日在YouTube上公布。
初回封入特典为BanG Dream! 3rd☆LIVE Sparklin' PARTY 2017!门票先行抽选申请券、直签明信片、角色卡片等。各店铺特典是贴纸、写真、徽章等。
由于限定盘和通常盘的封面分别强调了两首歌曲的标题，因此在手游选曲列表中，《走り始めたばかりのキミに》使用限定盘封面，《ティアドロップス》使用通常盘封面。这也是目前BanG Dream企划内唯一一张所有歌在手游中使用CD封面的单曲。

## 宣传MV

## 收录曲目

## Blu-ray收录内容

BanG Dream! First☆LIVE Sprin'PARTY 2016! Live映像
曲目：
1.Yes! BanG_Dream!
2.GLAMOROUS SKY （电影《NANA》主题曲）
3.God knows…（TV动画《凉宫春日的忧郁》插曲）
4.空色デイズ（TV动画《天元突破》片头曲）
5.DISCOTHEQUE（TV动画《十字架与吸血鬼(第二季)》片头曲）
6.一番の宝物（TV动画《Angel Beats!》插曲）
7.ティアドロップス
8.ぽっぴん’しゃっふる
9.走り始めたばかりのキミに
10.Yes! BanG_Dream!
EN1. STAR BEAT!〜ホシノコドウ〜
「走り始めたばかりのキミに」アニメーションミュージックビデオ（ショートバージョン）
《走り始めたばかりのキミに》动画MV(Short Ver.)

### Live映像

## 外部链接与注释

宣传MV
（日文）官网CD介绍页
