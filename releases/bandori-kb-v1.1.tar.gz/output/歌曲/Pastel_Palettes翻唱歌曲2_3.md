---
title: Pastel*Palettes翻唱歌曲2 - LUKALUKA★NIGHT FEVER
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - LUKALUKA★NIGHT FEVER

## LUKALUKA★NIGHT FEVER

《ルカルカ★ナイトフィーバー》由Pastel*Palettes演唱。原曲是一首VOCALOID传说曲，原唱是巡音流歌。
本曲也是除七首联动曲之外，三首在封面上标明CFM版权所有的V家歌曲翻唱之一（另两首为《把你给MIKUMIKU掉》和《夜行性孩子》）。
完整版收录于VOCALOID翻唱曲合辑，发售于2020年12月16日。
Aya Aya★Nice Fever~

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

虽然物量较多，但难度在一众26里面不算高。结尾由滑条构成的五角星很明显是neta了歌曲标题中的五角星符号。
