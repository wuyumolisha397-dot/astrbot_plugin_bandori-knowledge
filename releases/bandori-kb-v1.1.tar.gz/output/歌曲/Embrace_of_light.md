---
title: Embrace of light
url: https://zh.moegirl.org.cn/Embrace%20of%20light
revision: 8545090
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 扰乱 THE PRINCESS OF SNOW AND BLOOD音乐
- 日本音乐作品
- 片尾曲
- 纺木吏佐歌曲
---

# Embrace of light

「Embrace of light」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲，也是TV动画《扰乱 THE PRINCESS OF SNOW AND BLOOD》的片尾曲。

## 简介

本曲收录于2021年4月21日发售的RAISE A SUILEN的7th单曲《EXIST》中。
相比于同一单的EXIST，经常在效率方面被人吐槽，也是RAS少有的慢歌，但是其中还是蕴含了满满的RAS风格。
歌词讲述了主角雪村咲羽（牛込百合）对中村浅阳（市谷有咲）的心意，即使历经磨难，有万般无可奈何之事阻拦，我还是会守护在你身边，永不离弃。
本曲于「OVERKILL」上被首次演奏。

## 歌曲试听

动画版

完整版

## 歌词

翻译:茶喵子酱

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

全曲BPM倒数第二，第一名是PasPale的翻唱曲「奏（かなで）」。

### EXPERT难度

仅有22级，作为一首慢歌其难度在所有EX谱中也偏简单（除了收尾阶段的连打），适合EX新人上手。
这首歌的EX物量也是目前全游倒数第二，只比你所给予之物多了5个notes。

## 外部链接与注释
