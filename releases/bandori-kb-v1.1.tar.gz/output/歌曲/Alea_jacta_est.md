---
title: Alea jacta est
url: https://zh.moegirl.org.cn/Alea%20jacta%20est
revision: 8505220
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

《Alea jacta est》是《BanG Dream!》企划旗下虚拟与真人结合的组合Ave Mujica发行的首张迷你专辑，于2023年9月13日正式面世。该专辑分为附赠Blu-ray的生产限定盘与通常盘两种规格发售。

专辑名称“Alea jacta est”是一句著名的拉丁语，源自历史人物凯撒大帝的名言，字面意思为“骰子已被掷下”。这句话象征着不可逆转的决断时刻：一旦做出了某个决定，事态的发展便超出了个人的掌控范围，未来的所有变化都只能顺应天意。这一充满宿命感与戏剧张力的主题，完美契合了Ave Mujica组合神秘、华丽且带有悲剧色彩的基调。

在音乐内容方面，这张迷你专辑不仅收录了组合极具代表性的原创歌曲，还展现了她们出色的翻唱实力。专辑内包含了《Ave Mujica》、《黒のバースデイ》、《Choir 'S' Choir》、《神さま、バカ》、《Mas?uerade Rhapsody Re?uest》以及《ふたつの月 ~Deep Into The Forest~》等核心曲目。此外，专辑中还收录了多首在《BanG Dream!》企划中极具人气的翻唱作品，如《KINGS》、《暗黒天国》、《Determination Symphony》、《堕天》与《PASSIONATE ANTHEM》等，充分展现了成员们多元且扎实的音乐驾驭能力。

除了音频曲目，生产限定盘所附带的Blu-ray光碟更是收录了极为丰富的视觉与影像内容。其中包括Ave Mujica首场单独演唱会“0th LIVE「Primo die in scaena」的完整现场演出影像，真实记录了这支神秘乐队初登舞台的惊艳表现。光碟中还收录了前五首主打曲目的音乐录影带，以及五部充满悬疑色彩的原创故事视频，分别以“再生”、“探索”、“摩擦”、“过去”与“招待”为主题，层层递进地构建出组合独特的世界观。同时，限定盘内还附带了一本设计精美的小册子，其中不仅包含专辑的歌词本，更隐藏着代号为“？？？？？？？？ -■■-”的神秘文本，为听众留下了无尽的遐想空间。
