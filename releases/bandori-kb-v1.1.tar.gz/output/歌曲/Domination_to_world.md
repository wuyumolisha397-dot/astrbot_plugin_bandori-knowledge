---
title: Domination to world
url: https://zh.moegirl.org.cn/Domination%20to%20world
revision: 8545069
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# Domination to world

「Domination to world」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲。

## 简介

本曲收录于2021年9月29日发售的RAISE A SUILEN的8th单曲《Domination to world》中，后又收录于2024年6月12日发售的RAISE A SUILEN的2nd专辑《SAVAGE》中。
本曲是手游活动第151期「outside/inside」的活动曲，日服实装于2021年5月31日。
本曲于「Mythology」上被首次演奏。

## 歌曲

完整版

## 歌词

该歌词已还原BK
翻译:BurstAlpha

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

### EXPERT难度

RAS又有27？这首歌出乎意料的不水？1:49时长但有鬼畜的932物量前排提醒：绿条苦手和双押苦手快跑啊！
本曲的难点不是在于粉键，本曲有大量天弱和BJ的鬼畜绿条，开头和结尾都有类似SOS的配置，combo599后还有Yolo的连续三次的迅速三连打⇄双押，而本曲最难的部分是combo757后的强化版罪恶王冠DNA双押
在DRIVE US CRAZY实装到游戏里之前，这首歌一直都是公认的RAS最难27级EX谱面。毕竟RAS其他27谱面都是肉眼可见的水

## 注释与外部链接
