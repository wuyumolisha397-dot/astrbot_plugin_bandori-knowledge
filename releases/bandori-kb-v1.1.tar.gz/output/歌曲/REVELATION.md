---
title: REVELATION
url: https://zh.moegirl.org.cn/REVELATION
revision: 8462477
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# REVELATION

《REVELATION》是《BanG Dream!》企划组合RAISE A SUILEN的第一张迷你专辑，发售于2023年11月1日，分为Blu-ray付生产限定盘、LAYER Ver.、LOCK Ver.、MASKING Ver.、PAREO Ver.、CHU² Ver.，共六种规格。
试听动画于2023年10月27日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：一张演唱会RAISE A SUILEN LIVE 2024「ESSENTIALS」的最速先行抽选券，以及一张对应版本的角色卡片。
迷你专辑标题REVELATION意为启示录，收录的五首歌曲标题分别指向五位成员。虽然并非全由角色本人作为主唱演唱，但仍可视为该成员的角色印象曲。

## 收录曲目

## Blu-ray收录内容

RAISE A SUILEN LIVE 2023「EXCLAMATION HIGHLAND」 Live映像

Guest: Roselia
1.熱色スターマイン
2.Dear Gleam
3.PASSIONATE ANTHEM
4.BLACK SHOUT
5.FIRE BIRD
RAISE A SUILEN
1.Invincible Fighter
2.DEAD HEAT BEAT
3.ゴーカ！ごーかい！？ファントムシーフ！
4.UNSTOPPABLE
5.OUTSIDER RODEO
6.劣等上等
7.Keep the Heat and Fire Yourself Up
8.Repaint
9.!NVADE SHOW!
10.狂乱 Hey Kids!!
11.灼熱 Bonfire!
12.EXPOSE ‘Burn out!!!’
13.-N-E-M-E-S-I-S-
14.THE WAY OF LIFE
15.HELL! or HELL?
16.DRIVE US CRAZY

## 外部链接与注释

试听动画：
（日文）官网CD介绍页
