---
title: Call the shots
url: https://zh.moegirl.org.cn/Call%20the%20shots
revision: 8546323
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# Call the shots

《Call the shots》是游戏《BanG Dream! 少女乐团派对！》第221次活动「不朽的蔷薇 未闻其色」的追加歌曲，由Roselia演唱。

## 简介

本曲是Roselia第14张单曲《VIOLET LINE》的C/W曲。单曲于2023年12月13日发售。

## 歌曲试听

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  冰川纱夜  今井莉莎  宇田川亚子  白金燐子  合唱

## BanG Dream! 少女乐团派对！

游戏第221次活动「不朽的蔷薇 未闻其色」的相关歌曲。
2023年5月8日活动结束后可于日服通常游玩。2023年12月22日于简体中文服追加。

## 外部链接与注释
