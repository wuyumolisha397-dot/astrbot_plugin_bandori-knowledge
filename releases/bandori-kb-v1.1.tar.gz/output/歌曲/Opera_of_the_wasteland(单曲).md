---
title: Opera of the wasteland(单曲)
url: https://zh.moegirl.org.cn/Opera%20of%20the%20wasteland%28%E5%8D%95%E6%9B%B2%29
revision: 8531936
updated: '2026-06-28'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Opera of the wasteland(单曲)

《Opera of the wasteland》是《BanG Dream!》企划组合Roselia的5th单曲，发售于2018年3月21日。
主打曲《Opera of the wasteland》的试听动画于2018年1月28日在YouTube上发布，C/W曲《軌跡》的试听动画于2018年2月14日在YouTube上发布。
RoseliaCD中第二张由活动剧情曲做主打曲的单曲。但是在惯例书写主打曲歌词的CD封页上，书写的歌词是来自軌跡的歌词“いつまでも热いままで”。
初回封入特典为BanG Dream! 5th☆LIVE 特别2次先行抽选申请券、角色卡等。各店铺特典是写真、文件夹、明信片等。除此之外，在各店铺与Poppin'Party9th单曲《CiRCLING》一同购入还将赠送特典翻唱曲CD一张。

## 试听动画

Opera of the wasteland

軌跡

## 收录曲目

## 特典CD

与Poppin'Party9th单曲《CiRCLING》一同购入赠送，收录了BanG Dream!的部分翻唱歌曲。
共有四种，分别对应店铺为：

青——Animate
赤——Gamers
黄——Tower Record
黑——Bushiroad EC、虎之穴（部分店铺）、WonderGOO（部分店铺）、其他应援店铺。

### 收录曲目

## 外部链接与注释

试听动画：Opera of the wasteland、轨迹
（日文）官网CD介绍页
