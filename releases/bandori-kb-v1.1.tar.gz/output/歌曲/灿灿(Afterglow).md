---
title: 灿灿(Afterglow)
url: https://zh.moegirl.org.cn/%E7%81%BF%E7%81%BF%28Afterglow%29
revision: 8546259
updated: '2026-07-01'
categories:
- Afterglow歌曲
- BanG Dream!音乐
- 三泽纱千香歌曲
- 佐仓绫音歌曲
- 使用标题替换的页面
- 加藤英美里歌曲
- 日本音乐作品
- 日笠阳子歌曲
- 条目中存在只限中国内地播放的音频
- 金元寿子歌曲
---

# 灿灿(Afterglow)

「燦々」是企划《BanG Dream!》旗下组合Afterglow演唱的歌曲。
作为Afterglow × じん的联动特别企划，歌曲于2023年9月2日发布。

## 歌曲试听

完整版

动画MV

## 歌词

翻译取自B站官方MV中文字幕
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

### 谱面

第233期活动「Poppin'western journey！」的组曲模式课题曲之一。

#### EXPERT难度

又一首 AG 28
（待补充）

## 注释及外部链接

燦々 | BanG Dream!（バンドリ！）公式サイト
