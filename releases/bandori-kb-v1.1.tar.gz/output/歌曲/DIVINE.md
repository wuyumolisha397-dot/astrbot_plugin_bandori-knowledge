---
title: DIVINE
url: https://zh.moegirl.org.cn/DIVINE
revision: 8557942
updated: '2026-06-28'
categories:
- Ave Mujica歌曲
- BanG Dream!音乐
- 佐佐木李子歌曲
- 冈田梦以歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 渡濑结月歌曲
- 片头曲
- 米泽茜歌曲
- 高尾奏音歌曲
---

# DIVINE

「DIVINE」是企划《BanG Dream!》旗下组合Ave Mujica的原创歌曲，也是游戏《PROGRESS ORDERS》的片头曲。

## 简介

本曲的开头曲映像于2025年1月17日公开，完整版配信于2025年8月4日，收录于2026年6月17日发售的Ave Mujica的Best Album《Ave Música》中。
本曲于「Nova Historia」上被首次演奏。

## 歌曲

开头曲映像

完整版

## 歌词

该歌词已还原BK

中文翻译：EmpyreusX

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 Doloris  Mortis  Timoris  Amoris  Oblivionis  合唱
