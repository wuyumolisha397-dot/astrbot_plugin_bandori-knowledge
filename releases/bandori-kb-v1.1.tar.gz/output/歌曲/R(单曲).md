---
title: R(单曲)
url: https://zh.moegirl.org.cn/R%28%E5%8D%95%E6%9B%B2%29
revision: 8462474
updated: '2026-06-28'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# R(单曲)

《R》是《BanG Dream!》企划组合Roselia的6th单曲，发售于2018年07月25日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听动画于2018年6月22日在YouTube上发布。
该碟是中岛由贵接替远藤祐里香之后Roselia的首张唱片。除了收录了新曲《R》以外，还收录了中岛由贵参与的《BLACK SHOUT》与《Neo-Aspect》的重录版本。
初回封入特典为Roselia Fan Meeting 2018的抽选应征申请券等。各店铺特典是写真、文件夹等。

## 试听动画

## 收录曲目

## Blu-ray收录内容

Roselia ガルパライブ
节目列表：
Day1(2018.1.13)
1.ONENESS
2.Re:birth day
3.陽だまりロードナイト
4.LOUDER
Day2(2018.1.14)
1.BLACK SHOUT
2.熱色スターマイン
3.ONENESS
「Neo-Aspect」 Music Video

### Live映像

## 外部链接与注释

试听动画：R
（日文）官网CD介绍页
