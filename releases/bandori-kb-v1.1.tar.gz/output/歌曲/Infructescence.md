---
title: Infructescence
url: https://zh.moegirl.org.cn/Infructescence
revision: 8457825
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# Infructescence

《Infructescence》是《BanG Dream!》衍生企划梦的结唱角色POPY的1st专辑，发售于2023年7月12日。分为1000个周边付特装盘、通常盘两种规格。
本专辑包含15首新曲目，音乐多数由VOCALOID P提供，其中《私色きらめき日和》《Starry Phrase！》为梦的结唱作曲大赛获奖作品。
1000个周边付特装盘包含特制亚克力立牌和7张复制原画。

## 试听动画

## 收录曲目

## 外部链接

（日文）官网CD介绍页
