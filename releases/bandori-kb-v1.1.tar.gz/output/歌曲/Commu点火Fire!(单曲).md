---
title: Commu点火Fire!(单曲)
url: https://zh.moegirl.org.cn/Commu%E7%82%B9%E7%81%ABFire%21%28%E5%8D%95%E6%9B%B2%29
revision: 8461181
updated: '2026-06-28'
categories:
- 2024年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Commu点火Fire!(单曲)

《コミュ着火Fire!》是《BanG Dream!》旗下虚拟Youtuber组合梦限大MewType的1st单曲，发售于2024年12月25日。
初回生产分限定封入特典为一张迷你相卡（共10种）。
官方还于2025年1至2月间在日本各地举办本单曲的发售活动，包含谈话会和手渡会。
单曲封面由藤都子绘制。

## 收录曲目

## 发售活动

## 外部链接

（日文）官网单曲介绍页
（日文）发售纪念活动介绍页
