---
title: 「BanG Dream! FILM LIVE 2nd Stage」剧中歌合辑
url: https://zh.moegirl.org.cn/%E3%80%8CBanG%20Dream%21%20FILM%20LIVE%202nd%20Stage%E3%80%8D%E5%89%A7%E4%B8%AD%E6%AD%8C%E5%90%88%E8%BE%91
revision: 8529057
updated: '2026-06-30'
categories:
- 2021年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# 「BanG Dream! FILM LIVE 2nd Stage」剧中歌合辑

《劇場版「BanG Dream! FILM LIVE 2nd Stage」Special Songs》是《BanG Dream!》企划电影《BanG Dream! FILM LIVE 2nd Stage》的安可曲合辑，发售于2021年8月25日。分为Blu-ray付生产限定盘、通常盘两种规格。Blu-ray付生产限定盘附带小册子等特典。
试听动画于2021年7月30日在YouTube上发布。

## 单曲试听

## 收录曲目

## Blu-ray收录内容

BanG Dream! FILM LIVE
※未特殊标注的，均为Short Ver.
Poppin'Party

二重の虹（ダブルレインボウ）（完整版）
- MC -

Happy Happy Party!
Afterglow

Y.O.L.O！！！！！
Scarlet Sky
- MC -

ON YOUR MARK（完整版）
Pastel*Palettes

しゅわりん☆どり～みん
- MC -

ゆら・ゆらRing-Dong-Dance
きゅ～まい＊flower（完整版）
Hello, Happy World!

えがおのオーケストラっ！
- MC -

せかいのっびのびトレジャー！
えがお・シング・あ・ソング（完整版）
Roselia

LOUDER
- MC -

BLACK SHOUT
FIRE BIRD（完整版）
Poppin'Party

Returns
Dreamers Go!
- 后台场景 -
—— 安可 ——
Roselia

BRAVE JEWEL（完整版）
Poppin'Party

キズナミュージック♪（完整版）

—— 返场谢幕 ——
片尾曲：
Poppin'Party

Jumpin'（完整版）

## 注释

## 外部链接

（日文）官网CD介绍页
