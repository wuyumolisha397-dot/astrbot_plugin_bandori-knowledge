---
title: Choir 'S' Choir
url: https://zh.moegirl.org.cn/Choir%20%27S%27%20Choir
revision: 8540872
updated: '2026-06-28'
categories:
- Ave Mujica歌曲
- BanG Dream!音乐
- 佐佐木李子歌曲
- 冈田梦以歌曲
- 日本音乐作品
- 渡濑结月歌曲
- 米泽茜歌曲
- 高尾奏音歌曲
---

# Choir 'S' Choir

「Choir 'S' Choir」是《BanG Dream!》企划组合Ave Mujica的原创歌曲。

## 简介

本曲于2023年4月23日配信并于当日公开MV，完整版收录于2023年9月13日发售的Ave Mujica的1st迷你专辑《Alea jacta est》中。
本曲中的「‘S’ カレート」对应的是英语单词「escalate（エスカレート）」，意为「加剧」「升级」，故「‘S’」可能特别对应「es」，「es」在拉丁语中意为「是」或「存在」。「Choir」意为「唱诗班」「合唱团」。
本曲于「Primo die in scaena」上被首次演奏。

## 歌曲

试听

MV（AveMujica）

MV（MyGO_AveMujica）

LIVE视频

## 歌词

该歌词已还原BK

翻译来自B站官方MV中文字幕

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 Doloris  Mortis  Timoris  Amoris  Oblivionis  合唱

## 注释与外部链接
