---
title: Morfonica翻唱歌曲 - QUEEN
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - QUEEN

## QUEEN

《QUEEN》由Morfonica演唱。原曲是Kanaria投稿至niconico和YouTube的VOCALOID日文原创歌曲，原唱为GUMI。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

国服以庆祝黄金周名义于2023.9.30超前追加。

#### Expert难度
