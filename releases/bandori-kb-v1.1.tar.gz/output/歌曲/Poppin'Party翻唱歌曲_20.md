---
title: Poppin'Party翻唱歌曲 - Cherry Bomb
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - Cherry Bomb

## Cherry Bomb

《チェリボム》由Poppin'Party演唱。原唱为SILENT SIREN。原曲收录于SILENT SIREN的同名EP；在2019年PPP和SS的共演Live《NO GIRL NO CRY》中，本曲也作为SILENT SIREN的表演曲目之一，同时为第一天两支乐队的共演安可曲。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.5，发售于2021年2月24日。

### 歌曲试听

游戏版

完整版

### 歌词

翻译：Silverpearl

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

190的BPM使手感略显紧张，但谱面的通关难度并不高，难点仍然在准度控制上。另外两根高密度转折滑条也是在两周年前后推出的谱面中经常出现的配置，协力请慎选。不然真的就协力协力BOOM了
