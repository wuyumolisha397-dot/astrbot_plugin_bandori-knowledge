---
title: Afterglow翻唱歌曲2 - Listen!!
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545299
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

Afterglow是《BanG Dream!》企划中活跃的女子摇滚乐队，由美竹兰（主唱）、青叶摩卡（吉他）、上原绯玛丽（贝斯）、宇田川巴（鼓手）和羽泽鸫（键盘手）组成。乐队以其充满活力的翻唱歌曲和原创作品受到粉丝喜爱，其中翻唱曲《Listen!!》是她们的代表性翻唱作品之一。

《Listen!!》原曲是TV动画《轻音少女》第二季的片头曲，由剧中组合“放学后TEA TIME”演唱。这首歌曲以明快活泼的旋律和青春洋溢的歌词著称，是许多动漫乐迷心中的经典。Afterglow的翻唱版本保留了原曲的动感与热情，同时融入了乐队自身特有的摇滚能量——主唱美竹兰富有爆发力的嗓音与充满张力的吉他、贝斯、鼓点配合，赋予这首歌别样的风风火火的魅力。

该翻唱曲的完整版收录于Afterglow的第二张专辑《STAY GLOW》的Disc2中。这张专辑于2023年4月26日正式发售，包含多首乐队原创曲目和翻唱曲，其中《Listen!!》作为翻唱环节的高人气曲目，吸引了大量原动画粉丝和新听众。在游戏《BanG Dream! Girls Band Party!》中，这首翻唱曲也被制成可游玩谱面，玩家可以通过游戏体验Afterglow版本的《Listen!!》。除了完整版之外，还同时收录了面向游戏的Game Size版本，方便玩家在游戏中快捷使用。

《Listen
