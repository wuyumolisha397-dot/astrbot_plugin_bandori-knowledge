---
title: Afterglow翻唱歌曲 - READY STEADY GO
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542925
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《READY STEADY GO》是企划《BanG Dream!》中登场乐队Afterglow的一首翻唱歌曲。该曲原唱为日本知名摇滚乐团L'Arc～en～Ciel，曾作为经典电视动画《钢之炼金术师》的片头曲而广为人知。Afterglow的翻唱完整版收录于2018年6月27日发行的音乐专辑《BanG Dream! 少女乐团派对！翻唱曲合辑Vol.1》中。

在游戏《BanG Dream! 少女乐团派对！》内，这首翻唱曲的谱面设计具有鲜明的特色。在Expert难度下，它是Afterglow所有翻唱曲目中难度最低的几首之一，整体评级处于24级上位水平。尽管整体难度不高，但谱面中包含了大量跟随歌曲鼓点的不规则连打与小交互配置，如果玩家未能完全掌握节奏，实际游玩体验可能会接近25级的难度。

此外，该曲在后续游戏更新中追加了Special难度谱面，并作为第一百三十六次活动“Red Ignition”的挑战曲目登场。Special难度的整体评级大约处于26级中位，谱面的主要难点集中在前奏与尾奏部分的短绿条交互配置。同时，在副歌段落中出现的红绿键交替配置也较为考验玩家的手速与协调能力，容易造成卡手的情况，需要玩家在游玩时特别留意并加以适应。
