---
title: Poppin'Party翻唱歌曲2 - 吸血鬼
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - 吸血鬼

## 吸血鬼

《ヴァンパイア》由Poppin'Party演唱。原曲是VOCALOID传说曲。原唱为初音未来。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.7，发售于2022年12月14日。

### 歌曲试听

游戏内版本

完整版

### 歌词

翻译：Cyanlix_シアンリックス

### 谱面

国服以庆祝3周年名义于2022.5.30超前追加。演奏时间很长不太适合在协力活动选。

#### EXPERT难度
