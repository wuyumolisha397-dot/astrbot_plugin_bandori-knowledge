---
title: BanG Dream!特殊组合翻唱歌曲 - 天体观测
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 天体观测

## 天体观测

《天体観測》由户山香澄（CV.爱美）和Afterglow共同演唱。原曲是电视剧《天体观测》的插曲。原唱为BUMP OF CHICKEN，爱美正是该乐团的支持者，天体观测也是她最喜欢的乐曲之一。

### 歌曲试听

### 歌词

翻译：迦箬

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### Expert难度

前期的26级上位，即使放在现在也是26级中上难度，节奏比较难抓，因此尽管属于协力效率曲，但选的人似乎不多。对邦可以炸人
