---
title: Poppin'Party翻唱歌曲2 - 心绘
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - 心绘

## 心绘

《心絵》由Poppin'Party演唱。原唱为ロードオブメジャー（ROAD OF MAJOR）。原曲为TV动画《棒球大联盟》OP1、主题曲。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

国服于2024年1月29日15:00，作为第226期活动巡演第三曲追加。虽说歌曲与活动并无直接关联，作为首期启用卡面加成的活动，组曲三曲中竟然有两首都是破琵琶的，而破琵琶全员甚至没在活动剧情中露过面

#### EXPERT难度
