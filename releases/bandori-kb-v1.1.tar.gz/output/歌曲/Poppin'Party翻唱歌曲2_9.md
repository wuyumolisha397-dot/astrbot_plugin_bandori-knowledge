---
title: Poppin'Party翻唱歌曲2 - Yesterday
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - Yesterday

## Yesterday

《イエスタデイ》由Poppin'Party演唱。原曲是动画电影《HELLO WORLD》的主题曲，原唱是Official髭男dism。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

BPM仅130（笔者觉得打起来还有点像65），配置也十分朴实简单，没有特别难点，冲击通关和FC难度非常简单，比部分23要简单。但AP难度不虚，副歌前的小调段节奏略为难抓，副歌段也有一些小爆G坑点。
