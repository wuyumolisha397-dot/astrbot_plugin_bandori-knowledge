---
title: Poppin'Party翻唱歌曲 - 非你莫属
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - 非你莫属

## 非你莫属

《君じゃなきゃダメみたい》由Poppin'Party演唱。原曲是TV动画《月刊少女野崎君》的片头曲。原唱为大石昌良。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.2，发售于2019年3月16日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

略显搞怪的节点直条+红键收尾，还有12分连续双押，拉高了谱面难度，配信以来就被众多玩家视作臭名昭著的25级天花板，且个人差也非常严重。甚至连原唱大石昌良试玩都打不过3秒。月刊明明是个27
六周年难度标级调整荣升26
