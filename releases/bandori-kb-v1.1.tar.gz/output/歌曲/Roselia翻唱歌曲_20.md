---
title: Roselia翻唱歌曲 - Paradisus-Paradoxum
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - Paradisus-Paradoxum

## Paradisus-Paradoxum

《Paradisus-Paradoxum》由Roselia演唱。原曲为动画《Re:从零开始的异世界生活》的后期片头曲，原唱为MYTH & ROID。本曲同时是BanG Dream和Re0动画联动活动的一部分。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.5，发售于2021年2月24日。

### 歌曲试听

### 歌词

### 谱面

#### EXPERT难度

Re：从零开始的28级生活
在日服第97期（Re0合作活动）中登场的第七首28级EX。虽然在28级中拥有倒数第四的物量，Note数比811的甜歌苦步仅多两个，但乐曲长度仅94秒神仙们的效率曲然而现在却被更短更简单出分更高的SAVIOR OF SONG吊打，因此谱面密度也达到了8.6，和红六兆和SP无人岛比肩，对玩家体力要求比较高（比过千物量的gk还高）；但如果跨过了体力门槛，本谱整体仍属于纯粹考查手速和定位以及本能的下位28级，有大触甚至初见AP。
虽然在部分绿条配置中能看到开花的缩影，而副歌前和结尾各有一处和海色非常类似的超级协调配置，但其他非难点段并没有出现交互掺纵连、超短条等在其他28+中大杀特杀的配置，唯一需要注意的就是比较容易点歪的Note位置。因此本曲推出不久，就已经被玩家公认为新的28级地板。
考虑到高BPM带来的底力要求，本曲个人差明显，这首28并不是像gk那样真正的逆诈称，不过仍有机会成为海外服配信后冲击EX试炼的热门选择。如果不考虑本身曲速的话甚至比隔壁PPP的28级还简单。
更简单的天之弱出来之后就没地位了
