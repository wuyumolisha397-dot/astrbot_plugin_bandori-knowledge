---
title: BanG Dream! 少女乐团派对！翻唱曲合辑Vol.8
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91Vol.8
revision: 8545691
updated: '2026-06-30'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 翻唱专辑
---

# BanG Dream! 少女乐团派对！翻唱曲合辑Vol.8

《バンドリ！ ガールズバンドパーティ！ カバーコレクション Vol.8》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》的8th翻唱曲专辑，预定于2023年9月6日发售。
Disc1中收录了Poppin'Party、Pastel*Palettes、Hello, Happy World!、Morfonica、Roselia、Afterglow、和RAISE A SUILEN七大团各2首翻唱曲，共14首；Disc2中收录了七大团各2首Extra歌曲，分别为与原唱合唱版和乐队独唱版，共14首。
Blu-ray付生产限定盘除上述翻唱曲外，还收录了迷你动画《BanG Dream! ガルパ☆ピコ ふぃーばー！》全26集。

## 歌曲试听

暂无

## 收录曲目

## 外部链接与注释

（日文）官网CD介绍页
