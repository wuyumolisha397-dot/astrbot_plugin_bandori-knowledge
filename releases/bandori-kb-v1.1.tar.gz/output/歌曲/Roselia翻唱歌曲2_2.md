---
title: Roselia翻唱歌曲2 - Bad Apple!! feat. nomico
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - Bad Apple!! feat. nomico

## Bad Apple!! feat. nomico

《Bad Apple!! feat. nomico》由Roselia演唱。原曲为一首东方Project的原曲改编歌曲，原唱为nomico。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

开头18秒处，吉他第一次响起的时候，出现了一个绿条和粉键构成的苹果。
后续的吉他比较影响节奏，建议跟着DNA鼓的节奏打
开头43秒处出现了一个由两个绿条组成的类似茶杯的形状的图案
fever后半段（1:13至1:24），粉键绿条的组合频繁出现对底力是个小考验
