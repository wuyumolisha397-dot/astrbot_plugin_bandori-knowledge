---
title: Roselia翻唱歌曲 - Hacking to the Gate
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - Hacking to the Gate

本条目收录乐队企划《BanG Dream!》中组合Roselia在游戏及唱片中发布的翻唱歌曲。
真人乐队Roselia在演唱会现场表演过的翻唱歌曲在BanG Dream! Live翻唱歌曲查看。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## Hacking to the Gate

《Hacking to the Gate》由Roselia演唱。原曲是TV动画《命运石之门》的片头曲。原唱为伊藤香奈子。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

不难打的25，只要注意滑键就能FC，而且在早期歌曲不多的时候为效率曲，尤其是在官方大修歌曲FEVER段后更是取代了修车，成为了早期最强效率歌。
由于国服开服时使用的歌曲FEVER数据是大修后的，因此国服玩家在前两期活动期间的协力并不是被修车支配的，而是被石头门支配的。
车门焊死，谁都别想下车.jpg
