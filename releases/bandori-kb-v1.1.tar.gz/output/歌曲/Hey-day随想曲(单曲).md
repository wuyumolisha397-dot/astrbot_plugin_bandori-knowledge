---
title: Hey-day随想曲(单曲)
url: https://zh.moegirl.org.cn/Hey-day%E9%9A%8F%E6%83%B3%E6%9B%B2%28%E5%8D%95%E6%9B%B2%29
revision: 8522253
updated: '2026-06-28'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Hey-day随想曲(单曲)

《Hey-day狂騒曲(カプリチオ)》是《BanG Dream!》企划组合Afterglow的2nd单曲，发售于2018年1月31日。
主打曲《Hey-day狂騒曲(カプリチオ)》的试听动画于2017年12月21日在YouTube上发布，C/W曲《Scarlet Sky》的试听动画于2017年12月22日在YouTube上发布。
初回封入特典为2nd单曲三联购入活动报名券Afterglow部分、角色卡等。各店铺特典为写真、文件夹、明信片等。
标题括号里面的是“狂騒曲”的注音kapurichio，来自意大利语capriccio。

## 试听动画

Hey-day狂騒曲(カプリチオ)

Scarlet Sky

## 收录曲目

## 外部链接与注释

试听动画：Hey-day狂骚曲、Scarlet Sky
（日文）官网CD介绍页
