---
title: Afterglow翻唱歌曲 - 蓝书签
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542925
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《蓝书签》（青い栞）是企划BanG Dream!中乐队Afterglow翻唱的一首歌曲。该曲原为Galileo Galilei演唱的电视动画《我们仍未知道那天所看见的花的名字。》片头曲，Afterglow的翻唱完整版收录于其第二张专辑《STAY GLOW》Disc2，于2023年4月26日发售。

Afterglow是一支由青梅竹马组成的少女乐队，成员包括主唱美竹兰、吉他青叶摩卡与羽泽鸫、贝斯日菜子以及键盘手松原花音。乐队以温暖坚定的羁绊和充满情感张力的流行摇滚风格著称。翻唱《蓝书签》时，Afterglow保留了原曲清新而略带忧伤的基调，同时融入乐队自身明亮有力的编曲特色，使歌曲在怀旧氛围中展现出更为积极向上的力量。

该翻唱曲的游戏版本于2020年5月29日作为一周年庆祝内容提前实装，随后正式收录于专辑中。歌曲通过细腻的旋律与歌词，呼应了Afterglow成员间深厚的友情与共同成长的经历，成为乐队翻唱作品中颇具代表性的一首。
