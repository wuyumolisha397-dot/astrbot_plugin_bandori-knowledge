---
title: 怀有梦想的Sunflower
url: https://zh.moegirl.org.cn/%E6%80%80%E6%9C%89%E6%A2%A6%E6%83%B3%E7%9A%84Sunflower
revision: 8540578
updated: '2026-07-01'
categories:
- BanG Dream!音乐
- Poppin'Party歌曲
- 伊藤彩沙歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 插曲
- 日本音乐作品
- 爱美歌曲
- 西本里美歌曲
---

# 怀有梦想的Sunflower

## 简介

《夢みるSunflower》是《BanG Dream!》企划组合Poppin'Party6th单曲《前へススメ！／夢みるSunflower》中的歌曲，同时也是TV动画第13话的插曲。单曲发售于2017年5月10日。

## 歌曲试听

完整版

第一季插入曲

## 歌词

该歌词已还原BK
翻译：Stevie@LoveDream

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

日服于2017年4月22日追加，国服于第四次活动追加；须通过礼物箱领取。

EXPERT难度
前奏绿条有点妖娆哈，绿条完了就是单双押阵外加几个粉键，再之后就是连打+粉键单双。
进入副歌后谱面表现出多样，也需要注意。尾奏的乱打也比较难搞……

## 外部链接与注释
