---
title: A DECLARATION OF ×××
url: https://zh.moegirl.org.cn/A%20DECLARATION%20OF%20%C3%97%C3%97%C3%97
revision: 8543320
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

《A DECLARATION OF ×××》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的原创歌曲，同时作为手机游戏《九州三国志》的主题曲。该曲于2019年2月20日以RAISE A SUILEN第二张单曲的形式发行，后于2020年8月19日被收录进乐队首张专辑《ERA》中。

歌曲标题中的“×××”本身不发音，仅作为视觉符号存在。在演出中，当演唱至3分52秒处时，主唱Raychell与吉他手小原莉子、键盘手仓知玲凤会同步转头面向排列的电风扇，形成独特的舞台效果。该曲首次公演是在乐队专场活动“Brave New World”上。

2020年4月25日，历经一年多的等待后，《A DECLARATION OF ×××》正式在游戏《BanG Dream! 少女乐团派对！》中配信。由于此前除Pastel＊Palettes外，其余乐团的第二张单曲在游戏中均被设定为较高难度，加之本曲曲风激烈，玩家一度猜测其Expert难度可能达到27级或更高。然而实际配信后，本曲难度仅为常规的26级，令多数玩家感到意外。尽管如此，其节奏紧凑、鼓点密集的特点仍为RAISE A SUILEN的曲库增添了一首具有代表性的快节奏作品。
