---
title: Pastel*Palettes翻唱歌曲 - 心动Poporon
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - 心动Poporon

## 心动Poporon

《ときめきポポロン♪》由Pastel*Palettes演唱。原曲是TV动画《请问您今天要来点兔子吗？？》的片尾曲。原唱为智麻惠队。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

以12分音和绿条为主要组成的谱面，虽然FC难度不高，甚至可以说是比25下位的家街还水逆诈称（12分红键仍然值得注意），但绿条尾端非常容易爆great，AP向玩家请多加注意。48s强判，你值得拥有。
再生时长跟ふわふわ时间还短1秒，但协力效率未能冲击ふわふわ时间的地位。
