---
title: 前进吧！／怀有梦想的Sunflower
url: https://zh.moegirl.org.cn/%E5%89%8D%E8%BF%9B%E5%90%A7%EF%BC%81%EF%BC%8F%E6%80%80%E6%9C%89%E6%A2%A6%E6%83%B3%E7%9A%84Sunflower
revision: 8557386
updated: '2026-07-01'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
---

# 前进吧！／怀有梦想的Sunflower

《前へススメ！／夢みるSunflower》是《BanG Dream!》企划组合Poppin'Party的6th单曲，发售于2017年5月10日。试听动画于2017年5月10日在YouTube上发布。
初回封入特典为贴纸等。各店铺特典为书签等。

## 试听动画

## 收录曲目

## 外部链接与注释

试听动画
（日文）官网CD介绍页
