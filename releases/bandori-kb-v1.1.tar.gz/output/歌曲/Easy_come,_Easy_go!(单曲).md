---
title: Easy come, Easy go!(单曲)
url: https://zh.moegirl.org.cn/Easy%20come%2C%20Easy%20go%21%28%E5%8D%95%E6%9B%B2%29
revision: 8525125
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Easy come, Easy go!(单曲)

《Easy come, Easy go!》是《BanG Dream!》企划组合Afterglow的6th单曲，发售于2020年3月11日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2019年12月22日在YouTube上发布。
初回封入特典：单曲封面角色卡1张（共5种）、Weiß Schwarz PR卡1张（共6种）和「Afterglow×Pastel＊Palettes×Hello, Happy World!6th单曲发售特别活动」抽选券。

## 试听动画

## 收录曲目

## Blu-ray收录内容

动画《BanG Dream! 3rd Season》 #8~#9
BanG Dream! TV 特别篇#5

## 外部链接

试听动画
（日文）官网CD介绍页
