---
title: Hello, Happy World!翻唱歌曲2 - We Are!
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - We Are!

## We Are!

《ウィーアー！》由Hello, Happy World!演唱。原曲是TV动画《海贼王》的OP1，原唱为北谷洋。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.5，发售于2021年2月24日。
kkr富可敌国，海贼王有one piece，kkr=海贼王，所以我要成为海贼王的女人

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EX难度

（待补充）
