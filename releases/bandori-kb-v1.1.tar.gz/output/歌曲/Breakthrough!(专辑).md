---
title: Breakthrough!(专辑)
url: https://zh.moegirl.org.cn/Breakthrough%21%28%E4%B8%93%E8%BE%91%29
revision: 8540452
updated: '2026-07-01'
categories:
- 2020年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
---

# Breakthrough!(专辑)

《Breakthrough!》是《BanG Dream!》企划组合Poppin'Party的2nd专辑，发售于2020年6月24日。分为Blu-ray付生产限定盘、通常盘两种规格。Blu-ray付生产限定盘还另外赠送写真集，全36p。
Disc1收录了从12th《キズナミュージック♪》至15th《イニシャル/夢を撃ち抜く瞬間に！》的全部主打曲目，以及合作单曲《NO GIRL NO CRY》的Poppin'Party版，和6首未发售曲目。
Disc2仅收录在Blu-ray付生产限定盘。收录了从1st《Yes! BanG_Dream!》至15th《イニシャル/夢を撃ち抜く瞬間に！》的所有C/W曲。

## 在线试听

## 收录曲目

## Blu-ray收录内容

《Breakthrough!》真人MV
Poppin'Party Fan Meeting Tour 2019!宇宙へドリーマーズGO!
1.朗読劇2.B.O.E ～Believe Our EKAKIUTA～3.ポピパ、あのね…4.ぽっぴん即興劇♪5.ファンミのテーマソングを作ろう！1.Yes! BanG_Dream!2.前ヘススメ！3.Time Lapse4.Dreamers Go!

## 注释与外部链接

（日文）官网CD介绍页
