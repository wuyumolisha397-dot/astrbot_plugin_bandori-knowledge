---
title: 期待不已meets Trip(单曲)
url: https://zh.moegirl.org.cn/%E6%9C%9F%E5%BE%85%E4%B8%8D%E5%B7%B2meets%20Trip%28%E5%8D%95%E6%9B%B2%29
revision: 8525072
updated: '2026-06-28'
categories:
- 2020年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 带有失效视频的条目
---

# 期待不已meets Trip(单曲)

《ワクワクmeetsトリップ》是《BanG Dream!》企划组合Pastel*Palettes的第六张单曲，发售于2020年3月4日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听动画于2019年12月22日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：单曲封面角色卡1张（共6种）、Weiß Schwarz PR卡1张（共6种）和「Afterglow×Pastel＊Palettes×Hello, Happy World!6th单曲发售特别活动」抽选券。

## 试听动画

## 收录曲目

## Blu-ray收录内容

动画《BanG Dream! 3rd Season》 #6~#7
BanG Dream! TV 特别篇#4

## 外部链接与注释

（日文）官网CD介绍页
