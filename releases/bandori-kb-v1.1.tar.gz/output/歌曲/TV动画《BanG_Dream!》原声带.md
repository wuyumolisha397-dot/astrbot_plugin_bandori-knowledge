---
title: TV动画《BanG Dream!》原声带
url: https://zh.moegirl.org.cn/TV%E5%8A%A8%E7%94%BB%E3%80%8ABanG%20Dream%21%E3%80%8B%E5%8E%9F%E5%A3%B0%E5%B8%A6
revision: 8557406
updated: '2026-06-30'
categories:
- BanG Dream!音乐唱片
- 原声带
---

# TV动画《BanG Dream!》原声带

《TVアニメ「BanG Dream!」オリジナル・サウンドトラック》是TV动画《BanG Dream!》的原声带，发售于2017年4月26日。分为Blu-ray付生产限定盘、通常盘两种规格。宣传CM于2017年1月28日在YouTube上发布。
收录有动画OP《ときめきエクスペリエンス！》与ED《キラキラだとか夢だとか ～Sing Girls～》的TV Size版本。
除此之外还收录了Poppin'Party演唱的《私の心はチョココロネ》的TV Size版本、Glitter*Green演唱的《Don't be afraid!》和《Glee! Glee! Glee!》、CHiSPA演唱的《Be shine, shining!》、户山香澄（CV.爱美）演唱的《きらきら星 ～はじまりのステージVer.～》等插曲与BGM。
BD收录了BanG Dream! Second☆LIVE Starrin' PARTY 2016!的Live映像以及一部特典映像。

## 宣传CM

## 收录曲目

## Blu-ray内容

“BanG Dream! Second☆LIVE Starrin' PARTY 2016!” at TOKYO DOME CITY HALL
节目列表：
1.ドラマ 〜2016年11月13日〜
2.OPENING
3.ぽっぴん’しゃっふる
4.夏空 SUN! SUN! SEVEN!
5.Crow Song（TV动画《Angel Beats!》插曲）
6.ふわふわ時間（TV动画《轻音少女》插曲）
7.ETERNAL BLAZE（TV动画《魔法少女奈叶A's》片头曲）
8.ドラマ 〜ある星の見える夜〜
9.ぽっぴん’しゃっふる Acoustic Ver.
10.STAR BEAT!〜ホシノコドウ〜 Acoustic Ver.
11.走り始めたばかりのキミに
12.ティアドロップス
13.Yes! BanG_Dream!
EN1.1000回潤んだ空
EN2.STAR BEAT!〜ホシノコドウ〜
EN3.ENDING
特典映像「メイキング映像〜舞台裏 de ポッピン！〜」

### Live映像

## 外部链接与注释

宣传CM
（日文）官网CD介绍页
