---
title: GLOW GOES ON
url: https://zh.moegirl.org.cn/GLOW%20GOES%20ON
revision: 8457821
updated: '2026-06-28'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# GLOW GOES ON

《GLOW GOES ON》是《BanG Dream!》企划组合Afterglow的第二张迷你专辑，发售于2025年7月2日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为一张《JR東海 presents 出発進行！バンドリ！10周年記念トークジャーニー！》谈话会巡演的最速先行抽选申请券以及一张角色卡片（共5种）。

## 收录曲目

## Blu-ray收录内容

Afterglow「After School Event 夕景の一頁」1部·2部公演映像

## 外部链接

（日文）官网CD介绍页
