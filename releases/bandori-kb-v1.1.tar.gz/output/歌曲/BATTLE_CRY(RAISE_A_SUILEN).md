---
title: BATTLE CRY(RAISE A SUILEN)
url: https://zh.moegirl.org.cn/BATTLE%20CRY%28RAISE%20A%20SUILEN%29
revision: 8547295
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 使用标题格式化的页面
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

《BATTLE CRY》是《BanG Dream!》多媒体企划中女子摇滚乐队 RAISE A SUILEN 的一首原创歌曲。该曲由企划内核心主唱 LAYER（和奏瑞依）倾情演唱，配合 CHU²（珠手知由）的词曲创作与键盘编排，以及 LOCK（朝日六花）、MASKING（佐藤益木）、PAREO（鳰原令王那）的吉他、鼓与键盘演奏，共同呈现出乐队标志性的强劲流行摇滚风格。

这首歌曲在正式收录前，曾于 RAISE A SUILEN 的线上演唱会「ESSENTIALS」中作为惊喜曲目首次公开演奏。充满爆发力的现场演绎与极具感染力的旋律，让这首作品在正式发布前便赢得了乐迷的热烈反响与高度期待。

在游戏领域，该曲被选为手机音乐游戏《BanG Dream! 少女乐团派对！》第237期活动「A step to the WORLD」的专属活动主题曲，并于2023年10月10日在日服正式实装。其充满活力的节奏与乐队极具攻击性的硬核曲风完美契合，为玩家带来了极具张力的视听体验。

在实体唱片发行方面，《BATTLE CRY》被收录于 RAISE A SUILEN 的第二张正规专辑《SAVAGE》中，该专辑于2024年6月12日正式发售。作为专辑内的核心曲目之一，这首歌不仅延续了 RAISE A SUILEN 始终坚持的“最强音乐与舞蹈”的核心理念，更展现了五位成员在音乐道路上不断突破自我、向世界宣战的坚定姿态。无论是作为游戏内的活动主题曲，还是作为实体专辑中的重要一环，《BATTLE CRY》都凭借其高燃的基调与出色的乐队表现力，成为了 RAISE A SUILEN 音乐历程中一首极具代表性的优秀作品。
