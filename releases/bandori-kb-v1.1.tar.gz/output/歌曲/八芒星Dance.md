---
title: 八芒星Dance
url: https://zh.moegirl.org.cn/%E5%85%AB%E8%8A%92%E6%98%9FDance
revision: 8547313
updated: '2026-06-30'
categories:
- Ave Mujica歌曲
- BanG Dream!音乐
- 佐佐木李子歌曲
- 冈田梦以歌曲
- 插曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 渡濑结月歌曲
- 米泽茜歌曲
- 高尾奏音歌曲
---

# 八芒星Dance

「八芒星ダンス」（英文标题：Octagram Dance）是企划《BanG Dream!》旗下组合Ave Mujica的原创歌曲，也是动画《BanG Dream! Ave Mujica》第13话的插入曲之一，收录于Ave Mujica的首专《Completeness》。

## 简介

本曲是TV动画《BanG Dream! Ave Mujica》第13话里，Ave Mujica的开场曲目，其正式MV发布于2025年4月23日。
歌词中包含大量马戏团的意象，也因此无论是TV动画中还是MV里，角色的舞台演出都在模仿马戏团风格。与此类似，声优现场演奏此曲时也会玩点杂技，例如MyGO!!!!!×Ave Mujica联合演唱会《分歧路口，前途漫漫》上，渡濑结月便复刻了动画中若叶睦甩吉他的动作。Ave Mujica 6th LIVE Ulterius Procedere上佐佐木李子更是在同一位置整出了侧手翻的绝活。
八芒星象征着太阳，代表了太阳在一个回归年的视循环运动，即一年四季的循环变化。因此，它常被用来代表“永恒”、“无限”、“和谐”与“超越”。同时在犹太教等传统中，数字“7”代表圆满，而紧随其后的“8”则象征着新的开始。因此，八芒星也象征着复活与重生。

## 歌曲试听

游戏版

完整版

## 歌曲视频

官方MV

动画MV

## 歌词

该歌词已还原BK

翻译取自官方B站MV中文字幕。

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 Doloris  Mortis  Timoris  Amoris  Oblivionis  合唱

## BanG Dream! 少女乐团派对！

于2025年3月27日作为TV动画《BanG Dream! Ave Mujica》完结纪念在日服和简中服实装。

## 注释及外部链接
