---
title: Drive Your Heart(单曲)
url: https://zh.moegirl.org.cn/Drive%20Your%20Heart%28%E5%8D%95%E6%9B%B2%29
revision: 8487936
updated: '2026-07-01'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Drive Your Heart(单曲)

《Drive Your Heart》是《BanG Dream!》企划组合Poppin'Party的21st单曲，发售于2025年12月24日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为一张Poppin'Party×Roselia 合同ライブ「DREAMS GO ON」东京公演的最速先行抽选申请券、一张原创角色卡片（共5种）以及一张《卡片战斗先导者》PR卡。
在特定实体或电子商店与《Poppin'Party 10th Anniversary LIVE「ホシノコドウ」Blu-ray》一并购买将限量赠送附有复刻烫印角色签名的双面B2海报。

## 收录曲目

## Blu-ray收录内容

Poppin'Partyトークイベント「ポピパの新学期！」 1部、2部公演映像

## 注释和参考链接

## 外部链接

（日文）官网CD介绍页
