---
title: BanG Dream! 少女乐团派对！翻唱曲合辑Vol.1
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91Vol.1
revision: 8557394
updated: '2026-06-30'
categories:
- 2018年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 条目中存在只限中国内地播放的音频
- 翻唱专辑
---

# BanG Dream! 少女乐团派对！翻唱曲合辑Vol.1

《バンドリ！ ガールズバンドパーティ！ カバーコレクション Vol.1》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》的1st翻唱曲专辑，发售于2018年6月27日。
收录了手游五大团每团2首翻唱曲，共10首。

## 歌曲试听

## 收录曲目

## 外部链接与注释

（日文）官网CD介绍页
