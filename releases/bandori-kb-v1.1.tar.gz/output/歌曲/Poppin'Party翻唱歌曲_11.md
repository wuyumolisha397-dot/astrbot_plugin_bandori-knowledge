---
title: Poppin'Party翻唱歌曲 - DAYS
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - DAYS

## DAYS

《DAYS》由Poppin'Party演唱。原曲是TV动画《交响诗篇》的OP。原唱为FLOW。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.2，发售于2019年3月16日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：Summer-iii

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  山吹沙绫  合唱

### 谱面

第四十七期（国服为四十八期）活动《星期日 在稍远的公园中》作为对邦课题曲目追加。

#### EXPERT难度

相当考验绿条双边协调能力的25上位,300多combo地带有复杂红蓝交互。由于演奏时间长，协力效率也低，在活动协力不常有人选择。
