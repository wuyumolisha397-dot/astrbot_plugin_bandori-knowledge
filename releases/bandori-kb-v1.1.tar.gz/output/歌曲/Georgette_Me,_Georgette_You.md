---
title: Georgette Me, Georgette You
url: https://zh.moegirl.org.cn/Georgette%20Me%2C%20Georgette%20You
revision: 8547274
updated: '2026-06-30'
categories:
- Ave Mujica歌曲
- BanG Dream!音乐
- C/W曲
- 佐佐木李子歌曲
- 冈田梦以歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 渡濑结月歌曲
- 片尾曲
- 米泽茜歌曲
- 高尾奏音歌曲
---

# Georgette Me, Georgette You

「Georgette Me, Georgette You」是企划《BanG Dream!》旗下组合Ave Mujica的第二张单曲《KiLLKiSS》的C/W曲，也是动画《BanG Dream! Ave Mujica》的片尾曲。于2025年1月15日作为数字独立单曲发售。
曲目标题中的“georgette”为法语，中译“乔其纱”，是一种半透明的轻质绉布纺织品，由高度加捻的纱线制成，常用于缝制连衣裙、晚礼服、纱丽和家居装饰。
同时Georgette也是George的女名写法，另外Georgette可以作为舞台假名使用，并且在演员分饰两角时，它的确能起到防止“穿帮”或提前泄露剧情的作用。

## 歌曲试听

完整版

## 歌曲视频

## 歌词

该歌词已还原BK

前半部分翻译：官方B站MV中文字幕
后半部分翻译：EmpyreusX

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 Doloris  Mortis  Timoris  Amoris  Oblivionis  合唱

## BanG Dream! 少女乐团派对！

### 谱面

日服于2025年1月9日追加此歌曲；简中服于2025年1月13日追加此歌曲；国际服于2025年1月14日（即Ave Mujica成员Mortis/若叶睦生日当天）追加此歌曲。

#### EXPERT难度

（待补充）

## 注释及外部链接
