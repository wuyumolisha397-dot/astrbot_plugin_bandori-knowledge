---
title: Wahl
url: https://zh.moegirl.org.cn/Wahl
revision: 8544328
updated: '2026-06-28'
categories:
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 带有失效视频的条目
---

# Wahl

《Wahl》（德语：选择）是《BanG Dream!》企划组合Roselia的2nd专辑，发售于2020年7月15日。分为Blu-ray付生产限定盘、通常盘两种规格。Blu-ray付生产限定盘还另外赠送写真集，全52p。
其中Blu-ray付生产限定盘的背面将会有Roselia二次元成员版权绘。这也使《Wahl》成为Roselia名义发售的CD中第一张拥有严格意义的二次元成员版权绘。
本专辑的标题“Wahl”为手游BanG Dream! 少女乐团派对！中Roselia剧情活动《ノーブル・ローズ -歌、至りて-》（第81期）的关键词。再加上曲目安排和二次元成员版权绘的暗示，《Wahl》可以说是配合ノーブル・ローズ系列活动剧情制作的专辑。

## 歌曲试听

## 收录曲目

## 曲目收录杂谈

或许是因为曲数限制（12首）和呼应《ノーブル・ローズ》剧情的需要，《Wahl》放弃了7th到9th单曲中的三首CW（尽管这三首都是活动剧情曲）并选择了已收录在1st专辑《Anfang》中的三首乐曲。

不过BD限定盘中收录了Sanctuary和Ringing Bloom的富士急LIVE影像，某种意义上只有PASSIONATE ANTHEM没有收录在《Wahl》中。
Determination Symphony同时作为游戏活动曲和《BanG Dream! 2nd Season》插入歌，也是《ノーブル・ローズ》系列剧情中突出冰川纱夜部分的重要歌曲。
乐曲Re:birth day和Neo-Aspect分别为Roselia乐队剧情两首主题曲，同时乐曲Neo-Aspect也在活动《ノーブル・ローズ -歌、至りて-》剧情中有所提及。
值得一提的是，专辑中收录的《R》、《BRAVE JEWEL》、《Safe and Sound》、《Re:birth day》、《Determination Symphony》、《Neo-Aspect》的白金燐子的和声与独唱部分的音轨，由原先明坂聪美担当演唱的版本更换成了志崎桦音担当演唱重新录制的版本。那为啥没重做《BLACK SHOUT》啊…于是收录在三专《Für immer》里了
收录曲顺最后三首乐曲均为游戏活动《ノーブル・ローズ》系列主题曲，依时间顺序排列。
Roselia 1st专辑《Anfang》（译：开端）中最后一首曲目为LOUDER，2nd专辑《Wahl》（译：选择）中最后一首曲目为Song I am.，完全对应活动《ノーブル・ローズ -歌、至りて-》剧情中对两首乐曲的说明。

## Blu-ray收录内容

Roselia Live「Flamme/Wasser」 Live映像

## 注释

## 外部链接

（日文）官网CD介绍页
