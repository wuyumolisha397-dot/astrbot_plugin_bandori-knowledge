---
title: Girl's Code(单曲)
url: https://zh.moegirl.org.cn/Girl%27s%20Code%28%E5%8D%95%E6%9B%B2%29
revision: 8461204
updated: '2026-07-01'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Girl's Code(单曲)

《ガールズコード》是《BanG Dream!》企划组合Poppin'Party的11th单曲，发售于2018年10月3日。
主打曲《ガールズコード》的试听动画于2018年8月8日在YouTube上发布，C/W曲《切ないSandglass》的试听动画于2018年9月1日在YouTube上发布。

## 试听动画

ガールズコード

切ないSandglass

## 收录曲目

## 外部链接与注释

试听动画：ガールズコード、切ないSandglass
（日文）官网CD介绍页
