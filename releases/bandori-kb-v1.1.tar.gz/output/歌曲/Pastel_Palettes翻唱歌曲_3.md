---
title: Pastel*Palettes翻唱歌曲 - 雀斑
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - 雀斑

## 雀斑

《そばかす》由Pastel*Palettes演唱。原曲是TV动画《浪客剑心》的片头曲。原唱为JUDY AND MARY。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：青涩果实W

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### NORMAL难度

谱面音符密度最低的Normal，比10级的Yes! BanG_Dream! Normal还低。

#### EXPERT难度

比较友好的23级下位谱面，但考虑交互部分很难压gr标23并非完全不合理。

#### SPECIAL难度

第五十五期活动《通往梦想的散步小~路》追加，作为该期挑战曲目。
谱面以长押和滑按为主，绿条开头、结尾和节点在总物量中的占比极高（不出意外是全游最高），堪称绿条地狱。但由于没有带节点的超短滑，因此还是比重生日、打碟歌ex的绿条好对付很多。然而这样一张以绿条为主要配置的谱面，对大部分玩家来说阻碍FC的最大难点并不是绿条，而是副歌中间的两对12分连续双红键。
