---
title: Dreamers Go!/Returns
url: https://zh.moegirl.org.cn/Dreamers%20Go%21%2FReturns
revision: 8540382
updated: '2026-07-01'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

# Dreamers Go!/Returns

《Dreamers Go!/Returns》是《BanG Dream!》企划组合Poppin'Party的14th单曲，发售于2019年5月15日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2019年3月28日在YouTube上发布。
初回封入特典为角色卡片一张（全5种）。

## 试听动画

## 收录曲目

## Blu-ray收录内容

TV动画《BanG Dream! 2nd Season》第1、2话
Web版下集预告#1~#2
TV动画《BanG Dream! 2nd Season》CM Poppin'Party篇

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
