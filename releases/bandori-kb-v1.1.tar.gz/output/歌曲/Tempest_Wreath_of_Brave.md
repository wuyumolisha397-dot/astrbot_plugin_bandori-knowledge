---
title: Tempest/Wreath of Brave
url: https://zh.moegirl.org.cn/Tempest%2FWreath%20of%20Brave
revision: 8462504
updated: '2026-06-28'
categories:
- 2024年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

# Tempest/Wreath of Brave

《Tempest/Wreath of Brave》是《BanG Dream!》企划组合Morfonica的7th单曲，发售于2024年10月9日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为《Morfonica LIVE「Rubato」》的最速先行抽选申请券以及一张原创角色卡片（共5种）。

## 收录曲目

## Blu-ray收录内容

《Morfonica Concept LIVE「forte」》Live映像

## 外部链接

（日文）官网CD介绍页
