---
title: 竞宴Red×Violet
url: https://zh.moegirl.org.cn/%E7%AB%9E%E5%AE%B4Red%C3%97Violet
revision: 8545079
updated: '2026-06-30'
categories:
- Afterglow歌曲
- BanG Dream!音乐
- Roselia歌曲
- 三泽纱千香歌曲
- 中岛由贵歌曲
- 佐仓绫音歌曲
- 加藤英美里歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 日笠阳子歌曲
- 樱川惠歌曲
- 相羽爱奈歌曲
- 金元寿子歌曲
---

# 竞宴Red×Violet

## 简介

《競宴Red×Violet》是剧场版动画《BanG Dream! FILM LIVE 2nd Stage》的三首轮替安可曲之一，由Afterglow和Roselia共同演唱。收录于《劇場版「BanG Dream! FILM LIVE 2nd Stage」Special Songs》。

## 歌曲试听

## 歌词

翻译:茶喵子酱

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 美竹兰  凑友希那  合唱

## 歌词彩蛋

同是剧场版混团的三首曲目，歌词中也有各自乐队的歌词对应，可能不完整，以下是确认部分
中村老师和织田老师都是塞彩蛋狂魔

「戦いは 必然」→RED RED RED
「魂は眩しく」→ONE OF US
「何処まで着いて来れる?」→SENSENFUKOKU
「Ah…賭ける想い」→PASSIONATE ANTHEM、Avant-garde HISTORY、ONENESS
「この瞬間だけは譲らない」→PASSIONATE ANTHEM
「より一層　視界は冴え渡り」→BLACK SHOUT、Safe and Sound
「油断をすれば」→ON YOUR MARK
「飲み込まれるわ」→Avant-garde HISTORY
「思わず溢れる笑みに　武者震い」→Hey-day狂騒曲(カプリチオ)
「細胞よ　踊れ」→PASSIONATE ANTHEM
「それぞれの誇り」→SENSENFUKOKU

## BanG Dream! 少女乐团派对！

### Expert难度

Roselia和Afterglow的共演曲目难度想必不会低，28的难度，1000+的物量也不算出人意料。
全曲充斥着各种各样的绿粉配置尾杀会让你感受每个绿条后都是红键收尾的感觉，对绿粉的考察相当综合，低bpm高难度曲目中常见16分二连和多组24分交互对手速也提出了一定的要求。（148BPM的24分连打并不好对付，相当于222BPM的16分连打，超越YOLO的210BPM下的16分连打，比得上150BPM24分连打的full版火鸟尾杀）
NPS和Ringing Bloom EX、六兆年 SP、天弱 SP基本一样，均为9.0，但是巨量的多节点滑条导致物量水分过大，总体来说还是算比较简单的28级（但在近期28有变得越来越水的趋势下，本曲并没有到逆诈欺的程度）。凭这首歌的节奏完全可以期待一个可以比肩セツナトリップ SP的special难度。
“×”型绿条在曲子中多次出现，歌名的存在感非常强烈。

## 注释与外部链接
