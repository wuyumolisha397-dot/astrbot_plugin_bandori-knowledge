---
title: BanG Dream!特殊组合翻唱歌曲 - 如果我成为大统领
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 如果我成为大统领

## 如果我成为大统领

《シル・ヴ・プレジデント》由Hello, Happy World!、丸山彩（CV.前岛亚美）和仓田真白（CV.进藤天音）共同演唱。原唱为P丸様。。
完整版收录于《BanG Dream! 少女乐团派对！翻唱曲合辑Vol.7》，发售于2022年12月14日。
2022年12月22日，官方在生放中公布了与P丸様。的EXTRA曲目企划，本曲再一次被提名所以现在到底该听哪个版本呢？我全都要.jpg

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

#### EXPERT难度
