---
title: DANCING DARING
url: https://zh.moegirl.org.cn/DANCING%20DARING
revision: 8547292
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# DANCING DARING

「DANCING DARING」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲。

## 简介

本曲配信于2023年9月4日，收录于2024年6月12日发售的RAISE A SUILEN的2nd专辑《SAVAGE》中。
本曲是手游活动第222期活动「Power Chord Reverberation」的活动曲，日服实装于2023年5月10日。
本曲于「Boot IGNITION」上被首次演奏，距离本曲于日服实装已过去三年。

## 歌曲试听

完整版

## 歌词

该歌词已还原BK
翻译：面向局外的边缘人

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

### EXPERT难度

## 注释与外部链接
