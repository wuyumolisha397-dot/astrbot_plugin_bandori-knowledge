---
title: RAISE A SUILEN翻唱歌曲 - 狐妖少女
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - 狐妖少女

## 狐妖少女

《メギツネ》由RAISE A SUILEN演唱。原唱是BABYMETAL。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.7，发售于2022年12月14日。
国服赶超日服指日可…什么已经超了？这首歌的相关数据在2022年6月7日维护后意外出现在了国服的包体内国服运营组你好强大，居然搞到日服都没有实装的歌

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  CHU²

### 谱面

本曲并未在日服首先上线而是在国服和国际服首先上线，成为了第一个没有在日服首先实装的翻唱曲海外有人权尽管只早了一天

#### EXPERT难度
