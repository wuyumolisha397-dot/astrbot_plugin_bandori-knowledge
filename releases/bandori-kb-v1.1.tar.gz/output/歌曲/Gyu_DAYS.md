---
title: Gyu DAYS
url: https://zh.moegirl.org.cn/Gyu%20DAYS
revision: 8543312
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 使用标题替换的页面
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
---

# Gyu DAYS

## 简介

《ぎゅっDAYS♪》是《BanG Dream!》企划组合Pastel*Palettes 6th 单曲《ワクワクmeetsトリップ 》的C/W曲，单曲于2020年3月4日发售。

## 歌曲试听

Game Size

完整版

## 歌词

翻译：网易云音乐

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

## BanG Dream! 少女乐团派对！

第66期活动《活出、理想的自我》主题曲，为当期活动挑战曲之一。
拥有全游第三首11级Easy。

### Hard难度

谱面有很多转接的绿条，但是平均密度不大，符合20级水平。

### EXPERT难度

26级标准偏上水平，在同团、同级的曲目中，比SURVIVOR Never Give Up略难，比atoz简单az明明27。
两处16分交互连打、副歌的短滑条+双粉、结尾的粉键穿插和最后的粉尾滑条都是难点，初见杀成分严重，稍有不慎就会断Combo，读谱较慢的话更有可能大面积崩坏。

## 外部链接与注释
