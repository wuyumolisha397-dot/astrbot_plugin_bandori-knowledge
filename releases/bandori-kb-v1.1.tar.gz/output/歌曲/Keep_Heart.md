---
title: Keep Heart
url: https://zh.moegirl.org.cn/Keep%20Heart
revision: 8544383
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# Keep Heart

## 简介

《Keep Heart》是企划《BanG Dream!》旗下组合Roselia歌曲。同时为游戏第300首追加的歌曲。
歌曲完整版初收录于2021年12月15日发售的剧场版 BanG Dream! Episode of Roselia I：约束的BD附带特典CD，并同时在音乐平台配信；后于2024年6月26日发售的Roselia 3rd专辑《Für immer》再次收录。

## 歌曲试听

## 歌词

翻译：BurstAlpha

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  冰川纱夜  今井莉莎  宇田川亚子  白金燐子  合唱

## BanG Dream! 少女乐团派对！

该曲目是日服在2021年1月21日举行的第139次活动「テリブル·ホラー·ナイト」的活动歌曲。

### EXPERT难度

27级底力曲，谱面 (特别是交互与红键) 与某宣战布告颇为相似，可视作其弱化版。

## 外部链接与注释
