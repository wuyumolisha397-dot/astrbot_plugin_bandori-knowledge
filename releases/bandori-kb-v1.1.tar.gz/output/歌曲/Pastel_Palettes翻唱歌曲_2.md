---
title: Pastel*Palettes翻唱歌曲 - Dream Parade
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - Dream Parade

## Dream Parade

《ドリームパレード》由Pastel*Palettes演唱。原曲是TV动画《美妙天堂》第2季的片头曲。原唱为i☆Ris。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：雪_琉夏

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EX难度

逆诈称26，物量较低，没有那些低物量高难度谱面的卡手/局部发狂地带手动@贼船、opera of the wasteland，总体难度接近后期25，只要注意红键就能冲击FC。
