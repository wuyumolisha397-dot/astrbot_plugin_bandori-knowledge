---
title: FIVE as ONE
url: https://zh.moegirl.org.cn/FIVE%20as%20ONE
revision: 8547439
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# FIVE as ONE

「FIVE as ONE」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲。

## 简介

本曲是手游活动298期「Baby steps!」的活动曲，完整版收录于2025年11月12日发售的RAISE A SUILEN的14th单曲《'FIGHT' ADDICT》中。
本曲于「RUMBLEHEADZ」上被首次演奏，在两日演出中的演奏顺序都排在「REIGNING」之后，且两曲之间有一段简短的键盘Solo进行衔接。

## 歌曲试听

## 歌词

该歌词已还原BK
翻译：Res_Ty

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

## 注释
