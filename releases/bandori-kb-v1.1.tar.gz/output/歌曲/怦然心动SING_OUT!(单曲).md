---
title: 怦然心动SING OUT!(单曲)
url: https://zh.moegirl.org.cn/%E6%80%A6%E7%84%B6%E5%BF%83%E5%8A%A8SING%20OUT%21%28%E5%8D%95%E6%9B%B2%29
revision: 8550483
updated: '2026-07-01'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 怦然心动SING OUT!(单曲)

《どきどきSING OUT!》是TV动画《BanG Dream!》主角户山香澄（CV.爱美）的角色歌专辑，发售于2017年4月5日。试听动画于2017年4月5日在YouTube上发布。
另收录了由户山香澄演唱的《ティアドロップス》的Acoustic版本作为C/W曲。
初回封入特典为ESP合作角色拨片（户山香澄ver.）、角色歌五首联动特别报名券等。各店铺特典为写真、徽章、收纳盒等。

## 试听动画

## 收录曲目

## 外部链接与注释

试听动画
（日文）官网CD介绍页
