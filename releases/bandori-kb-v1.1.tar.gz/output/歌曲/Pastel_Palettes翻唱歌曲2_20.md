---
title: Pastel*Palettes翻唱歌曲2 - 喜欢你Chu！
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 喜欢你Chu！

## 喜欢你Chu！

《すきっちゅーの！》由Pastel*Palettes演唱。原唱是かぴ。

### 歌曲试听

### 歌词

### 谱面

#### EXPERT难度

（待补充）
