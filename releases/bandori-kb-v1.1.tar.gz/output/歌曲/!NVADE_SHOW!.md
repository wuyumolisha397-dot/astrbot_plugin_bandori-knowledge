---
title: '!NVADE SHOW!'
url: https://zh.moegirl.org.cn/%21NVADE%20SHOW%21
revision: 8544372
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 纺木吏佐歌曲
---

《!NVADE SHOW!》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的原创歌曲，也是剧场版动画《BanG Dream! FILM LIVE 2nd Stage》及《BanG Dream! ぽっぴん'どりーむ！》的插入曲。歌曲收录于RAISE A SUILEN第一张专辑《ERA》中，该专辑于2020年8月19日发售。曲名中的“!NVADE”源自单词“INVADE”，意为“入侵”。这首歌曲首次公开演奏是在名为“THE DEPTHS”的演出活动中。

在手机游戏《BanG Dream! 少女乐团派对！》中，该曲于RAS主线故事第一章（下）更新时同步实装，玩家需阅读第25话后方可解锁。游戏内设有Expert难度，以其相对较低的谱面难度而受到玩家关注，被认为是27级中最容易的歌曲之一。
