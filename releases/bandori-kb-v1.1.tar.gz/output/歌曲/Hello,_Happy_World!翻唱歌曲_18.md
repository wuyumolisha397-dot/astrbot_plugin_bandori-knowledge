---
title: Hello, Happy World!翻唱歌曲 - 恋爱裁判
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542918
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲 - 恋爱裁判

## 恋爱裁判

《恋愛裁判》由Hello, Happy World!演唱。原曲是 VOCALOID 传说曲，原唱为初音未来。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.4，发售于2020年5月27日。
另收录于Garupa Vocaloid翻唱曲合辑，发售于2020年12月16日。

### 歌曲试听

游戏版

完整版

### 歌词

翻译：黑暗新星

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

中上位的25。难点体现在中段各种令人瞠目结舌（大爆死）的扭曲滑条低配打碟歌对于较难掌握小绿条或者拇指玩家而言，难度堪比26。然而，如果能够克服掉滑条段的话，就只是普通的25级水准（但是红键配置还是得注意）。
