---
title: BanG Dream! 翻唱曲合辑 Extra Volume
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91%20Extra%20Volume
revision: 8440574
updated: '2026-06-30'
categories:
- 2024年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 翻唱专辑
---

# BanG Dream! 翻唱曲合辑 Extra Volume

《バンドリ！カバーコレクション Extra Volume》是《BanG Dream!》企划的一张翻唱曲专辑，发售于2024年7月10日。分为Blu-ray付生产限定盘、通常盘两种规格。
专辑分别收录了企划中组合MyGO!!!!!和Ave Mujica的各三首翻唱歌曲，由于在发售时手游未收录Ave Mujica的三首翻唱曲，因此本专辑是以企划名义而不是手游名义发售的。
初回封入特典：

一张《MyGO!!!!!の「迷子集会」出張版 第二弾 - 日常の欠片 -》的最速先行抽选申请券；
《Ave Mujica 3rd LIVE「Veritas」》和《Ave Mujica 4th LIVE「Adventus」》的最速先行抽选申请券各一张；
一张CD封面图贴纸。

## 收录曲目

## Blu-ray收录内容

Roselia「Farbe」开场嘉宾Live映像

Day1：MyGO!!!!!
影色舞
碧天伴走
壱雫空
Day2：Ave Mujica
Ave Mujica
神さま、バカ
Mas?uerade Rhapsody Re?uest

## 外部链接

（日文）官网CD介绍页
