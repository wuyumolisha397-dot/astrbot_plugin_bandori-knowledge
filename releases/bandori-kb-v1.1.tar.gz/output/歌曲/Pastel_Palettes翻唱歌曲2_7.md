---
title: Pastel*Palettes翻唱歌曲2 - 向夜晚飞奔
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 向夜晚飞奔

## 向夜晚飞奔

《夜に駆ける》由Pastel*Palettes演唱。原曲是小说《塔纳托斯的诱惑》以及《溶于夜中》的印象曲，原唱是YOASOBI。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

国服以庆祝夏之律动名义于7月13日超前实装。

#### EXPERT难度

标称26，但实际上没有26的配置，只有25中下的程度，公认的逆诈称EX牌26Great10以下之友
