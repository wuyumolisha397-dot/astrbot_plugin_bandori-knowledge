---
title: BanG Dream! 少女乐团派对！/曲目列表/翻唱曲目
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%2F%E6%9B%B2%E7%9B%AE%E5%88%97%E8%A1%A8%2F%E7%BF%BB%E5%94%B1%E6%9B%B2%E7%9B%AE
revision: 8561800
updated: '2026-06-30'
categories:
- BanG Dream!列表
- 音乐游戏歌曲列表
---

# BanG Dream! 少女乐团派对！/曲目列表/翻唱曲目

绿字解锁条件是包括繁中服，红字解锁条件是已经确定只在日服上线。

## Poppin'Party

## Afterglow

## Pastel*Palettes

## Roselia

## Hello, Happy World!

## Morfonica

## RAISE A SUILEN

## MyGO!!!!!

## 其他

## 注释及外部链接
