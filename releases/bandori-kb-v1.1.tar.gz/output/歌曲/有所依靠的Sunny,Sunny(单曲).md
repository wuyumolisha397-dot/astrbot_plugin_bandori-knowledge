---
title: 有所依靠的Sunny,Sunny(单曲)
url: https://zh.moegirl.org.cn/%E6%9C%89%E6%89%80%E4%BE%9D%E9%9D%A0%E7%9A%84Sunny%2CSunny%28%E5%8D%95%E6%9B%B2%29
revision: 8461161
updated: '2026-06-28'
categories:
- 2022年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 有所依靠的Sunny,Sunny(单曲)

《寄る辺のSunny, Sunny》是《BanG Dream!》企划组合Morfonica的5th单曲，发售于2022年9月14日。分为Blu-ray付生产限定盘与通常盘两种规格。
试听动画于2022年7月29日在YouTube的BanG Dream!官方频道上发布。
初回封入特典：一张BanG Dream! 11th☆LIVE DAY2的抽选券，以及一张角色卡片。

## 试听动画

## 收录曲目

## Blu-ray收录内容

### Disc 1

TV动画《BanG Dream! Morfonication》原声带
1.くじらの夢
2.モニカの団欒
3.密かな計画
4.ましろの憂鬱
5.消える世界
6.重なる想い
7.輝く景色に向かって
TV动画《BanG Dream! Morfonication》

## 外部链接

（日文）官网CD介绍页
