---
title: Roselia翻唱歌曲2 - sister's noise
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - sister's noise

## sister's noise

《sister's noise》由Roselia演唱。原曲是TV动画《某科学的超电磁炮S》OP1。原唱为fripSide。

### 歌曲试听

### 歌词

### 谱面

第一百三十八期活动《五光十色的二重奏》追加，作为对邦指定曲。

#### EXRERT难度

物量555，跟同为超炮主题曲的OMRSP谱物量相同。作为一首25，难度不大且时长较短，出分和效率均属中上水平，姑且可以当作效率曲。
