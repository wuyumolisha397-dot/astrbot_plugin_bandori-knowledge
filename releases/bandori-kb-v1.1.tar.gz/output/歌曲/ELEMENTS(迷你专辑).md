---
title: ELEMENTS(迷你专辑)
url: https://zh.moegirl.org.cn/ELEMENTS%28%E8%BF%B7%E4%BD%A0%E4%B8%93%E8%BE%91%29
revision: 8542122
updated: '2026-06-28'
categories:
- 2024年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
---

# ELEMENTS(迷你专辑)

《ELEMENTS》是《BanG Dream!》企划组合Ave Mujica的2nd迷你专辑，发售于2024年10月2日，发售日当日为新月。分为数量限定生产特装盘、Blu-ray付生产限定盘与通常盘三种规格。数量限定生产特装盘采用特制的豪华包装盒进行包装，但只在武士道在线商店（ブシロードオンラインストア）和活动会场独家限量销售。
专辑标题“ELEMENTS”指代古典哲学中的古典元素。专辑中前四首歌曲的标题都包含古典四大元素的炼金术符号（火、风、水、土），而第五首歌曲则指代以太。
各版本迷你专辑均有初回封入特典：一张Ave Mujica与MyGO!!!!!的联合演唱会《わかれ道の、その先へ》的最速先行抽选申请券。
数量限定生产特装盘特典还包括以专辑歌曲为设计灵感的 ELEMENTS 特制贴纸套装以及Ave Mujica 2nd LIVE「Quaerere Lumina」 -ELEMENTS Edition- 特制黑色金字硅胶带（约W202×H25mm)。
需注意，官方从未表明该专辑的歌曲为角色曲，歌曲内容均为配合Mujica 1st LIVE 至4th LIVE 幕间剧情。暂未发现可直接、唯一佐证曲子与角色存在关联的可靠证据，相关说法也尚未形成统一结论。

## 收录曲目

## Blu-ray收录内容

Ave Mujica 2nd LIVE「Quaerere Lumina」神奈川公演Live影像
素晴らしき世界 でも どこにもない場所
Ave Mujica
Angles
暗黒天国
Mas?uerade Rhapsody Re?uest
神さま、バカ
Symbol I : 🜂
KINGS
堕天
Symbol II : 🜁
Choir 'S' Choir
ふたつの月 ~Deep Into The Forest~
黒のバースデイ

## 外部链接

（日文）官网CD介绍页
