---
title: Pastel a la mode
url: https://zh.moegirl.org.cn/Pastel%20a%20la%20mode
revision: 8525293
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题替换的页面
---

# Pastel a la mode

《Pastel à la mode》（法语：时尚粉彩）是《BanG Dream!》企划组合Pastel*Palettes的第二张音乐专辑，发售于2023年5月31日。分为商品付生产限定盘、通常盘两种规格。
商品付生产限定盘附赠商品为一张装饰用假唱片与12英寸黑胶唱片封套。
初回封入特典：单曲封面贴纸1张（区分限定盘与通常盘）。

## 收录曲目

## 外部链接

（日文）官网CD介绍页
