---
title: Don't be afraid!
url: https://zh.moegirl.org.cn/Don%27t%20be%20afraid%21
revision: 8542685
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Glitter*Green歌曲
- 三森铃子歌曲
- 佐佐木未来歌曲
- 德井青空歌曲
- 插曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 橘田泉歌曲
---

# Don't be afraid!

## 简介

《Don't be afraid!》是TV动画《BanG Dream!》第1季第1~2话和第2季第7话的插曲，由Glitter*Green演唱。收录于TV动画OST。发售于2017年4月26日。
2018年11月21日Glitter*Green发售了唯一一张单曲《Don't be afraid!》，收录了该曲的完整版。

## 歌曲

Game size

完整版

## 歌词

翻译来源：网易云音乐

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

### EXPERT难度

标准的25级，配置平淡，是新人从25级下位过渡到25级中上、甚至26级的必备歌曲之一。

### SPECIAL难度

这能塞到27也是没想到27下位，主要难点是一段长散打和新键，然而对于一首27新SP来说还是比较容易。

## 注释与外部链接
