---
title: Cutie～Mighty*flower(单曲)
url: https://zh.moegirl.org.cn/Cutie%EF%BD%9EMighty%2Aflower%28%E5%8D%95%E6%9B%B2%29
revision: 8557381
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Cutie～Mighty*flower(单曲)

《きゅ～まい＊flower》是《BanG Dream!》企划组合Pastel*Palettes的5th单曲，发售于2019年9月18日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听动画于2019年4月25日在YouTube上发布。
初回封入特典为Pastel*Palettes 特别公演～まんまるお山に彩りスペシャル☆～的抽选申请卷。

## 试听动画

## 收录曲目

## Blu-ray收录内容

动画《BanG Dream! 2nd Season》 #9~#10
Web版下回预告 #9~#10
动画《BanG Dream! 2nd Season》CM Pastel＊Palettes 篇

## 外部链接与注释

试听动画
（日文）官网CD介绍页
