---
title: Poppin'Party翻唱歌曲2 - Discovery!
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - Discovery!

本条目收录乐队企划《BanG Dream!》中组合Poppin'Party在游戏及唱片中发布的翻唱歌曲。
真人乐队Poppin'Party在演唱会现场表演过的翻唱歌曲在BanG Dream! Live翻唱歌曲查看。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## Discovery!

《ディスカバリー！》由Poppin'Party演唱。原曲为手游《少女☆歌剧 Revue Starlight -Re LIVE-》的主题曲和OP曲，原唱为Starlight九九组。arisa翻唱自己
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.8，发售于2023年9月6日。

### 歌曲试听

Poppin'Party ver.(Game Size)

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

729的物量对于25级而言稍多，但没有什么太大的难点。虽然有一些短连打的出现，但底力好的玩家仍可初见FC，整体属于中位的25。
