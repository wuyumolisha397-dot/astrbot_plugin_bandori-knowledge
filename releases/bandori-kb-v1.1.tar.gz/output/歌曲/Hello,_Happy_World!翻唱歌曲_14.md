---
title: Hello, Happy World!翻唱歌曲 - EXTRA MAGIC HOUR
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542918
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲 - EXTRA MAGIC HOUR

## EXTRA MAGIC HOUR

《エクストラ・マジック・アワー》由Hello, Happy World!演唱。原曲是TV动画《甘城光辉游乐园》的OP主题曲，原唱为AKINO with bless4。
完整版收录于Hello, Happy World! 2nd专辑《SMILE ON PARADE》Disc2，发售于2023年6月28日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

第六十三期活动《冬日里的自由集市》追加，作为该期挑战曲。

#### HARD难度

EX谱面的滑条简化版，除了简化节奏之外，凡是在16分音上取节点的滑条都被简化成了2分音或4分音节点滑条，作为18级还是不难FC的。被EX的滑条折磨到怀疑人生的同学可以转向HARD谱面给自己增强一些信心。

#### EXPERT难度

HHW的第二首27级，终于正常了一些？
从整体配置上来看的确是比较正常的27级，但难点在于多根超长转折大滑条——前奏有，主歌有，副歌也有；与此同时，副歌还有两个圆圈形滑条接粉键都很容易蜜汁节点Miss，这一点颇有PA副歌开头的味道。
虽然除了绿条，还有结尾的红键密集段之外，其他部分基本是普通的上位26级水平，同时绿条节点判定有保P的特性，但节点的横向判定区并不是很宽（左右最多可以偏1轨），偏太多、该滑到最边缘的滑条没滑到最边缘等情况都会导致miss，对打歌的影响也是毫不含糊的，也为本曲难度带来了较大个人差。
同时本曲出分较高，是HHW的最强效率曲。
