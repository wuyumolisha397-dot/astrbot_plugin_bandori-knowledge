---
title: Poppin'Party翻唱歌曲2 - 群青日和
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - 群青日和

## 群青日和

《群青日和》由Poppin'Party演唱。原曲发行于2004年9月8日，原唱是东京事变。
封面致敬了原曲MV。

### 歌曲试听

### 歌词

翻译：Ronny

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

完全不匹配26的难度，说是25中下位也没有问题。
