---
title: Roselia翻唱歌曲 - Red fraction
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - Red fraction

## Red fraction

《Red fraction》由Roselia演唱。原曲是TV动画《黑礁》的片头曲。原唱为MELL。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.8，发售于2023年9月6日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EX难度

就谱面配置来说，除了一些16分音符跟主流25级分别不大，但密度更高，且混杂了几个局部纵连和一个24分微交互，有26级中位难度。
