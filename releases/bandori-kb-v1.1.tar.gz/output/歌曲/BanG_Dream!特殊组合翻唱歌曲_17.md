---
title: BanG Dream!特殊组合翻唱歌曲 - 闪光
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 闪光

## 闪光

《閃光》由Afterglow和LAYER（CV.Raychell）共同演唱。原曲是剧场版动画《机动战士高达 闪光的哈萨维》的主题歌，原唱是［Alexandros］。

### 歌曲试听

### 歌词

### 谱面

#### EXPERT难度

（待补充）
