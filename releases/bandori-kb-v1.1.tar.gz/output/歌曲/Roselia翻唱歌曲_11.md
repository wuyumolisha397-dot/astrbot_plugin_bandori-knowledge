---
title: Roselia翻唱歌曲 - Believe in my existence
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - Believe in my existence

## Believe in my existence

《Believe in my existence》由Roselia演唱。原曲是TV动画《卡片战斗先导者》的片头曲。原唱为JAM Project。

### 歌曲试听

### 歌词

翻译：Silverpearl

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

虽然只有不到600物量，但后半无明显休息段，不是水26。因为演奏时间短（仅比a to z长2秒）而且理论HSR高，本曲为协力高效率曲之一。
