---
title: Re:birth day(单曲)
url: https://zh.moegirl.org.cn/Re%3Abirth%20day%28%E5%8D%95%E6%9B%B2%29
revision: 8557430
updated: '2026-06-28'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题替换的页面
- 因冒号重设分类索引的页面
---

# Re:birth day(单曲)

《Re:birth day》是《BanG Dream!》企划组合Roselia的2nd单曲，发售于2017年6月28日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听动画于2017年6月21日在YouTube上发布。
初回封入特典为Roselia 1st Live「Rosenlied」追加公演门票先行抽选申请券、角色卡等。各店铺特典为贴纸等。

## 试听动画

## 收录曲目

## Blu-ray收录内容

「Re:birth day」Live映像
舞台后花絮影像（「Bushiroad10周年纪念Live」）

### Live映像

## 外部链接与注释

试听动画
（日文）官网CD介绍页
