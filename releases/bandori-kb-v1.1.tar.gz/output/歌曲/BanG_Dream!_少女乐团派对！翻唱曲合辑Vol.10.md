---
title: BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91Vol.10
revision: 8547390
updated: '2026-06-30'
categories:
- 2025年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 条目中存在只限中国内地播放的音频
- 翻唱专辑
---

# BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10

《バンドリ！ ガールズバンドパーティ！ カバーコレクション Vol.10》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》的第10张翻唱曲专辑，发售于2025年10月15日。分为10th纪念商品付初回生产限定盘、通常盘两种规格。
Disc1收录了Poppin'Party、Afterglow、Pastel*Palettes和Roselia的各3首翻唱曲以及2首特殊组合翻唱歌曲，共14首；Disc2收录了Hello, Happy World!、Morfonica、RAISE A SUILEN和MyGO!!!!!的各3首翻唱曲以及2首特殊组合翻唱歌曲，共14首。
10th纪念商品付初回生产限定盘附带特制透明盒套，并附赠印有专辑封面图的手提包（大小约宽360×高370×深110㎜）以及角色吧唧套装（共8种，直径约54㎜）。

## 歌曲试听

## 收录曲目

## 外部链接与注释

（日文）官网CD介绍页
