---
title: RAISE A SUILEN翻唱歌曲 - 像神一样呐
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - 像神一样呐

## 像神一样呐

《神っぽいな》由RAISE A SUILEN演唱。原曲是ピノキオピー于2021年9月17日投稿至niconico、bilibili和YouTube的VOCALOID日文歌曲，由初音未来演唱。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.8，发售于2023年9月6日。
本曲为全企划中最高音的歌曲（游戏实装版真假混声D6，full版后段E6。注：《無路矢》和音纯假声C6最高系误传）美竹兰（佐仓）躲过一劫

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  CHU²

### 谱面

#### EXPERT难度

（待补充）
