---
title: Afterglow翻唱歌曲2 - CHAINSAW BLOOD
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545299
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《CHAINSAW BLOOD》是日本女子乐团Afterglow翻唱的一首歌曲。原曲由创作歌手Vaundy创作并演唱，作为动画《电锯人》第1集的片尾曲使用，凭借独特的节奏与充满张力的演绎广受欢迎。Afterglow的翻唱版本收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，该合辑于2024年10月30日正式发售。

Afterglow是BanG Dream!企划旗下的一支五人女子摇滚乐队，成员包括主唱美竹兰（CV：佐仓绫音）、吉他手青叶摩卡（CV：三泽纱千香）、贝斯手上原绯玛丽（CV：加藤英美里）、鼓手宇田川巴（CV：日笠阳子）以及键盘手羽泽鸫（CV：金元寿子）。乐队以充满活力的摇滚风格和细腻的情感表达著称，翻唱过大量知名动画歌曲与VOCALOID曲目。

此次翻唱《CHAINSAW BLOOD》，Afterglow在保留原曲强烈冲击感的基础上，加入了乐队标志性的双吉他编曲与厚实鼓点，主唱美竹兰的嗓音在保留爆发力的同时增添了几分柔和的韧性，使整首歌曲在忠于原作的前提下展现出Afterglow独有的音乐气质。歌词延续了原版关于生存、痛苦与挣扎的主题，Afterglow的演绎更强化了青春热血与同伴羁绊的意象。

除实体专辑外，该翻唱版本亦于游戏《BanG Dream! 少女乐团派对！》中作为可玩曲目实装，玩家可以在游戏中体验完整的谱面与演出。作为翻唱曲合辑Vol.9中的亮点之一，《CHAINSAW BLOOD》既是Afterglow对经典动画歌曲的致敬，也是乐队在二次元音乐领域持续拓展影响力的又一力证。
