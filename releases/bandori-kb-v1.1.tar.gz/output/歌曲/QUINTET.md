---
title: QUINTET
url: https://zh.moegirl.org.cn/QUINTET
revision: 8505198
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# QUINTET

《QUINTET》是《BanG Dream!》企划组合Morfonica的1st专辑，发售于2023年3月15日。分为Blu-ray付生产限定盘与通常盘两种规格。标题QUINTET意为五重奏。
《誓いのWingbeat》的MV与《メランコリックララバイ》的短版歌词视频分别于2023年2月5日和2月16日在YouTube的BanG Dream!官方频道上发布。
全曲目试听动画于2023年2月22日在YouTube官方频道上发布。
初回封入特典：一张Morfonica ZEPP TOUR 2023的抽选券，以及一张封面贴纸。

## 试听动画

## 收录曲目

## Blu-ray收录内容

## 外部链接

（日文）官网CD介绍页
