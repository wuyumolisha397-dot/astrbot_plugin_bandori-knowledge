---
title: '"UNIONS" Road'
url: https://zh.moegirl.org.cn/%22UNIONS%22%20Road
revision: 8543382
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# "UNIONS" Road

## 简介

“UNIONS” Road是《BanG Dream!》企划组合Roselia 10th 单曲《約束》的C/W曲。单曲于2020年1月15日发售。
该曲为2019年8月31号-9月8号的日服活动「ノーブル·ローズ -晦冥の导き手-」的主题曲。

## 歌曲试听

Game Size

完整版

## 歌词

翻译：清水绘空
凑友希那
冰川纱夜
今井莉莎
宇田川亚子
白金燐子
全员

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

第八十九期活动《NOBLE·ROSE -幽冥的引导者-》追加曲目。

### EXPERT难度

BPM为较慢的135，而且没有太变态的配置，在一众R团歌曲难度算低。

## 注释
