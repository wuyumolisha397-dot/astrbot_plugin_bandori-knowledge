---
title: Pastel*Palettes翻唱歌曲 - 百合摇摇摇摇摇摇曳百合大事件
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - 百合摇摇摇摇摇摇曳百合大事件

## 百合摇摇摇摇摇摇曳百合大事件

《ゆりゆららららゆるゆり大事件》由Pastel*Palettes演唱。原曲是TV动画《摇曳百合》的OP。原唱为七森中☆娱乐部。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

除了开头的16连交互外几乎毫无难点。开幕雷击大事件
阿卡林？不存在的
