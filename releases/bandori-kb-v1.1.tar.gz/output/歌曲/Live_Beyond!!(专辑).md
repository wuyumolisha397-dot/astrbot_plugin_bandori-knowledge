---
title: Live Beyond!!(专辑)
url: https://zh.moegirl.org.cn/Live%20Beyond%21%21%28%E4%B8%93%E8%BE%91%29
revision: 8457799
updated: '2026-07-01'
categories:
- 2021年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
- 带有失效视频的条目
---

# Live Beyond!!(专辑)

《Live Beyond!!》是《BanG Dream!》企划组合Poppin'Party的首张迷你专辑但新曲可能比全专还多。发售于2021年8月18日。分为Blu-ray付生产限定盘、通常盘两种规格。

## 专辑试听

## 收录曲目

## Blu-ray收录内容

「Live Beyond!!」MV
「BanG Dream! 8th☆LIVE」夏の野外3DAYS DAY3：「Special Live ～Summerly Tone♪～」Poppin'Party PART
1.Time Lapse
2.イニシャル
3.夏のドーン！
4.夏空 SUN! SUN! SEVEN!
5.八月のif
6.ときめきエクスペリエンス！
7.STAR BEAT!～ホシノコドウ～
8.ティアドロップス
9.ミライトレイン
幕间映像Ⅲ
ENCORE
Poppin'Party with 凑友希那(CV.相羽あいな) & LAYER(CV.Raychell) 夢を撃ち抜く瞬間に！
特典映像 全力！バンドリ！タイムズ前编/后编

## 外部链接

（日文）官网CD介绍页
