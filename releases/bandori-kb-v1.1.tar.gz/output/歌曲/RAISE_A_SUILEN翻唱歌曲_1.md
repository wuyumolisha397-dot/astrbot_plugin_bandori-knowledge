---
title: RAISE A SUILEN翻唱歌曲 - 1/3的纯真感情
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - 1/3的纯真感情

本条目收录乐队企划《BanG Dream!》中组合RAISE A SUILEN在游戏及唱片中发布的翻唱歌曲。
真人乐队RAISE A SUILEN在演唱会现场表演过的翻唱歌曲在BanG Dream! Live翻唱歌曲查看。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## 1/3的纯真感情

《1/3の純情な感情》由RAISE A SUILEN演唱。原曲是TV动画《浪客剑心》第67~82集的片尾曲。原唱为SIAM SHADE。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.3，发售于2019年12月18日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

RAS在游戏里的第一首翻唱曲，基本上没有难度的25下位。相对于同难度的其他歌，RAS的歌总是那么温柔呢。←然而下一首翻唱让你打脸了。

#### SPECIAL难度

于活动「100回生まれ变わっても」中作为挑战曲目追加，没有太大难度的24中位，需要注意的是开头和高潮前出现的直角绿条，不熟悉可能会断触。另外在「1/3も传わらない」这句，谱面有“3”的文字押。效率和EXPERT基本没有差别。
