---
title: RAISE A SUILEN翻唱歌曲 - 狂乱 Hey Kids!!
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - 狂乱 Hey Kids!!

## 狂乱 Hey Kids!!

《狂乱 Hey Kids!!》由RAISE A SUILEN演唱。原曲是TV动画《野良神》第2期的片头曲。原唱为THE ORAL CIGARETTES。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.8，发售于2023年9月6日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  CHU²

### 谱面

#### EXPERT难度
