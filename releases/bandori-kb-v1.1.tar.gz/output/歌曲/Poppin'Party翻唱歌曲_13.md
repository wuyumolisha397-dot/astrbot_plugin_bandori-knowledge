---
title: Poppin'Party翻唱歌曲 - 夏祭
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - 夏祭

## 夏祭

《夏祭り》由Poppin'Party演唱。原曲发行于1990年8月29日，原唱是JITTERIN'JINN。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

在50期对邦活动 一闪Summer Dive 配信并为活动歌曲。

#### HARD难度

HARD谱面中，经典的前奏段被大量三连绿条占据，绿条判定抓不好的同学们要小心了，明显的EX比HD简单系列。

#### EXPERT难度

出现在太鼓之达人、Jubeat、maimai等多款街机音游中的经典三连在这个EX谱面中得到了完美重现，在街机打过这歌的话相信不难掌握。
虽说谱面节奏鲜明易掌握，但是800+物量令它成为了25级上位曲，不比相同物量、标定26级的Life Will Change容易。但台服配信不到15分钟，当期歌牌第一的人就二见AP了。

#### SPECIAL难度

虽然物量看起来过高（差一位数就到1000，与RAS某首28EX的谱面物量一致），但其中不少物量都是带节点的绿条水出来的，且EXPERT谱面中标志性的三连打在SPECIAL中也被节点绿条所取代，总体来说难度与EX相差不大。
