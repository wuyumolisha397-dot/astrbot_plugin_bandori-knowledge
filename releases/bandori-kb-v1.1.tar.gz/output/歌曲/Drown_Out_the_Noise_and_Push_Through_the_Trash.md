---
title: Drown Out the Noise and Push Through the Trash
url: https://zh.moegirl.org.cn/Drown%20Out%20the%20Noise%20and%20Push%20Through%20the%20Trash
revision: 8547367
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Fear, and Loathing in Las Vegas歌曲
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# Drown Out the Noise and Push Through the Trash

「Drown Out the Noise and Push Through the Trash」是《BanG Dream!》企划组合RAISE A SUILEN和乐队Fear, and Loathing in Las Vegas的歌曲。

## 简介

本曲是Fear, and Loathing in Las Vegas给RAISE A SUILEN提供的第二首歌（第一首为「Repaint」），RAISE A SUILEN版收录于2025年11月12日发售的RAISE A SUILEN的14th单曲《'FIGHT' ADDICT》中，Fear, and Loathing in Las Vegas版收录于2026年5月20日发售的Fear, and Loathing in Las Vegas的8th专辑《StandBy》中。
本曲的主题是「将SNS等平台上不负责任的言论视为"噪音"并"将其消除"」。

本曲的标题是一串很长的英文，对于日式英语使用者来说非常不友好，Raychell也出现过在读歌曲名时咬舌的情况。
由于本曲含有未和谐的不适当内容，所以在流媒体平台中喜提E标，这也是BanG Dream!企划中的第一首E标原创歌曲。
相较于「Repaint」，本曲的FaLiLV版并没有进行重编曲，使用的是和RAS版一样的编曲，但是仍可以听出两版有些许不同，比如赌城经典的“不锈钢”音色的鼓组。最大的区别反而是两个版本在“Until you finish writing yeah”一句的断句上有所不同。除此之外，两版BK中的歌词及排版略有不同，并且由于不同规格的FaLiLV专辑尺寸不同，对应BK的排版也可能与条目中所还原的版本（通常盘）不同。
本曲于同名演唱会「Drown Out the Noise」上被首次演奏，并在MEGA VEGAS 2026上实现了与FaLiLV的合唱。

## 歌曲

RAS版

FaLiLV版

MV

## 歌词

该歌词已还原BK

翻译：Res_Ty
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

新晋最简单28级竞争者，ex牌又一个好帮手，除了前半段的弓形绿条和副歌前的短条交互，没有能配得上28的配置了，但是有着1140的物量，可能会有心态杀。

## 注释
