---
title: Poppin'Party翻唱歌曲 - Life Will Change
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - Life Will Change

## Life Will Change

《Life Will Change》由Poppin'Party演唱。原曲是PS4游戏《女神异闻录5》的插曲。原唱为Lyn。

### 歌曲试听

### 歌词

翻译：膜菌

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

Persona联动歌曲中个人差最大的一首，对于搞不懂绿条判定的新手来说可能不太好对付，但对于老手来说甚至比标定25的P3 ED更简单（无误）。虽然物量高达800+，但并没有太多卡手的配置，几乎都是简单易懂的连打（但是有几个跟随吉他旋律的24分交互接红键可能会比较坑），FC难度相当低。但由于其随性的散拍和较低的BPM，AP难度仍然处于26级中位。
