---
title: Pastel*Palettes翻唱歌曲2 - 随花起舞
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - 随花起舞

## 随花起舞

《花ハ踊レヤいろはにほ》由Pastel*Palettes演唱。原曲为动画《花舞少女》片头曲，原唱为花舞少女队。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.5，发售于2021年2月24日。

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

### 谱面

国服不顾落后日服两年的进度于2020年4月28日光速实装该曲。最速传说的开始

#### EXPERT难度

中规中矩的BPM和配置，最难部分为490combo起左手单点+右手hold。整体难度属于25下位。

#### SPECIAL难度

（待补充）
