---
title: Morfonica翻唱歌曲 - ALIVE
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - ALIVE

## ALIVE

《ALIVE》由Morfonica演唱。原曲是TV动画《莉可丽丝》的片头曲，原唱是ClariS。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.8，发售于2023年9月6日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### Expert难度

M团新晋效率曲，时长仅次于SAVIOR OF SONG，效率亦仅次于SOS及A to Z，是目前25难度下最强效率曲。
副歌前有一段开花式的16分交互接8分粉键，需要注意。
