---
title: Hello, Happy World!翻唱歌曲 - Dragon Night
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542918
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲 - Dragon Night

## Dragon Night

《Dragon Night》由Hello, Happy World!演唱，原唱为SEKAI NO OWARI。原曲是日本流行乐坛人气曲，曾在第65回红白歌会上演出。

作为BanG Dream手游2017-2018跨年翻唱曲企划中的一部分，该翻唱版本在日服手游中实装的日期是2017年12月31日，正是每年举办红白歌会的日子。
本曲是目前除联动曲之外，唯一在封面上出现HHW成员形象的翻唱曲（左侧坐在草地上的心和右侧躲在树后的米歇尔）。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.2，发售于2019年3月16日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：小米的午后

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

前述基础上，还作为第二十九期活动《新春！波澜不断的抽签》活动挑战曲追加。

#### EXPERT难度

诈称23级，在黄RB面世之前一直是23天花板，谱面中存在大量高能连打和骚气滑条（尤其是过渡段中的高密度节点长滑条是miss重灾区313警告），FC难度比大部分24还高，强行标23可能是因为物量仅500现在真的去24了，而且绿条节点miss一个扣20血而已，所以过关难度不大。
六周年荣升24
