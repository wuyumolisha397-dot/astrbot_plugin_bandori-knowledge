---
title: 剧场版「BanG Dream! Episode of Roselia」主题歌集
url: https://zh.moegirl.org.cn/%E5%89%A7%E5%9C%BA%E7%89%88%E3%80%8CBanG%20Dream%21%20Episode%20of%20Roselia%E3%80%8D%E4%B8%BB%E9%A2%98%E6%AD%8C%E9%9B%86
revision: 8457830
updated: '2026-06-28'
categories:
- 2021年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# 剧场版「BanG Dream! Episode of Roselia」主题歌集

《劇場版「BanG Dream! Episode of Roselia」Theme Songs Collection》是《BanG Dream!》企划组合Roselia的首张迷你专辑，也是整个企划内第一张迷你专辑但新曲可能比全专还多。发售于2021年6月30日。分为Blu-ray付生产限定盘、通常盘两种规格。
专辑试听已于2021年6月6日在YouTube上发布。
初回封入特典：2021年冬季Roselia单独live活动抽选券、以及一张Voice Actor Card Collection EX VOL.01 Roselia 「Edel Rose」PR卡。限定盘和通常盘的卡面不相同。

## 专辑试听

## 收录曲目

## Blu-ray收录内容

BanG Dream! 8th☆LIVE 夏の野外3DAYS DAY1:Einheit Live映像
Avant-garde HISTORY
BLACK SHOUT
Ringing Bloom
BRAVE JEWEL
Safe and Sound
約束 / 幕間映像Ⅰ
Break your desire
Neo-Aspect
PASSIONATE ANTHEM
ONENESS
Sanctuary
R
FIRE BIRD / 幕間映像Ⅱ
ENCORE

Song I am.
熱色スターマイン

## 外部链接

（日文）官网CD介绍页
