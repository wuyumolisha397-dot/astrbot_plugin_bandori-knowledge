---
title: Life on the Lotus
url: https://zh.moegirl.org.cn/Life%20on%20the%20Lotus
revision: 8547256
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 纺木吏佐歌曲
---

# Life on the Lotus

「Ray of hope」是《BanG Dream!》企划组合RAISE A SUILEN的原创歌曲。

## 简介

本曲收录于2024年6月12日发售的RAISE A SUILEN的2nd专辑《SAVAGE》中。
本曲是手游活动第256期活动「Bless your ReBirthday」的活动曲，日服实装于2024年4月20日。
本曲于「PANDEMONIUM」上被首次演奏。

## 歌曲试听

## 歌词

翻译：面向局外的边缘人

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  LOCK  MASKING  PAREO  CHU²  合唱

## BanG Dream! 少女乐团派对！

### 谱面

#### EXPERT难度

（待补充）

## 注释及外部链接
