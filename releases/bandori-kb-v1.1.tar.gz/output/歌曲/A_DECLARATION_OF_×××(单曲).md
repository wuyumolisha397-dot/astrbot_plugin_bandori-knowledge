---
title: A DECLARATION OF ×××(单曲)
url: https://zh.moegirl.org.cn/A%20DECLARATION%20OF%20%C3%97%C3%97%C3%97%28%E5%8D%95%E6%9B%B2%29
revision: 8557380
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

《A DECLARATION OF ×××》是《BanG Dream!》企划旗下的乐队RAISE A SUILEN发行的第二张单曲，于2019年2月20日正式发售。单曲分为Blu-ray付生产限定盘和通常盘两种规格。全碟的试听动画于2019年1月7日在YouTube平台公开。

单曲的初回封入特典包含一张RAISE A SUILEN“Heaven and Earth”演唱会的最速先行抽选券，以及一张原创角色卡片（共五种，随机封入一种）。此外，若与Afterglow的第四张单曲《Y.O.L.O！！！！！》在同一店铺同时购买，还可获赠特典Blu-ray一张，内容为“RAISE A SUILEN スタジオライブ”（RAISE A SUILEN录音室现场演出视频）。

作为RAISE A SUILEN继首张单曲之后的重要作品，本单曲进一步巩固了乐队在《BanG Dream!》企划中的音乐形象。RAISE A SUILEN以其强劲的电子摇滚风格和极具感染力的现场表演著称，而《A DECLARATION OF ×××》正体现了这一特点。单曲同名主打歌延续了乐队一贯的高能量编曲与充满冲击力的演唱，歌词中蕴含的宣言式表达与乐队“以音乐打破界限”的理念相契合。

在发行同期，RAISE A SUILEN还举办了多场演唱会，其中“Heaven and Earth”演唱会即作为特典抽选券的对象活动，进一步拉近了与粉丝的距离。单曲的Blu-ray版收录了THE THIRD(仮) 2nd LIVE的现场影像，为乐迷提供了珍贵的演出记录。

整体而言，《A DECLARATION OF ×××》不仅是RAISE A SUILEN音乐道路上的重要节点，也是《BanG Dream!》企划拓展其音乐宇宙的缩影，充分展现了乐队成员——主唱LAYER、吉他手LOCK、贝斯手PAREO、鼓手CHU²及键盘手MASKING——各自独特的演奏魅力与舞台表现力。
