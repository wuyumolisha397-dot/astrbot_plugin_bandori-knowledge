---
title: Poppin'Party翻唱歌曲2 - Music Hour
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - Music Hour

## Music Hour

《ミュージック・アワー》由Poppin'Party演唱。原唱为色情涂鸦。原曲为日本流行乐曲。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.4，发售于2020年5月27日。
该曲是 2019 年“夏之鼓动”活动追加的三首翻唱曲之一。

由于原歌词出现了原唱ポルノグラフィティ的名字，因此在翻唱版的歌词中，两处使用ポルノグラフィティ的地方都被替换成了Poppin'Party。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：Silverpearl

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

中段带有大量常见于R团26+曲目的交错单手点+红键组合，一旦分心读谱力下降或者协调力差时就容易红键打错边吞下MISS。如果不是特别有信心的话，可以当作双手红键处理，幸好BPM仅135，不然又是26+了。
