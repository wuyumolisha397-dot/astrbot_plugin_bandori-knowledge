---
title: Poppin'Party翻唱歌曲 - Little Busters!
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545301
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲 - Little Busters!

## Little Busters!

《Little Busters!》由Poppin'Party演唱。原曲是游戏、以及同名TV动画《Little Busters!》的片头曲。原唱为Rita。
在少女乐团派对中使用的封面因为使用了游戏原作中的图片素材，所以罕见地加入了“©VisualArt's/Key”的版权声明。
游戏采用的是TV动画版。
台服因海外授权到期而在2022年1月31日移除该歌曲，无法再游玩此曲。是第一次有海外服务器因授权到期而移除曾经配信的歌曲。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

EXPERT难度
主歌的绿条配置比较考验配合能力，副歌16分音无缝接双押粉键也容易断连，总体上在25难度里不算简单，个人差较大。
本曲协力出分较高，但由于时长较长，因此效率反而很一般。
