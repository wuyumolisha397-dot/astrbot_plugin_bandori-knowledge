---
title: RAISE A SUILEN翻唱歌曲 - CORE PRIDE
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543368
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲 - CORE PRIDE

## CORE PRIDE

《CORE PRIDE》由RAISE A SUILEN演唱。原曲是TV动画《青之驱魔师》OP1。原唱为UVERworld。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 LAYER  CHU²

### 谱面

#### EXPERT难度

开首即高速交互杀，虽然除此之外是中规中矩的26，但交互苦手的话很容易一开始便失血过多。
