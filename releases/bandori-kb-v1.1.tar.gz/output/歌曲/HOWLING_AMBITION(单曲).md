---
title: HOWLING AMBITION(单曲)
url: https://zh.moegirl.org.cn/HOWLING%20AMBITION%28%E5%8D%95%E6%9B%B2%29
revision: 8461205
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# HOWLING AMBITION(单曲)

《HOWLING AMBITION》是《BanG Dream!》企划组合RAISE A SUILEN的13th单曲，发售于2025年6月11日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典：

RAISE A SUILEN 2DAYS LIVE「RUMBLEHEADZ」的最速先行抽选申请券；
附有巡回演唱会《RAISE A SUILEN ZEPP TOUR 2024-2025「PANDEMONIUM」》背景幕图案的高级卡片（共5种；仅限Blu-ray付生产限定盘）；
一张原创角色卡片（共5种；仅限通常盘）。
在特定实体或电子商店购买该专辑还会限量赠送包含《RAISE A SUILEN ZEPP TOUR 2024-2025「PANDEMONIUM」》中演唱曲目的特典CD（共6种）。
为纪念本单曲发售，2025年6月10日起，在特定实体商店购买BanG Dream!相关音像制品每满8000日元（含税）即可限量获赠一张本单曲的公告海报设计卡，内含RAISE A SUILEN×トゲナシトゲアリ「RAISE MY CATHARSIS」的最速先行抽选申请序列号。

## 收录曲目

## Blu-ray收录内容

RAISE A SUILEN ZEPP TOUR 2024-2025「PANDEMONIUM」东京公演Live映像
HELL! or HELL?
UNSTOPPABLE
EXIST
Takin’ my Heart
Beautiful Birthday
Life on the Lotus
CORUSCATE -DNA-
DRIVE US CRAZY
Bad Kids All Bet
JUST THE WAY I AM
V.I.P MONSTER
灼熱 Bonfire!
EXPOSE 'Burn out!!!'
Light a fire
WELCOME TO PANDEMONIUM
Encore:

TWIN TALE
!NVADE SHOW!

## 注释和参考链接

## 外部链接

（日文）官网CD介绍页
