---
title: Morfonica翻唱歌曲 - unravel
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - unravel

## unravel

《unravel》由Morfonica演唱。原曲是动画《东京食尸鬼》的第一季OP，原唱是Tk from 凛として時雨。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.7，发售于2022年12月14日。
要刚出道两年的新人唱到F5，武士道你能体会到进藤天音的痛吗？
继佐仓绫音的号哭之后又一力作“进藤天音的痛”

### 歌曲试听

#### 游戏版

#### 完整版

### 歌词

### 谱面

#### Expert难度

777的物量可能来自1000-7
较下位的26，配置类似于残酷天使，难点在于前奏的小提琴绿条和副歌的粉键，还有几处24分交互和一处32分交互。
另外，本曲的时长接近两分半（2:20），而且密度不高，效率跟泪落差不多，协力慎选。
