---
title: Yes! BanG Dream!(单曲)
url: https://zh.moegirl.org.cn/Yes%21%20BanG%20Dream%21%28%E5%8D%95%E6%9B%B2%29
revision: 8538357
updated: '2026-07-01'
categories:
- 2015年音乐单曲
- 2016年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题替换的页面
---

# Yes! BanG Dream!(单曲)

《Yes! BanG_Dream!》是《BanG Dream!》企划组合Poppin'Party的1st单曲，首次出现是作为初期1st Live后成员手渡的配布品（非卖）发布于2015年4月18日，生产限定盘先行发售于2015年10月11日，正式发售于2016年2月24日，分为Blu-ray付生产限定盘、通常盘两种规格。
配布盘只有Yes! BanG_Dream!一首歌：盘面是歌名，附加手渡时爱美、伊藤彩沙、西本里美三人的直笔签名；生产限定盘封面登场角色是除了山吹沙绫以外的其他四人，且多了一首C/W曲《STAR BEAT!〜ホシノコドウ〜》，后作为第二张单曲的主打曲。
正式盘的宣传MV于2016年2月24日在YouTube上发布。各店特典为角色明信片。在正式发售之先，Poppin'Party举行发售纪念讲座和小型Live演出，分别在：2016年2月18日的Animate新宿店
和2016年2月21日的AKIHABARAGamers本店 8F举办。

## 宣传MV

## 收录曲目

## Blu-ray收录内容

「Yes! BanG_Dream!」アニメーションミュージックビデオ
《Yes! BanG_Dream!》动画MV

## 外部链接和注释

宣传MV
（日文）官网CD介绍页
