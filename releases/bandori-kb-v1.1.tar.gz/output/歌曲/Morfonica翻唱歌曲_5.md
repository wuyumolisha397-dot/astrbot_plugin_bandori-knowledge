---
title: Morfonica翻唱歌曲 - 深海少女
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - 深海少女

## 深海少女

《深海少女》由Morfonica演唱。原曲VOCALOID传说曲，原唱为初音未来。
该曲是BanG Dream手游和初音未来第三次联动的三首曲目之一，因此官方于2020年7月29日在niconico动画上发布了完整版MV；本曲实装同时，本曲的游戏版MV在手游中追加。
完整版收录于Garupa Vocaloid翻唱曲合辑，发售于2020年12月16日。

### 歌曲试听

游戏版

完整版

### MV

#### 游戏版

#### 完整版

### 歌词

### 谱面

简中服于2025年3月6日追加此歌曲，但是游戏内歌曲封面与日服相比有较大变化。

#### EXPERT难度

（待补充）
