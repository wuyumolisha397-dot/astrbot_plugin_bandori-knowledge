---
title: Afterglow翻唱歌曲2 - Children Record (Re:boot)
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545299
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《Children Record (Re:boot)》是日本跨媒体企划《BanG Dream!》旗下女子摇滚乐队Afterglow演唱的翻唱歌曲。原曲为VOCALOID传说曲《チルドレンレコード》，由初音未来原唱，是初音未来代表曲目之一。Afterglow的翻唱版本以“Re:boot”为名重新编曲录制，于2024年10月30日随专辑《BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9》正式发售。该专辑收录了多首游戏内热门翻唱曲目，本曲亦在其中。此外，这首翻唱最初在游戏《BanG Dream! 少女乐团派对！》的第233期活动「Poppin'western journey！」期间作为可玩曲目实装，供玩家挑战不同难度谱面。

Afterglow是由美竹兰（主唱）、青叶摩卡（吉他）、上原绯玛丽（贝斯）、宇田川巴（鼓手）、羽泽鸫（键盘）组成的五人女子乐队，以硬朗的摇滚风格和充满活力的舞台表现著称。乐队成员均为羽丘女子学园的同班同学，彼此之间深厚的友情与默契贯穿乐队始终。《Children Record (Re:boot)》作为Afterglow的翻唱作品之一，延续了乐队对高能量摇滚曲目的偏好，在保留原曲快节奏与强烈情感的基础上，融入了乐队自身的音色特点，展现了她们对经典VOCALOID曲目的独特诠释。这首翻唱也因此成为Afterglow在游戏及现场演出中的热门曲目之一，进一步扩大了乐队在企划内外的影响力。
