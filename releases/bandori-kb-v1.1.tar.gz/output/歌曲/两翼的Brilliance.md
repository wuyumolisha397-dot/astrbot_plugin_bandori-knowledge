---
title: 两翼的Brilliance
url: https://zh.moegirl.org.cn/%E4%B8%A4%E7%BF%BC%E7%9A%84Brilliance
revision: 8546269
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- 卡片战斗先导者音乐
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 片尾曲
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

# 两翼的Brilliance

《両翼のBrilliance》是《BanG Dream!》企划组合Morfonica的6th单曲《両翼のBrilliance》的主打曲，也是TV动画《卡片战斗先导者 DivineZ》的片尾曲。该单曲于2024年5月1日发售。

## 歌曲

游戏版

完整版

完整版MV

LIVE视频

## 歌词

翻译：EmpyreusX

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 仓田真白  桐谷透子  广町七深  二叶筑紫  八潮瑠唯  合唱

## BanG Dream! 少女乐团派对！

日服于2024年4月14日演唱会Morfonica Concept LIVE「forte」期间实装。
