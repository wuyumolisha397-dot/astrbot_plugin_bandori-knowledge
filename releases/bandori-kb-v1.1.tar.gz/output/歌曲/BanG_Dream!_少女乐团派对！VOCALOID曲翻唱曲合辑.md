---
title: BanG Dream! 少女乐团派对！VOCALOID曲翻唱曲合辑
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81VOCALOID%E6%9B%B2%E7%BF%BB%E5%94%B1%E6%9B%B2%E5%90%88%E8%BE%91
revision: 8542923
updated: '2026-06-30'
categories:
- 2020年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 条目中存在只限中国内地播放的音频
- 翻唱专辑
---

# BanG Dream! 少女乐团派对！VOCALOID曲翻唱曲合辑

《ガルパ ボカロカバーコレクション》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》中专门收录VOCALOID翻唱曲的专辑，发售于2020年12月16日。分为Blu-ray付生产限定盘、通常盘两种规格。
收录了截至2020年7月31日，游戏内追加的Poppin'Party、Afterglow、Pastel*Palettes、Roselia、Hello, Happy World、Morfonica和RAISE A SUILEN七大乐团中的21首VOCALOID翻唱曲。

## 歌曲试听

## 收录曲目

## Blu-ray收录内容

Poppin'Party《ロミオとシンデレラ》MV
Afterglow《ロストワンの号哭》MV
Pastel*Palettes《からくりピエロ》MV
Roselia《右肩の蝶》MV
Hello, Happy World!《エイリアンエイリアン》MV
Morfonica《深海少女》MV
RAISE A SUILEN《劣等上等》MV

## 外部链接与注释

（日文）官网CD介绍页
