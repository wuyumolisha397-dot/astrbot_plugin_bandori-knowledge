---
title: '''FIGHT'' ADDICT'
url: https://zh.moegirl.org.cn/%27FIGHT%27%20ADDICT
revision: 8554822
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- RAISE A SUILEN歌曲
- Raychell歌曲
- 仓知玲凤歌曲
- 卡片战斗先导者音乐
- 夏芽歌曲
- 小原莉子歌曲
- 日本音乐作品
- 片尾曲
- 纺木吏佐歌曲
---

《'FIGHT' ADDICT》是《BanG Dream!》企划旗下乐队RAISE A SUILEN的原创歌曲，同时作为TV动画《卡片战斗先导者 DivineZ DELUXE决胜篇》的第9集片尾曲。该曲的TV版本于2025年9月7日以数字独立单曲形式先行发售，完整版则收录于同年11月12日发行的RAISE A SUILEN第14张单曲《'FIGHT' ADDICT》中。此外，这首歌曲曾在乐队专场演出「RUMBLEHEADZ」上首次现场演奏，成为其现场表演的代表曲目之一。
