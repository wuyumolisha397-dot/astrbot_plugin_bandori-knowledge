---
title: '''S/'' The Way'
url: https://zh.moegirl.org.cn/%27S%2F%27%20The%20Way
revision: 8461100
updated: '2026-06-28'
categories:
- Ave Mujica歌曲
- BanG Dream!音乐
- 佐佐木李子歌曲
- 冈田梦以歌曲
- 卡片战斗先导者音乐
- 日本音乐作品
- 渡濑结月歌曲
- 片尾曲
- 米泽茜歌曲
- 高尾奏音歌曲
---

《'S/' The Way》是《BanG Dream!》企划旗下组合Ave Mujica的原创歌曲，读作“SLASH”，用作电视动画《卡片战斗先导者 DivineZ DELUXE决胜篇》第11集的片尾曲。该曲的TV尺寸版本于2025年9月28日作为数字单曲独立发行，完整版则收录于同年12月10日发售的Ave Mujica第3张单曲《'S/' The Way / Sophie》中。此外，由Diggy-MO'演唱的Demo Mix版本收录于2026年4月17日发行的《Sophie / 'S/' The Way -ver.D-》中。官方音乐视频于2025年12月14日发布，当天恰逢Ave Mujica在东京举办的“Ulterius Procedere”公演。

该曲在动画片尾字幕、企划官网TV尺寸配信页面以及《卡片战斗先导者》动画官网的Staff&Cast页面中，均额外标注了“Produced by Diggy-MO’”。乐曲首次演奏是在Ave Mujica的“Nova Historia”演出中，但当时并未公布曲名。歌曲的官方MV由一色しめ负责绘画，サメ食べる（株式会社Ludd）负责动画制作。

作为Ave Mujica音乐作品的一部分，《'S/' The Way》延续了组合一贯的哥特式摇滚风格，歌词以拉丁语词汇“Doloris”“Mortis”“Timoris”“Amoris”“Oblivionis”等意象交织，营造出深邃而神秘的氛围。该曲同时也是组合第三张单曲的核心曲目之一，与同单曲收录的《Sophie》共同展现了Ave Mujica在叙事性与音乐性上的进一步探索。
