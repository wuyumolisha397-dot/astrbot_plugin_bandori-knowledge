---
title: SMILE ON PARADE
url: https://zh.moegirl.org.cn/SMILE%20ON%20PARADE
revision: 8552118
updated: '2026-06-28'
categories:
- 2023年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
---

# SMILE ON PARADE

《SMILE ON PARADE》是《BanG Dream!》企划组合Hello, Happy World!的第二张音乐专辑，发售于2023年6月28日。分为商品付生产限定盘、通常盘两种规格。
商品付生产限定盘附赠商品为一张装饰用假唱片与12英寸黑胶唱片封套。
初回封入特典：一张2023年Hello, Happy World!活动最速先行抽选券，以及单曲封面贴纸1张（区分限定盘与通常盘）。

## 收录曲目

## 外部链接

（日文）官网CD介绍页
