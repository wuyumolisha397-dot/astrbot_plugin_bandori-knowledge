---
title: STAR BEAT!～星之鼓动～(单曲)
url: https://zh.moegirl.org.cn/STAR%20BEAT%21%EF%BD%9E%E6%98%9F%E4%B9%8B%E9%BC%93%E5%8A%A8%EF%BD%9E%28%E5%8D%95%E6%9B%B2%29
revision: 8538321
updated: '2026-07-01'
categories:
- 2016年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# STAR BEAT!～星之鼓动～(单曲)

《STAR BEAT!〜ホシノコドウ〜》是《BanG Dream!》企划组合Poppin'Party的2nd单曲，发售于2016年8月3日。分为Blu-ray付生产限定盘、通常盘两种规格。宣传MV于2016年7月7日在YouTube上发布，完整版MV于2017年1月30日发布。
初回封入特典为BanG Dream! Second☆LIVE Starrin'PARTY 2016!的门票先行抽选申请券。各店铺特典是A5透明文件夹与明信片等。

## 宣传MV

## 收录曲目

## Blu-ray收录内容

『STAR BEAT!〜ホシノコドウ〜』 アニメーションミュージックビデオ
《STAR BEAT!〜ホシノコドウ〜》动画MV

## 外部链接与注释

宣传MV、完整MV
（日文）官网CD介绍页
