---
title: Morfonica翻唱歌曲 - 咬住秒针
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - 咬住秒针

## 咬住秒针

《秒針を噛む》由Morfonica演唱。原唱为永远都是深夜就好了。

### 歌曲试听

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

第114期活动《Let's Perfect Collection！》追加，作为该期对邦指定曲。
超级水的26。
