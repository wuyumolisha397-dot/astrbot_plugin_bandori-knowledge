---
title: Hello, Happy World!翻唱歌曲2 - 爱之上
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - 爱之上

## 爱之上

《アイウエ》由Hello, Happy World!演唱。原曲是TV动画《福星小子》新版OP。原唱为美波。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

打破了SAVIOR OF SONG的1:30，以不足1秒之差成为当前游戏中非Full曲时长最短曲目。效率是HHW歌曲里面最高，但是出分并不算很顶，只是HHW单人第三、协力第二。总的来说在协力不能撼动EXIST和ALIVE的地位，但是单人效率较为接近。
