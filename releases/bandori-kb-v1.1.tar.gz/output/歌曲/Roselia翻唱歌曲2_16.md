---
title: Roselia翻唱歌曲2 - 火花-Reloaded-
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - 火花-Reloaded-

## 火花-Reloaded-

《ヒバナ-Reloaded-》由Roselia演唱。原曲是VOCALOID传说曲。原唱是初音未来。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

本曲EASY难度的物量为187（ひばな），EXPERT难度的物量则为1187。

#### HARD难度

物量为非FULL曲第四高。

#### EXPERT难度

协调、体力、爆发的全方位大考验，比起很多SP29更难的存在，目前最难无方向键谱面之一。
1088cb处开始的大量绿粉是难倒无数玩家的存在。
