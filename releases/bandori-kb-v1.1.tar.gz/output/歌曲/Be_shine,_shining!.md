---
title: Be shine, shining!
url: https://zh.moegirl.org.cn/Be%20shine%2C%20shining%21
revision: 8542687
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- CHiSPA歌曲
- 南早纪歌曲
- 插曲
- 日本音乐作品
- 朝日奈丸佳歌曲
- 本泉莉奈歌曲
- 福圆美里歌曲
---

# Be shine, shining!

## 简介

《Be shine, shining!》是TV动画《BanG Dream!》第13话的插曲，由CHiSPA演唱。收录于TV动画OST。发售于2017年4月26日。

## 歌曲试听

TV size

## 歌词

该歌词已还原BK

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

## BanG Dream! 少女乐团派对！

（未配信）

## 注释与外部链接
