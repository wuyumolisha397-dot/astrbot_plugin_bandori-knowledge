---
title: CiRCLING(单曲)
url: https://zh.moegirl.org.cn/CiRCLING%28%E5%8D%95%E6%9B%B2%29
revision: 8522252
updated: '2026-07-01'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# CiRCLING(单曲)

《CiRCLING》是《BanG Dream!》企划组合Poppin'Party的9th单曲，发售于2018年3月21日。
主打曲《CiRCLING》的试听动画于2018年1月27日在YouTube上发布，C/W曲《Light Delight》的试听动画于2018年2月3日在YouTube上发布。
初回封入特典为BanG Dream! 5th☆LIVE 特别2次先行抽选申请券、角色卡等。各店铺特典是写真、文件夹、明信片等。除此之外，在各店铺与Roselia5th单曲《Opera of the wasteland》一同购入还将赠送特典翻唱曲CD一张。

## 试听动画

CiRCLING

Light Delight

## 收录曲目

## 特典CD

与Roselia5th单曲《Opera of the wasteland》一同购入赠送，收录了BanG Dream!的部分翻唱歌曲。
共有四种，分别对应店铺为：

青——Animate
赤——Gamers
黄——Tower Record
黑——Bushiroad EC、虎之穴（部分店铺）、WonderGOO（部分店铺）、其他应援店铺。

### 收录曲目

## 外部链接与注释

试听动画：CiRCLING、Light Delight
（日文）官网CD介绍页
