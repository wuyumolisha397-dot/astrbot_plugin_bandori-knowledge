---
title: Morfonica翻唱歌曲2
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8554819
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲2

本条目收录乐队企划《BanG Dream!》中组合Morfonica在游戏及唱片中发布的翻唱歌曲。
真人乐队Morfonica在演唱会现场表演过的翻唱歌曲在BanG Dream! Live翻唱歌曲查看。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## 捉迷藏

《かくれんぼ》由Morfonica演唱。原曲是AliA迷你专辑《AliVe》收录曲，于2019年5月20日发行。原唱是AliA。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 勇者

《勇者》由Morfonica演唱。原曲是动画《葬送的芙莉莲》的OP1，原唱是YOASOBI。

### 歌曲试听

### 歌词

### 谱面

#### EXPERT难度

（待补充）

## 轮舞-revolution

《輪舞-revolution》由Morfonica演唱。原曲是电视动画《少女革命》的片头曲。原唱为奥井雅美。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

游戏版

完整版

### 歌词

### 谱面

#### EXPERT难度

## again

《again》由Morfonica演唱。原曲是TV动画《钢之炼金术师FA》的OP1。原唱为YUI。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

### 歌词

### 谱面

#### EXPERT难度

## 身在前线

《オン・ザ・フロントライン》由Morfonica演唱。原曲是TV动画《无职转生～到了异世界就拿出真本事～》第二期第二季度的片头曲。原唱为ヒトリエ。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

## 白如雪的公主啊

《白い雪のプリンセスは》由Morfonica演唱。原曲是VOCALOID传说曲，原唱是初音未来。

### 歌曲试听

游戏版

### 歌词

翻译：yanao

### 谱面

#### EXPERT难度

（待补充）

## Mellow

《メロウ》由Morfonica演唱。原曲是动画《跳跃和乐福鞋》的片头曲，原唱是须田景凪。
完整版于2026年3月16日以数字单曲形式发行。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 外部链接与注释
