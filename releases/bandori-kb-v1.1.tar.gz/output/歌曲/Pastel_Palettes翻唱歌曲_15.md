---
title: Pastel*Palettes翻唱歌曲 - 奏
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - 奏

## 奏

《奏(かなで)》由Pastel*Palettes演唱。原曲是电影《ROUGH》的插曲。原唱为无限开关。该曲同样被作为TV动画《一周的朋友。》的片尾曲。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3，发售于2019年12月18日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

本曲BPM慢，游戏演奏时间约2分钟，音符密度低，而且没有卡手或采空音配置，是p*p第一首22级EX。实际比23级的《雀斑》、《我的世界已坠入爱河》都简单得多，甚至比起大量标级20-21的上位hard简单，以FC难度来说是22级最下位的逆诈称，AP难度也不高，推出后马上被大触花式收割1速200%note手写笔。
本曲协力效率位居中段，不像别的20-22级ex般效率倒数然而并没用，还是比a to zhard和滑滑蛋hard低。
