---
title: Roselia翻唱歌曲 - 海色
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - 海色

## 海色

《海色（みいろ）》由Roselia演唱。原曲为TV动画《舰队Collection》的片头曲，原唱为AKINO from bless4。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.4，发售于2020年5月27日。

### 歌曲试听

#### 游戏版

#### 完整版

### 歌词

### 谱面

第八十四期活动《充满希望的演奏会》追加，作为该期挑战曲。

#### EXPERT难度

什么你告诉我红莲是27这个是26？？吓得我赶紧看了看BPM，自古195出魔王系列+1坏了这下真27了
密度比红莲略高，而且混入了类似PA、ONENESS等27级配置（单点+红键交错、跟随低音部的移动连点），难度远远比大部分26都高出一个头。虽然密度比BRAVE JEWEL低，但依然无阻海色成为与BJ同类的诈称曲，对一些人来说比标定27的红莲、This game难上一截。尾杀的滑键绿条复合极具技巧性（注意，左边红尾绿条后接双手红键），甚至在之后的28级Paradisus-Paradoxum再次出现什么我都打到这了还不给我FC？。
对于地力足够FC本谱面的人来说，压gr难度不大,因此有人认为AP难度没有脱离其他26。前提是能FC
本曲也是第三届garupa杯第一轮预赛的两首课题曲之一。
六周年难度标级更改荣升27
