---
title: Esora no clover
url: https://zh.moegirl.org.cn/Esora%20no%20clover
revision: 8543429
updated: '2026-06-28'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Morfonica歌曲
- 小写标题
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 直田姬奈歌曲
- 西尾夕香歌曲
- 进藤天音歌曲
---

# Esora no clover

《esora no clover》是企划《BanG Dream!》旗下组合Morfonica的迷你专辑Forte中的曲目，专辑发售于2023年12月6日。

## 简介

官方歌词MV于2023年10月19日在YouTube发布。
本曲描写了鼓手二叶筑紫内心的挣扎和痛苦，以及克服困难坚强的一面。

## 歌曲

## 歌词

翻译：Ztumpie

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 仓田真白  桐谷透子  广町七深  二叶筑紫  八潮瑠唯  合唱

## 注释与外部链接
