---
title: BanG Dream! 少女乐团派对！原声带
url: https://zh.moegirl.org.cn/BanG%20Dream%21%20%E5%B0%91%E5%A5%B3%E4%B9%90%E5%9B%A2%E6%B4%BE%E5%AF%B9%EF%BC%81%E5%8E%9F%E5%A3%B0%E5%B8%A6
revision: 8547498
updated: '2026-06-30'
categories:
- BanG Dream!音乐唱片
- 原声带
- 条目中存在只限中国内地播放的音频
---

# BanG Dream! 少女乐团派对！原声带

《バンドリ！ガールズバンドパーティ！オリジナルサウンドトラック》是《BanG Dream!》企划手游《BanG Dream! 少女乐团派对！》的原声带，仅限在2019年6月8日至9日举办的《ガルパーティ！＆スタリラ祭2019 in池袋》线下活动的“Craft Egg展位”购买3000日元以上（含税）的商品时限量赠送。

## 歌曲试听

## 收录曲目

## 注释与参考链接
