---
title: ONENESS(单曲)
url: https://zh.moegirl.org.cn/ONENESS%28%E5%8D%95%E6%9B%B2%29
revision: 8461241
updated: '2026-06-28'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# ONENESS(单曲)

《ONENESS》是《BanG Dream!》企划组合Roselia的4th单曲，发售于2017年11月29日。分为Blu-ray付生产限定盘、通常盘两种规格。
主打曲《ONENESS》的试听动画于2017年11月10日在YouTube上发布，C/W曲《Determination Symphony》的试听动画于2017年11月11日在YouTube上发布。
初回封入特典为角色卡等。各店铺特典是写真、文件夹等。

## 试听动画

ONENESS

Determination Symphony

## 收录曲目

## Blu-ray收录内容

Roselia 1st Live Rosenlied追加公演 Live映像
节目列表：
1.LOUDER
2.BLACK SHOUT
3.魂のルフラン（剧场版动画《新世纪福音战士剧场版 死与新生》主题曲）
4.Hacking to the Gate （TV动画《命运石之门》片头曲）
5.熱色スターマイン
6.ETARNAL BLAZE（TV动画《魔法少女奈叶A's》片头曲）
7.陽だまりロードナイト
8.Re: birth day
EN1.BLACK SHOUT
EN2.LOUDER

### Live映像

## 外部链接与注释

试听动画：ONENESS、Determination Symphony
（日文）官网CD介绍页
