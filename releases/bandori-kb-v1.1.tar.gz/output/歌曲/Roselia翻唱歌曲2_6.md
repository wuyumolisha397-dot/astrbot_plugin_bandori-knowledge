---
title: Roselia翻唱歌曲2 - 鸟之诗
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - 鸟之诗

## 鸟之诗

《鳥の詩》由Roselia演唱。原曲是游戏《AIR》OP。原唱为Lia。完整版收录于Roselia的迷你专辑《ROZEN HORIZON》的写真集BK付生产限定盘，发售于2022年5月18日。

### 歌曲试听

### 歌词

### 谱面

本曲长度2:39，超越魂之轮回和千回，一度成为非full曲时长最长曲目。但此后被《焚音打》所取代。
国服以庆祝夏之律动名义于2021年7月14日超前实装。目前是国服最速实装的翻唱曲，仅相差两个半月

#### EXRERT难度

歌曲本身十分平缓，NPS(notes per second，即每秒的音符数)相当之低，除了后半段的一些八分二连点以外，没有过多的难点。主要还是依靠2:39的离谱长度撑起了26的标级。协力千万别选
