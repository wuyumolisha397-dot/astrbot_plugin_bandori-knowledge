---
title: Hello, Happy World!翻唱歌曲 - No Poi!
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542918
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲 - No Poi!

## No Poi!

《ノーポイッ！》由Hello, Happy World!演唱。原曲是TV动画《请问您今天要来点兔子吗？？》的片头曲，原唱为Petit Rabbit's。
某隔壁主唱：明明是我先来的……
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

三首点兔联动最难的一首，虽然没有魔性的滑条，但有HHW谱面传统的复杂节奏，FC和压gr难度比起另外2首25高。
