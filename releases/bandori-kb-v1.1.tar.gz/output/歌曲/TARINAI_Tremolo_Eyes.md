---
title: TARINAI/Tremolo Eyes
url: https://zh.moegirl.org.cn/TARINAI%2FTremolo%20Eyes
revision: 8462500
updated: '2026-07-01'
categories:
- 2024年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 隐藏子页面导航条的页面
---

# TARINAI/Tremolo Eyes

《TARINAI/トレモロアイズ》是《BanG Dream!》企划组合Poppin'Party的20th单曲，发售于2024年7月17日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典为一张Poppin'Party 10th Anniversary LIVE「ホシノコドウ」的最速先行抽选申请券以及一张原创角色卡片（共5种）。

## 收录曲目

## Blu-ray收录内容

BanG Dream! 12th☆LIVE DAY1:Welcome to Poppin'Land Live映像

## 外部链接

（日文）官网CD介绍页
