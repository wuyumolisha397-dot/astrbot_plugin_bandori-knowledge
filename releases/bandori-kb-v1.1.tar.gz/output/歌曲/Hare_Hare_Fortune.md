---
title: Hare Hare Fortune
url: https://zh.moegirl.org.cn/Hare%20Hare%20Fortune
revision: 8545616
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
---

# Hare Hare Fortune

## 简介

「ハレハレ☆フォーチュン」是企划《BanG Dream!》旗下组合Pastel*Palettes演唱的歌曲。

## 歌曲试听

## 歌词

翻译：星彩丶澄烁
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

## BanG Dream! 少女乐团派对！

第188期活动『ウェディング・マスト・ゴー・オン！』的主题曲。

### 谱面

tips: 在最后一个note后还有约9秒才播放完歌曲（钟声），稍稍多点耐心等待吧。

#### EXPERT难度

## 注释及外部链接
