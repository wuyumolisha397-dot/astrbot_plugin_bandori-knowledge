---
title: Pastel*Palettes翻唱歌曲2 - Stay Alive
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451784
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲2 - Stay Alive

本条目收录乐队企划《BanG Dream!》中组合Pastel*Palettes的翻唱歌曲。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## Stay Alive

《Stay Alive》由Pastel*Palettes演唱。原曲为动画《Re:从零开始的异世界生活》的后期片尾曲，原唱为爱蜜莉雅(CV：高桥李依)。本曲同时是BanG Dream和Re0动画联动活动的一部分。
完整版收录于Pastel*Palettes 2nd专辑《Pastel à la mode》Disc2，发售于2023年5月31日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### Hard难度

前一分钟的谱面属于相当简单的hard下位水平...17级，事儿歌，随手AP？
但是最后30秒得小心了，225combo处塞进了短连打，230-240combo左右更出现了红蓝交互的hard上位配置，难度落差颇大容易被欺诈，整体来说FC/AP难度不止17。

#### EXPERT难度

在日服第97期（Re0合作活动）中登场的PP第四首23级，也是目前全游EX物量的倒数第四，仅次于你所给予之物、Embrace of light和我不 哭我 不哭。再加上原曲的节奏就像是70BPM（目前官方BPM最低为75的奏）……看起来应该是很水的23吧？
但，并不是！本谱面的难度实际上远超其他23级曲，尤其是42秒左右的两根转折大滑条手动艾特Dragon Night、恋爱裁判、1分16秒左右开始的双红-蓝-蓝这是26配置吧？，还有曲中穿插的一些16分交互，都在23级曲的规格外，对于刚入EX的新手相当不友好，难点也没有Dragon Night 这么单纯。
就算把本身的曲速因素考虑在内，本谱难度也接近Dragon Night（有个人差），仅次于黄开花，是明显的诈称曲，吊打大部分24。幸好前面很水不容易爆gr，所以对于有主流25-26实力的玩家来说压gr和AP难度而言不及以上2首诈称23。
Re:从零开始的诈称生活
虽然本曲演奏时间短，但出分不高，与效率曲无缘。
