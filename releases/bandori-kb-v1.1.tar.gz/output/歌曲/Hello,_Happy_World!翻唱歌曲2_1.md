---
title: Hello, Happy World!翻唱歌曲2 - 全力少年
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - 全力少年

本条目收录乐队企划《BanG Dream!》中组合Hello, Happy World!的翻唱歌曲。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## 全力少年

《全力少年》由Hello, Happy World!演唱。原曲是电影《ROUGH》的插曲，原唱为无限开关。该曲同样被作为OVA《东京糖衣巧克力 男生篇》的主题曲。
完整版收录于Hello, Happy World! 2nd专辑《SMILE ON PARADE》Disc2，发售于2023年6月28日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：Ronny

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

全屏滑条是最难的地方，其他部分属于25下位。
