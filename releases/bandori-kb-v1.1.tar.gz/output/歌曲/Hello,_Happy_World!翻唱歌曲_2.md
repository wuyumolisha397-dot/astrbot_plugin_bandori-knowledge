---
title: Hello, Happy World!翻唱歌曲 - 1 2 fan club
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542918
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲 - 1 2 fan club

## 1 2 fan club

《いーあるふぁんくらぶ》由Hello, Happy World!演唱。原曲是VOCALOID传说曲。原唱为GUMI、镜音铃。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.1，发售于2018年6月27日。
另收录于Garupa Vocaloid翻唱曲合辑，发售于2020年12月16日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### NORMAL难度

游戏为数不多的有粉键的normal

#### EXPERT难度

#### SPECIAL难度

第103期活动《你好♪ 环游欢笑的地图》追加，作为当期挑战曲。
