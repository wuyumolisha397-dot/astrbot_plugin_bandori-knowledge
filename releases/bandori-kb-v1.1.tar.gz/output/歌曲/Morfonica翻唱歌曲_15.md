---
title: Morfonica翻唱歌曲 - divine intervention
url: https://zh.moegirl.org.cn/Morfonica%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545273
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Morfonica翻唱歌曲 - divine intervention

## divine intervention

《divine intervention》由Morfonica演唱。原曲是TV动画《魔女的使命》的片头曲，原唱是fhána。

### 歌曲试听

#### 游戏版

### 歌词

翻译：Winterlan

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### Expert难度
