---
title: Roselia翻唱歌曲 - Shangri-La
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - Shangri-La

## Shangri-La

《Shangri-La》由Roselia演唱。原曲是TV动画《苍穹之法芙娜》的片头曲。原唱为angela。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：陈鹿其

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

表面上是个24，但是有坑点。420combo左右的交互容易miss掉，但熟悉谱面后还没到诈称的地步。

#### SPECIAL难度

目前第一个SP23，除了时不时出现的过山车绿条之外，其他地方的难度也就只有23下位。
其实这首歌可以做成25甚至是26，但考虑到HD和EX难度的差距较大，做成23也算是合情合理的。
