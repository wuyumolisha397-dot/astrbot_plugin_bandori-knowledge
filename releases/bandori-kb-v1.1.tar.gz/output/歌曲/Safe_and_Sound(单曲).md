---
title: Safe and Sound(单曲)
url: https://zh.moegirl.org.cn/Safe%20and%20Sound%28%E5%8D%95%E6%9B%B2%29
revision: 8462490
updated: '2026-06-28'
categories:
- 2019年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Safe and Sound(单曲)

《Safe and Sound》是《BanG Dream!》企划组合Roselia的8th单曲，发售于2019年2月20日。分为Blu-ray付生产限定盘、通常盘两种规格。
全碟的试听动画于2019年1月5日在YouTube上发布。
初回封入特典为角色卡片一张（全5种），以及与8月3日及4日举办的Roselia单独Live 「Flamme」/「Wasser」的抽选申请卷。
在各店铺与Hello, Happy World!4th单曲《ハイファイブ∞あどべんちゃっ》一同购入还将赠送特典BD一张，内容为「Roselia -Ewigkeit- 「Roselia キャラ設定をくずしちゃいけない！！格付けクイズ」 完全版」。

## 试听动画

## 收录曲目

## Blu-ray收录内容

「BanG Dream! 5th☆LIVE」Day2:Roselia -Ewigkeit-(2018.5.13)

### Live映像

## 注释

## 外部链接

试听动画
（日文）官网CD介绍页
