---
title: IGNITE GLOW
url: https://zh.moegirl.org.cn/IGNITE%20GLOW
revision: 8546317
updated: '2026-06-30'
categories:
- Afterglow歌曲
- BanG Dream!音乐
- 三泽纱千香歌曲
- 佐仓绫音歌曲
- 加藤英美里歌曲
- 日本音乐作品
- 日笠阳子歌曲
- 条目中存在只限中国内地播放的音频
- 金元寿子歌曲
---

# IGNITE GLOW

《IGNITE GLOW》是游戏《BanG Dream! 少女乐团派对！》第211期活动「刻入天穹傲岸的烈光」的追加曲目。

## 简介

本曲收录于2024年4月3日发售的Afterglow第一张迷你专辑《忘れらんない日々のこと》中。
单曲于2023年8月3日配信。

## 歌曲试听

完整版

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 美竹兰  青叶摩卡  上原绯玛丽  宇田川巴  羽泽鸫  合唱

## BanG Dream! 少女乐团派对！

第211期活动《刻入天穹傲岸的烈光》追加曲目。
本曲目的SPECIAL难度在日服于2024年11月30日追加。

#### SPECIAL难度

（待补充）

## 注释与外部链接
