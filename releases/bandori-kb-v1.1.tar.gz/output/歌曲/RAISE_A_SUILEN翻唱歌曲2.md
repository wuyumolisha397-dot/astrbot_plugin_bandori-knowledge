---
title: RAISE A SUILEN翻唱歌曲2
url: https://zh.moegirl.org.cn/RAISE%20A%20SUILEN%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8554825
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# RAISE A SUILEN翻唱歌曲2

本条目收录乐队企划《BanG Dream!》中组合RAISE A SUILEN在游戏及唱片中发布的翻唱歌曲。
真人乐队RAISE A SUILEN在演唱会现场表演过的翻唱歌曲在BanG Dream! Live翻唱歌曲查看。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## 真理之口

《ボッカデラベリタ》由RAISE A SUILEN演唱。原曲是柊キライ于2020年4月26日投稿至niconico、bilibili和YouTube的VOCALOID歌曲，由V flower演唱。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.9，发售于2024年10月30日。

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

于第253期活动「SAKURA CiRCRiNG PARTY!」期间实装。

#### EXPERT难度

难度较高，物量较多，时间较长的26级谱面。

## SOULSOUP

《SOULSOUP》由RAISE A SUILEN演唱。原曲是动画电影《剧场版 间谍过家家 CODE: White》的主题曲。原唱为Official髭男dism。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

于第262期活动「Battle of R」期间实装。配合2024年愚人节皮肤使用更佳。

#### EXPERT难度

（待补充）

## Bling-Bang-Bang-Born

《Bling-Bang-Bang-Born》由RAISE A SUILEN演唱。原曲是动画《物理魔法使马修 神觉者候补选拔试验篇》的片头曲。原唱为Creepy Nuts。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

Game Size

完整版

### 歌词

### 谱面

#### EXPERT难度

（待补充）

## 第六感

《第六感》由RAISE A SUILEN演唱。原曲是BOAT RACE 2020的印象曲，原唱为Reol。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.10，发售于2025年10月15日。

### 歌曲试听

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 百花缭乱

《百花繚乱》由RAISE A SUILEN演唱。原曲是是动画《药屋少女的呢喃》第二季的片头曲，原唱是幾田りら。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## BROKEN GAMES

《BROKEN GAMES》由RAISE A SUILEN演唱。原曲是动画《香格里拉·开拓异境 ～粪作猎手挑战神作～》的片头曲，原唱是虚拟乐队FZMZ。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

（待补充）

## 革命途中

《革命道中》由RAISE A SUILEN演唱。原曲是动画《当哒当》第二季的片头曲，原唱是アイナ・ジ・エンド。
完整版于2026年3月18日以数字单曲形式发行。

### 歌曲试听

完整版

### 歌词

### 谱面

#### EXPERT难度

（待补充）

## 绝对零度

《絶対零度》由RAISE A SUILEN演唱。原曲是电视动画《WIND BREAKER 防风铃》第一季的片头曲，原唱是なとり。

### 歌曲试听

Game Size

### 歌词

### 谱面

#### EXPERT难度

（待补充）

## 注释与外部链接
