---
title: Dear Gleam
url: https://zh.moegirl.org.cn/Dear%20Gleam
revision: 8545682
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Roselia歌曲
- 中岛由贵歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 相羽爱奈歌曲
---

# Dear Gleam

## 简介

《Dear Gleam》是《BanG Dream!》企划组合Roselia13th单曲《THRONE OF ROSE》中的C/W曲目。单曲发售于2023年4月26日。
歌名意为“珍贵的微光”。

## 歌曲试听

## 歌词

翻译：Tsukiato月痕

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 凑友希那  冰川纱夜  今井莉莎  宇田川亚子  白金燐子  合唱

## BanG Dream! 少女乐团派对！

### EX难度

本曲的BPM高达196，看上去非常哈人，但是细细研究配置之后就会发现无非是R组其他27（比如ZEAL of proud、Keep Heart、Proud of oneself）的主要难点配置的变体和一些考验玩家底力基本功的配置。
中后段760-821combo的连续爆发是全曲最难段，是玩家clear/FC的最大阻碍然而另一方面来说实际上也是纸老虎，本曲的AP难度较低甚至和某些26接近。

## 外部链接与注释
