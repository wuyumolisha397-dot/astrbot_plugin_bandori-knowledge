---
title: Determination Symphony
url: https://zh.moegirl.org.cn/Determination%20Symphony
revision: 8540591
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- C/W曲
- Roselia歌曲
- 中岛由贵歌曲
- 小泽亚李歌曲
- 工藤晴香歌曲
- 带有失效视频的条目
- 志崎桦音歌曲
- 插曲
- 日本音乐作品
- 日笠阳子歌曲
- 明坂聪美歌曲
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 相羽爱奈歌曲
- 远藤祐里香歌曲
---

# Determination Symphony

## 简介

《Determination Symphony》是《BanG Dream!》企划组合Roselia4th单曲《ONENESS》中的C/W曲。单曲发售于2017年11月29日。
手游BanG Dream! 少女乐团派对！剧情活动《秋时骤雨伞层叠》主题曲。
在TV动画《BanG Dream!》第二季的第9话用作插曲。
2nd专辑《Wahl》中收录了该曲在两次更换声优后的重录版本。
本曲亦有由SISTER'S QUARTET（宇田川巴（CV.日笠阳子）、冰川日菜（CV.小泽亚李）、冰川纱夜（CV.工藤晴香）、宇田川亚子（CV.樱川惠））演唱的平行歌曲版本，于2026年1月6日在各音乐平台配信。

## 歌曲试听

重录版

Parallel Ver.

## 歌词

该歌词已还原BK

## BanG Dream! 少女乐团派对！

第二十一期活动《秋时骤雨伞层叠》追加曲目。

### Hard难度

少数21级hard，物量位居hard第五。其配置平均，没有特别难的地方，难点主要体现在物量和高BPM。

### EX难度

目前全游短板物量第十
综合难度在27中上位水平，甚至不比28级God Knows简单。但实际上配置和GK很相似，没有过难的点，27级的难度主要还是体现在物量和速度上，手速和体力是攻略该谱面过程中的关键，可以作为攻略重生日、RB的前置练习曲。

### Parallel Ver.

于2026年1月4日追加，谱面与原版谱面一致。
有关Parallel Vocals，详见此条目。

## 外部链接与注释
