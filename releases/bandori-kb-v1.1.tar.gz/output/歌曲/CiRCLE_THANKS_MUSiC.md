---
title: CiRCLE THANKS MUSiC
url: https://zh.moegirl.org.cn/CiRCLE%20THANKS%20MUSiC
revision: 8545126
updated: '2026-06-30'
categories:
- Ayasa歌曲
- BanG Dream!音乐
- Mika歌曲
- Raychell歌曲
- 三泽纱千香歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 中岛由贵歌曲
- 丰田萌绘歌曲
- 仓知玲凤歌曲
- 伊藤彩沙歌曲
- 伊藤美来歌曲
- 佐仓绫音歌曲
- 使用标题替换的页面
- 前岛亚美歌曲
- 加藤英美里歌曲
- 吉田有里歌曲
- 夏芽歌曲
- 大冢纱英歌曲
- 大桥彩香歌曲
- 小原莉子歌曲
- 小泽亚李歌曲
- 工藤晴香歌曲
- 志崎桦音歌曲
- 日本音乐作品
- 日笠阳子歌曲
- 条目中存在只限中国内地播放的音频
- 樱川惠歌曲
- 爱美歌曲
- 田所梓歌曲
- 直田姬奈歌曲
- 相羽爱奈歌曲
- 秦佐和子歌曲
- 纺木吏佐歌曲
- 西尾夕香歌曲
- 西本里美歌曲
- 进藤天音歌曲
- 金元寿子歌曲
- 黑泽朋世歌曲
---

# CiRCLE THANKS MUSiC

《CiRCLE THANKS MUSiC♪》是手游BanG Dream! 少女乐团派对！中的歌曲，由BanGDream企划全员组成的特殊乐队CiRCLE THANKS PARTY！スペシャルバンド共同演唱
本曲的完整版收录在纪念专辑《BanG Dream! Dreamer’s Best》中，于2022年3月16日发售。
这首歌的伴奏版也是邦邦手游在6.0时代使用的默认登录界面BGM，取代了统治两年的TWiNKLE CiRCLE，成为了网络状况不佳地区玩家的噩梦。该噩梦在7.0版本被RiNG A BELL取代。
本曲于BanG Dream! Special☆LIVE Girls Band Party! 2020→2022上被首次现场演唱，但当时因种种原因，包括前岛亚美在内的部分演唱者未能出席。直至约三年后的BanG Dream! 10th Anniversary LIVE「In the name of BanG Dream!」方集齐了全35位演唱者。

## 歌曲试听

### Game Ver.

### 完整版

## 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  市谷有咲  花园多惠  牛込里美  山吹沙绫  丸山彩  白鹭千圣  冰川日菜  若宫伊芙  大和麻弥  弦卷心  奥泽美咲  松原花音  濑田薰  北泽育美  冰川纱夜  凑友希那  今井莉莎  宇田川亚子  白金燐子  LOCK  MASKING  LAYER  PAREO  CHU²  桐谷透子  八潮瑠唯  广町七深  二叶筑紫  仓田真白  上原绯玛丽  宇田川巴  羽泽鸫  美竹兰  青叶摩卡  合唱

## BanG Dream! 少女乐团派对！

### EXPERT难度

（待补充）

### [FULL]EXPERT难度

全游第七个拥有完整版谱面的歌曲并且实装只比短版谱面晚了一周有趣的是，完整版谱面实装与短板谱面实装时的活动都叫「Backstage Pass 5」，但两个活动的活动类型和活动id都不同猜测是不许摸为了让五周年活动周期和同期正在播出的五周年纪念动画档期对应而故意为之
EX难度物量以五个的微弱优势超过了FULL ON YOUR MARK成为仅次于FULL火鸟的全游第二，但由于时长比前者长了不少所以谱面密度很低，但仍需注意本曲的三处邻轨note和结尾的三个BPM123的24分小交互

## 注释与外部链接
