---
title: Roselia翻唱歌曲2 - 甲贺忍法帖
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8545260
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲2 - 甲贺忍法帖

本条目收录乐队企划《BanG Dream!》中组合Roselia在游戏及唱片中发布的翻唱歌曲。
真人乐队Roselia在演唱会现场表演过的翻唱歌曲在BanG Dream! Live翻唱歌曲查看。
BanG Dream!系列完整歌曲列表在BanG Dream! 音乐列表查看。
BanG Dream!系列完整翻唱曲列表在BanG Dream!翻唱曲列表查看。

## 甲贺忍法帖

《甲賀忍法帖（ROSELISK TIME）》由Roselia演唱。原曲为动画《甲贺忍法帖》的片头曲，原唱为阴阳座。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.5，发售于2021年2月24日。

2017年，有网友将原曲的副歌段配上一个黑人跳舞的视频片段，并配以バジリスクタイム（BASILISK TIME）的文字，从而衍生出了这个深入人心的名梗。因此在Roselia翻唱版正式配信后，也立即出现了一些对Roselia版大玩BASILISK TIME梗的视频其实早在maimai收录原曲原版时，谱面就已经玩了这个梗。
真·全员黑人跳舞：
三田警告：

### 歌曲试听

游戏版

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

第103期活动《你好♪ 环游欢笑的地图》追加，作为该期挑战曲。

#### EXPERT难度

中规中矩的地力连打型26，值得注意的是，本曲在唱到花の様に劇く中“花の様に”时会谱面出现一个花朵形的五连滑条和隔壁PPP夏のドーン！一样
同时在唱到瞳の奥　閉じても中“瞳の奥”时也会出现一个眼睛形的滑条。

毫无高能的标准AP手元：
