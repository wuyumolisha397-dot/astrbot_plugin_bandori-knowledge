---
title: Roselia翻唱歌曲 - Fatima
url: https://zh.moegirl.org.cn/Roselia%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8545293
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Roselia翻唱歌曲 - Fatima

## Fatima

《ファティマ》由Roselia演唱。原曲为TV动画《命运石之门0》的片头曲，原唱为伊藤香奈子。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

谱面节奏较为紧凑，难点除前奏的转折滑条接粉键以外，还有深得Light Delight精髓的蓝粉双押+单键的交替组合。来回摆动1格的滑条可当作直条来糊，注意判定区域即可。
本曲时长仅1分35秒，协力效率达到了382%，姑且可以当做效率曲。
