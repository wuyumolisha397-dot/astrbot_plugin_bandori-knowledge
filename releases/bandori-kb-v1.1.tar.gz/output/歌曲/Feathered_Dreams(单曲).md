---
title: Feathered Dreams(单曲)
url: https://zh.moegirl.org.cn/Feathered%20Dreams%28%E5%8D%95%E6%9B%B2%29
revision: 8461198
updated: '2026-06-28'
categories:
- 2025年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# Feathered Dreams(单曲)

《Feathered Dreams》是《BanG Dream!》企划组合Morfonica的8th单曲，发售于2025年8月27日。分为Blu-ray付生产限定盘、通常盘两种规格。
Blu-ray付生产限定盘附带特制透明盒套（限量）以及24页的图片小册子。初回封入特典：

一张Morfonica 5th Anniversary LIVE「Maestoso」的最速先行抽选申请券；
一张角色卡片（共5种，另有5种附带全息烫印角色签名）；
一张《卡片战斗先导者》PR卡。
官方还于2025年8至9月间在日本各地举办本单曲的发售纪念活动，包括线上签名会、一日店长巡游以及特殊谈话会。

## 收录曲目

## Blu-ray收录内容

《Morfonica LIVE「Rubato」》Live、幕后（Behind the Veil）和广告（CM）映像
Wreath of Brave
Sonorous
メランコリックララバイ
誓いのWingbeat
両翼のBrilliance
ブルームブルーム
One step at a time
カラフルリバティー
寄る辺のSunny, Sunny
ティリカモニカリラ
flame of hope
Daylight -デイライト-
Polyphonyscape
ENCORE
ハーモニー・デイ
Tempest

## 外部链接

（日文）官网单曲介绍页
发售纪念活动介绍页
（日文）线上签名会
（日文）一日店长巡游
（日文）特殊谈话会
