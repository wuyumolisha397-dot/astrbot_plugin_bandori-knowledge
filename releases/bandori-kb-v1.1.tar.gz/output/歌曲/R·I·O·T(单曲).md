---
title: R·I·O·T(单曲)
url: https://zh.moegirl.org.cn/R%C2%B7I%C2%B7O%C2%B7T%28%E5%8D%95%E6%9B%B2%29
revision: 8557387
updated: '2026-06-28'
categories:
- 2018年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
- 含有受损文件链接的页面
---

# R·I·O·T(单曲)

《R·I·O·T》是《BanG Dream!》企划组合RAISE A SUILEN的1st单曲，发售于2018年12月12日。分为Blu-ray付生产限定盘、通常盘两种规格。
试听视频发布于2018年11月18日。
初回封入特典为一张TOKYO MX presents 「BanG Dream! 7th☆LIVE」DAY2:Genesis演唱会的最速先行抽选券，以及一张原创角色卡片（共5种，随机1种）
在各店铺与Poppin'Party12th单曲《キズナミュージック♪》和Roselia7th单曲《BRAVE JEWEL》一同购入还将赠送特典翻唱曲CD一张。

## 试听动画

## 收录曲目

## Blu-ray收录内容

THE THIRD(仮) 1st ライブ

### Live映像

## 特典CD

与Poppin'Party12th单曲《キズナミュージック♪》和Roselia7th单曲《BRAVE JEWEL》一同购入赠送，收录了BanG Dream!的部分翻唱歌曲。五张特典CD收录的歌曲完全相同，只有光盘表面的涂装不同。

### 收录曲目

## 注释

## 外部链接

试听动画
（日文） 官网CD介绍页
