---
title: Pastel*Palettes翻唱歌曲 - Fantastic future
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - Fantastic future

## Fantastic future

《Fantastic future》由Pastel*Palettes演唱。原曲是TV动画《变态王子与不笑猫》的片头曲。原唱为田村由香里。
完整版收录于BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3，发售于2019年12月18日。

### 歌曲试听

Game Size

完整版

### 歌词

翻译：Kyube

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EXPERT难度

在歌词唱到“私から誘う勇気をくださいと月に願うの”的时候，在"月"字的位置上，谱面会出现一个月亮形状的双滑条，呼应歌词同时暗示筒隐月子。该滑条也是本曲最大难点，如果不考虑那个滑条的话其余部分只是25级中位水平，能打那处滑条就是水26。
