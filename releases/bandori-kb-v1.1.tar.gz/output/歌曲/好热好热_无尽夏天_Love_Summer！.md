---
title: 好热好热 无尽夏天 Love Summer！
url: https://zh.moegirl.org.cn/%E5%A5%BD%E7%83%AD%E5%A5%BD%E7%83%AD%20%E6%97%A0%E5%B0%BD%E5%A4%8F%E5%A4%A9%20Love%20Summer%EF%BC%81
revision: 8548944
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Pastel*Palettes歌曲
- 上坂堇歌曲
- 中上育实歌曲
- 使用标题替换的页面
- 前岛亚美歌曲
- 小泽亚李歌曲
- 日本音乐作品
- 条目中存在只限中国内地播放的音频
- 秦佐和子歌曲
- 需要更名的条目
---

# 好热好热 无尽夏天 Love Summer！

## 简介

《あっつあつ 常夏 らぶ☆サマー！》是《BanG Dream!》企划组合Pastel*Palettes 1st 专辑《TITLE IDOL》中的曲目。专辑于2021年5月19日发售。

## 歌曲试听

游戏版

完整版

## 歌词

翻译：网易云音乐

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 丸山彩  冰川日菜  白鹭千圣  大和麻弥  若宫伊芙  合唱

## BanG Dream! 少女乐团派对！

第八十六期活动《只属于我们的SUMMER VACATION》追加曲目。

### HARD难度

### EXPERT难度

注意结尾的全屏双滑条接粉键。

### SPECIAL难度

日服于2023年7月29日追加。

## 外部链接与注释
