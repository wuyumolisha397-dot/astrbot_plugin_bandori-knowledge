---
title: Poppin'Party翻唱歌曲2 - 大河啊一同哭泣吧
url: https://zh.moegirl.org.cn/Poppin%27Party%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8451757
updated: '2026-07-01'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# Poppin'Party翻唱歌曲2 - 大河啊一同哭泣吧

## 大河啊一同哭泣吧

《大河よ共に泣いてくれ》由Poppin'Party演唱。原曲是动画《佐贺偶像是传奇 卷土重来》的片头曲，原唱是法兰秀秀。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.6，发售于2021年11月10日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  花园多惠  市谷有咲  合唱

### 谱面

#### EXPERT难度

作为动画OP，只有93秒的长度，难道又是新一代的效率曲？没错！排除了Bug级的SOS和EXIST，这首歌的效率绝对在T1队列，与SP烧鸡班持平，完爆EX烧鸡班、红莲、滑滑蛋。
但是大量的绿接粉使得难度较高（接近A2Z），属于26上位曲。
