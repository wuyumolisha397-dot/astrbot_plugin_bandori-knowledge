---
title: BanG Dream!特殊组合翻唱歌曲 - 檄！帝国华击团
url: https://zh.moegirl.org.cn/BanG%20Dream%21%E7%89%B9%E6%AE%8A%E7%BB%84%E5%90%88%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8543307
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在只限中国内地播放的音频
---

# BanG Dream!特殊组合翻唱歌曲 - 檄！帝国华击团

## 檄！帝国华击团

《檄！帝国華撃団》由Poppin'Party、丸山彩（CV.前岛亚美）和弦卷心（CV.伊藤美来）共同演唱。原曲是TV动画《樱花大战》的片头曲。原唱为真宫寺樱（横山智佐）& 帝国歌剧团。
完整版收录于BanG Dream! Girls Band Party! 翻唱曲合辑Vol.2，发售于2019年3月16日。

### 歌曲试听

Game Size

完整版

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 户山香澄  丸山彩  弦卷心  合唱

### 谱面

国服以庆祝一周年名义于2020年6月5日提前实装。

#### EXPERT难度

帝国滑稽团（确信）
一枚900+物量的26，不过其中红键及绿条节点的占比较高 半屏转折高密度滑条的鼻祖之一 。
