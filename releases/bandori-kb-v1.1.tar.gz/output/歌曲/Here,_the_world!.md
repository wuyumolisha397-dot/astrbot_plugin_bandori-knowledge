---
title: Here, the world!
url: https://zh.moegirl.org.cn/Here%2C%20the%20world%21
revision: 8456492
updated: '2026-06-30'
categories:
- BanG Dream!音乐
- Sumimi歌曲
- 佐佐木李子歌曲
- 反田叶月歌曲
- 日本音乐作品
---

# Here, the world!

「Here, the world!」是《BanG Dream!》企划组合sumimi的原创歌曲，也是动画《BanG Dream! It's MyGO!!!!!》第1、4-7、10话以及《BanG Dream! Ave Mujica》第11话的插入曲。

## 简介

本曲完整版于2023年6月30日先行配信，收录于2025年5月28日发售的《BanG Dream! Ave Mujica》动画Blu-ray的上下两卷同时预约购买附送的特典CD。
本曲也被观众戏称为“忘记一切的小曲”，原自上述MyGO!!!!!动画第七集结尾，失落的丰川祥子在街上广告牌听到了这首歌，打电话给演唱者之一的三角初华，哭着说：“拜托了初华，让我忘记一切吧……”
本曲于「わかれ道の、その先へ」上被首次演奏。

## 歌曲试听

完整版

## 歌词

翻译：壹条鱼干
本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。 初华  真奈  合唱

## 注释与外部链接

（日文） 官网数字单曲页面
