---
title: 热色Star Mine(单曲)
url: https://zh.moegirl.org.cn/%E7%83%AD%E8%89%B2Star%20Mine%28%E5%8D%95%E6%9B%B2%29
revision: 8522270
updated: '2026-06-28'
categories:
- 2017年音乐单曲
- BanG Dream!音乐单曲
- Bushiroad Music音乐单曲
- 使用标题格式化的页面
---

# 热色Star Mine(单曲)

《熱色スターマイン》是《BanG Dream!》企划组合Roselia的3rd单曲，发售于2017年8月30日。试听动画于2017年8月19日在YouTube上发布。
初回封入特典为Roselia 2nd Live门票抽选申请券、贴纸等。各店铺特典为写真等。

## 试听动画

## 收录曲目

## 外部链接与注释

试听动画
（日文）官网CD介绍页
