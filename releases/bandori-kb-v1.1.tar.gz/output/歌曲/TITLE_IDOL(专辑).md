---
title: TITLE IDOL(专辑)
url: https://zh.moegirl.org.cn/TITLE%20IDOL%28%E4%B8%93%E8%BE%91%29
revision: 8552175
updated: '2026-06-28'
categories:
- 2021年音乐专辑
- BanG Dream!音乐专辑
- Bushiroad Music音乐专辑
- 使用标题格式化的页面
---

# TITLE IDOL(专辑)

《TITLE IDOL》是《BanG Dream!》企划组合Pastel*Palettes的首张音乐专辑，发售于2021年5月19日。分为Blu-ray付生产限定盘、通常盘两种规格。
初回封入特典：单曲封面角色卡1张（共5种）。

## 收录曲目

## Blu-ray收录内容

DISC1

《TITLE IDOL》MV
Pastel*Palettes Sound Only Live「Flowerful＊」
DISC2

Pastel＊Palettes 特别公演 ～まんまるお山に彩りスペシャル☆～

## 特典CD

在对应店铺购买Afterglow 1st专辑、Pastel＊Palettes 1st专辑和Hello, Happy World! 1st专辑三张CD时将赠送三首翻唱碟曲CD。在不同的指定店铺购买时，光盘表面的涂装也不同。

「青い栞」Afterglow
「ドリームパレード」Pastel＊Palettes
「太陽曰く燃えよカオス」Hello, Happy World!
指定店铺可前往（日文）这里查看。

## 外部链接

（日文）官网CD介绍页
