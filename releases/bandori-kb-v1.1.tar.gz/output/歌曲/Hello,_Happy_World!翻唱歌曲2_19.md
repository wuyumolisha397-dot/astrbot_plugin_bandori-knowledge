---
title: Hello, Happy World!翻唱歌曲2 - Dancehall
url: https://zh.moegirl.org.cn/Hello%2C%20Happy%20World%21%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B22
revision: 8552850
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 条目中存在中国内地无法播放的视频
- 条目中存在只限中国内地播放的音频
---

# Hello, Happy World!翻唱歌曲2 - Dancehall

## Dancehall

《ダンスホール》由Hello, Happy World!演唱。原曲是富士电视台节目「めざまし8」的新主题曲，由Mrs. GREEN APPLE演唱。

值得一提的是，该曲原唱乐队主唱大森元贵与饰演奥泽美咲/米歇尔的黑泽朋世是好友。

### 歌曲试听

Game Size

### 歌词

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

于第232期活动“Kokoro's Happy Happy Summer Treasure!!”（こころのハピハピ・サマートレジャー！！）期间发布，同时也作为该挑战活动的课题曲之一。以0.5秒之差超越Hyadain的上上友情成为目前游戏内实装演奏时间最长的HHW非FULL版歌曲。
