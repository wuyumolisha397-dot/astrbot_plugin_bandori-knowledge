---
title: Afterglow翻唱歌曲 - 自豪革命
url: https://zh.moegirl.org.cn/Afterglow%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8542925
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
---

《自豪革命》是企划《BanG Dream!》中由少女乐团Afterglow演唱的一首翻唱歌曲。该曲原唱为CHiCO with HoneyWorks，最初作为电视动画《银魂°》的片头曲面世。Afterglow翻唱的完整版本收录于2019年12月18日发售的《BanG Dream! 少女乐团派对！翻唱曲合辑Vol.3》中。

在游戏《BanG Dream! 少女乐团派对！》内，这首翻唱曲的谱面设计极具挑战性。其Expert难度谱面是Afterglow在游戏中获得的第一首25级翻唱曲目。该谱面在185BPM的高语速节拍下，穿插了大量达到26级水平的交互连打，使得全连难度大幅提升，整体处于25级难度的上位水平。对于尚未掌握快速交互技巧的新手玩家而言，该谱面往往会产生难度“诈称”的错觉。

此外，游戏的Special难度谱面作为第七十五期活动《流转的四季、初始的天空》的挑战曲目追加。相较于Expert难度，Special谱面在物量与整体难度上均有着显著的提升，进一步考验着玩家的综合音游实力。这首歌曲凭借原曲激昂的旋律与Afterglow成员们充满力量的演绎，成为了游戏中备受玩家关注的经典翻唱曲目之一。
