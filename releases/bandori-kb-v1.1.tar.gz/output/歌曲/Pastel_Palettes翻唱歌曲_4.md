---
title: Pastel*Palettes翻唱歌曲 - MOON PRIDE
url: https://zh.moegirl.org.cn/Pastel%2APalettes%E7%BF%BB%E5%94%B1%E6%AD%8C%E6%9B%B2
revision: 8544069
updated: '2026-06-30'
categories:
- BanG Dream!列表
- BanG Dream!音乐
- 带有失效视频的条目
- 条目中存在只限中国内地播放的音频
---

# Pastel*Palettes翻唱歌曲 - MOON PRIDE

## MOON PRIDE

《MOON PRIDE》由Pastel*Palettes演唱。原曲是TV动画《美少女战士Crystal》的片头曲。原唱为桃色幸运草Z。

### 歌曲试听

### 歌词

翻译：佐渡守通胜、Amane

本段落中所使用的歌词，其著作权属于原著作权人，仅以介绍为目的引用。

### 谱面

#### EX难度

前奏与尾奏大量的迷幻长短滑条，读谱稍慢容易miss，在早期一度被认为是26上位，其他并无太多难点。随着新26的难度普遍提高这个早已经不算难的26了。
